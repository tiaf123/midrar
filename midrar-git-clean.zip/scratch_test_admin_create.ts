import dotenv from "dotenv";
dotenv.config();

import { createClient } from "@supabase/supabase-js";

async function testAdminCreateUser() {
  console.log("\n=========================================");
  console.log("🧪 Testing Supabase Admin User & Profile Creation (No Rate Limits)");
  console.log("=========================================");

  const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    console.error("❌ Missing Supabase URL or Service Role Key");
    return;
  }

  const supabaseAdmin = createClient(url, serviceKey);

  const testEmail = `real_user_${Date.now()}@gmail.com`;
  const testPassword = "Password123!";
  const testName = "عبد الله الرشيد (مستخدم حقيقي)";
  const testRole = "guardian";

  console.log(`1. Creating confirmed user via admin API: ${testEmail}...`);
  const adminCreateRes = await supabaseAdmin.auth.admin.createUser({
    email: testEmail,
    password: testPassword,
    email_confirm: true,
    user_metadata: { full_name: testName, role: testRole }
  });

  if (adminCreateRes.error) {
    console.error("❌ Admin Create Error:", adminCreateRes.error.message);
    return;
  }

  const userId = adminCreateRes.data.user.id;
  console.log("✅ User created successfully in auth.users with ID:", userId);

  console.log(`2. Inserting into public.profiles for ID: ${userId}...`);
  const profileInsert = await supabaseAdmin.from('profiles').upsert([
    {
      id: userId,
      role: testRole,
      full_name: testName,
      email: testEmail
    }
  ]);

  if (profileInsert.error) {
    console.error("❌ Profiles Insert Error:", profileInsert.error.message);
  } else {
    console.log("✅ Successfully inserted profile row into public.profiles!");
  }

  console.log("3. Verifying record from public.profiles table...");
  const verifyRes = await supabaseAdmin.from('profiles').select('*').eq('id', userId).single();
  if (verifyRes.error) {
    console.error("❌ Verification error:", verifyRes.error.message);
  } else {
    console.log("✅ RECORD VERIFIED IN SUPABASE DATABASE:");
    console.log(verifyRes.data);
  }

  console.log("=========================================\n");
}

testAdminCreateUser();
