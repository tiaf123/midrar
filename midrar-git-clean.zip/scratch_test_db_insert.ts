import dotenv from "dotenv";
dotenv.config();

import { createClient } from "@supabase/supabase-js";

async function testSupabaseRegistrationAndDbInsert() {
  console.log("\n=========================================");
  console.log("🧪 Testing Supabase Real User & Profile Insertion");
  console.log("=========================================");

  const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const anonKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !anonKey) {
    console.error("❌ Missing Supabase URL or keys");
    return;
  }

  const supabase = createClient(url, anonKey);
  const supabaseAdmin = serviceKey ? createClient(url, serviceKey) : supabase;

  const testEmail = `parent_test_${Date.now()}@gmail.com`;
  const testPassword = "Password123!";
  const testName = "عبد الله الرشيد (اختبار حي)";
  const testRole = "guardian";

  console.log(`1. Calling supabase.auth.signUp for: ${testEmail}...`);
  const signUpRes = await supabase.auth.signUp({
    email: testEmail,
    password: testPassword,
    options: {
      data: { full_name: testName, role: testRole }
    }
  });

  if (signUpRes.error) {
    console.error("❌ SignUp Error:", signUpRes.error.message);
    return;
  }

  const userId = signUpRes.data.user?.id;
  console.log("✅ User created in auth.users with ID:", userId);

  if (!userId) {
    console.error("❌ No user ID returned from signUp");
    return;
  }

  console.log(`2. Inserting into public.profiles for ID: ${userId}...`);
  const profileInsert = await supabaseAdmin.from('profiles').upsert([
    {
      id: userId,
      role: testRole,
      full_name: testName,
      email: testEmail
    }
  ]);

  if (profileInsert.error) {
    console.error("❌ Profiles Insert Error:", profileInsert.error.message, profileInsert.error);
  } else {
    console.log("✅ Successfully inserted into public.profiles!");
  }

  console.log("3. Verifying record from public.profiles...");
  const verifyRes = await supabaseAdmin.from('profiles').select('*').eq('id', userId).single();
  if (verifyRes.error) {
    console.error("❌ Verification error:", verifyRes.error.message);
  } else {
    console.log("✅ RECORD FOUND IN SUPABASE DATABASE:");
    console.log(verifyRes.data);
  }

  console.log("=========================================\n");
}

testSupabaseRegistrationAndDbInsert();
