import React from 'react';
import { AnimatePresence } from 'motion/react';
import { LanguageProvider } from './i18n/LanguageContext';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { LandingPage } from './components/landing/LandingPage';
import { StudentDashboard } from './components/student/StudentDashboard';
import { GuardianDashboard } from './components/guardian/GuardianDashboard';
import { TeacherDashboard } from './components/teacher/TeacherDashboard';
import { SchoolDashboard } from './components/school/SchoolDashboard';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { Toast } from './components/common/Toast';
import { SplashScreen } from './components/motion/SplashScreen';
import { MotionPage } from './components/motion/MotionPage';

import { InstallPWAButton } from './components/common/InstallPWAButton';

// Modals
import { AuthModal } from './components/auth/AuthModal';
import { LearningPreferenceModal } from './components/test/LearningPreferenceModal';
import { LessonViewerModal } from './components/lessons/LessonViewerModal';
import { QuizRunnerModal } from './components/quizzes/QuizRunnerModal';
import { TeacherProfileModal } from './components/schools/TeacherProfileModal';
import { ChatModal } from './components/chat/ChatModal';
import { ParentReportModal } from './components/guardian/ParentReportModal';
import { TeacherGeneratorModal } from './components/teacher/TeacherGeneratorModal';
import { AssignmentGraderModal } from './components/teacher/AssignmentGraderModal';
import { StudentAssignmentModal } from './components/student/StudentAssignmentModal';
import { AddChildModal } from './components/guardian/AddChildModal';
import { ChildrenCodesModal } from './components/guardian/ChildrenCodesModal';
import { SupabaseSchemaModal } from './components/common/SupabaseSchemaModal';
import { MidrarAIAssistant } from './components/chat/MidrarAIAssistant';

const AppContent: React.FC = () => {
  const { role } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-slate-800 font-sans selection:bg-[#81A6C6]/30 selection:text-slate-900 overflow-x-hidden">
      {/* 1. App Introduction Splash Screen (First visit session-cached) */}
      <SplashScreen />

      {/* 2. Top Header with Smooth Transitions */}
      <Header />

      {/* 3. Main Content Body with Smooth Page Transitions */}
      <main className="flex-1 pt-16 pb-24 md:pb-0">
        <AnimatePresence mode="wait">
          {role === 'guest' && (
            <MotionPage key="guest-view">
              <LandingPage />
            </MotionPage>
          )}
          {role === 'student' && (
            <MotionPage key="student-view">
              <StudentDashboard />
            </MotionPage>
          )}
          {role === 'guardian' && (
            <MotionPage key="guardian-view">
              <GuardianDashboard />
            </MotionPage>
          )}
          {role === 'teacher' && (
            <MotionPage key="teacher-view">
              <TeacherDashboard />
            </MotionPage>
          )}
          {role === 'school' && (
            <MotionPage key="school-view">
              <SchoolDashboard />
            </MotionPage>
          )}
        </AnimatePresence>
      </main>

      {/* 4. Footer */}
      <Footer />

      {/* 5. Native App-like Dynamic Mobile Bottom Navigation with layoutId */}
      <MobileBottomNav />

      {/* 6. Floating Midrar AI Assistant Widget (Permanent Fixed AI Robot) */}
      <MidrarAIAssistant />

      {/* 7. All Global Interactive Modals */}
      <AuthModal />
      <LearningPreferenceModal />
      <LessonViewerModal />
      <QuizRunnerModal />
      <TeacherProfileModal />
      <ChatModal />
      <ParentReportModal />
      <TeacherGeneratorModal />
      <AssignmentGraderModal />
      <StudentAssignmentModal />
      <AddChildModal />
      <ChildrenCodesModal />
      <SupabaseSchemaModal />

      {/* 8. Global PWA App Installation Prompt */}
      <InstallPWAButton />

      {/* 9. Global Toast Notification System */}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </LanguageProvider>
  );
}
