import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { UserRole } from '../../types';
import { Logo } from '../common/Logo';
import {
  X,
  GraduationCap,
  Users,
  BookOpen,
  School,
  KeyRound,
  Mail,
  Lock,
  ArrowRight,
  ShieldCheck,
  Loader2,
  UserCheck,
  UserPlus
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { activeModal, setActiveModal, loginWithStudentCode, loginWithEmail, registerWithEmail, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [studentCodeInput, setStudentCodeInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (activeModal !== 'auth') return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    // Student Login via Student Code ONLY
    if (selectedRole === 'student') {
      if (!studentCodeInput.trim()) {
        showToast(isArabic ? 'يرجى كتابة رمز الطالب (مثل: STU-8821)' : 'Please enter student code', 'warning');
        return;
      }
      setIsSubmitting(true);
      try {
        await loginWithStudentCode(studentCodeInput);
      } catch (err: any) {
        showToast(err?.message || 'خطأ أثناء تسجيل الدخول', 'error');
      } finally {
        setIsSubmitting(false);
      }
      return;
    }

    // Email Login (Guardian / Teacher / School)
    if (authMode === 'login') {
      if (!emailInput.trim() || !passwordInput.trim()) {
        showToast(isArabic ? 'يرجى كتابة البريد الإلكتروني وكلمة المرور' : 'Please enter email and password', 'warning');
        return;
      }
      setIsSubmitting(true);
      try {
        await loginWithEmail(emailInput, passwordInput, selectedRole);
      } catch (err: any) {
        showToast(err?.message || 'خطأ في تسجيل الدخول', 'error');
      } finally {
        setIsSubmitting(false);
      }
      return;
    }

    // Email Registration (Guardian / Teacher / School)
    if (authMode === 'register') {
      if (!nameInput.trim()) {
        showToast(isArabic ? 'يرجى إدخال الاسم الكامل' : 'Please enter full name', 'warning');
        return;
      }
      if (!emailInput.trim() || !passwordInput.trim()) {
        showToast(isArabic ? 'يرجى كتابة البريد الإلكتروني وكلمة المرور' : 'Please enter email and password', 'warning');
        return;
      }
      if (passwordInput.length < 6) {
        showToast(isArabic ? 'كلمة المرور يجب أن تكون 6 خانات أو أكثر' : 'Password must be at least 6 characters', 'warning');
        return;
      }

      setIsSubmitting(true);
      try {
        await registerWithEmail(emailInput, passwordInput, nameInput, selectedRole);
      } catch (err: any) {
        showToast(err?.message || 'تعذر إنشاء الحساب', 'error');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-br from-[#81A6C6]/10 via-white to-[#F3E3D0]/20">
          <Logo size="md" showSlogan={false} />
          <button
            type="button"
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          {/* Role Tabs */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5">
              {t.auth.selectRoleTitle}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setSelectedRole('student')}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                  selectedRole === 'student'
                    ? 'bg-[#81A6C6]/15 border-[#81A6C6] text-[#81A6C6] font-bold shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <GraduationCap className="w-5 h-5" />
                <span className="text-xs">{t.roles.student}</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('guardian')}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                  selectedRole === 'guardian'
                    ? 'bg-[#81A6C6]/15 border-[#81A6C6] text-[#81A6C6] font-bold shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Users className="w-5 h-5" />
                <span className="text-xs">{t.roles.guardian}</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('teacher')}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                  selectedRole === 'teacher'
                    ? 'bg-[#81A6C6]/15 border-[#81A6C6] text-[#81A6C6] font-bold shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <BookOpen className="w-5 h-5" />
                <span className="text-xs">{t.roles.teacher}</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('school')}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                  selectedRole === 'school'
                    ? 'bg-[#81A6C6]/15 border-[#81A6C6] text-[#81A6C6] font-bold shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <School className="w-5 h-5" />
                <span className="text-xs">{t.roles.school}</span>
              </button>
            </div>
          </div>

          {/* Login / Register Toggle Tabs (For Guardian, Teacher, School) */}
          {selectedRole !== 'student' && (
            <div className="flex border-b border-slate-200">
              <button
                type="button"
                onClick={() => setAuthMode('login')}
                className={`pb-2.5 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
                  authMode === 'login'
                    ? 'border-[#81A6C6] text-[#81A6C6]'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                <UserCheck className="w-4 h-4" />
                <span>{t.auth.alreadyHaveAccount}</span>
              </button>
              <button
                type="button"
                onClick={() => setAuthMode('register')}
                className={`pb-2.5 px-4 text-xs font-bold transition-all border-b-2 cursor-pointer flex items-center gap-1.5 ${
                  authMode === 'register'
                    ? 'border-[#81A6C6] text-[#81A6C6]'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>{t.auth.dontHaveAccount}</span>
              </button>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Student Code Flow (Student Role ONLY) */}
            {selectedRole === 'student' && (
              <div className="space-y-4 bg-slate-50 p-5 rounded-2xl border border-slate-200/80">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                    <KeyRound className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">{t.auth.studentCodeTitle}</h4>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">{t.auth.studentCodeSubtitle}</p>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t.auth.enterStudentCode}
                  </label>
                  <input
                    type="text"
                    value={studentCodeInput}
                    onChange={(e) => setStudentCodeInput(e.target.value)}
                    placeholder="مثال: STU-8821"
                    dir="ltr"
                    className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl text-center text-lg font-mono font-bold tracking-widest text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#81A6C6] focus:border-transparent uppercase placeholder:normal-case placeholder:tracking-normal placeholder:text-sm placeholder:font-sans"
                  />
                </div>

                <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl flex items-center gap-2 text-xs text-blue-800">
                  <ShieldCheck className="w-4 h-4 shrink-0 text-blue-600" />
                  <span>{t.auth.studentRuleNote}</span>
                </div>
              </div>
            )}

            {/* Standard Email/Password Flow (Guardian / Teacher / School Login or Register) */}
            {selectedRole !== 'student' && (
              <div className="space-y-4">
                {authMode === 'register' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {selectedRole === 'school' ? t.auth.schoolName : t.auth.fullName}
                    </label>
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      placeholder={selectedRole === 'school' ? "اسم المدرسة أو المجمع التعليمي" : "الاسم الكامل"}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{t.auth.email}</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute start-3 top-3" />
                    <input
                      type="email"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="name@example.com"
                      dir="ltr"
                      className="w-full ps-10 pe-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{t.auth.password}</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute start-3 top-3" />
                    <input
                      type="password"
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      placeholder="••••••••"
                      dir="ltr"
                      className="w-full ps-10 pe-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Big Action Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 px-6 bg-gradient-to-r from-[#81A6C6] to-[#6b93b5] hover:from-[#7298b9] hover:to-[#5e84a5] disabled:opacity-50 text-white font-extrabold text-base rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2.5 cursor-pointer transform active:scale-[0.99]"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>جاري المعالجة...</span>
                </>
              ) : (
                <>
                  <span>{authMode === 'login' ? t.auth.loginButton : t.auth.registerButton}</span>
                  <ArrowRight className="w-5 h-5 rtl:rotate-180" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
