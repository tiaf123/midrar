import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  Send,
  ShieldCheck,
  Search,
  MessageSquare,
  Paperclip,
  CheckCheck
} from 'lucide-react';

export const ChatModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    conversations,
    messages,
    activeConversationId,
    setActiveConversationId,
    sendChatMessage,
    currentUser
  } = useApp();
  const { isArabic, t } = useLanguage();

  const [inputMessage, setInputMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  if (activeModal !== 'chat') return null;

  const currentConv = conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const currentMessages = (activeConversationId && messages[activeConversationId]) || [];

  const filteredConversations = conversations.filter((c) =>
    c.participantName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || !activeConversationId) return;
    sendChatMessage(activeConversationId, inputMessage);
    setInputMessage('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#81A6C6]/20 text-[#81A6C6] flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">{t.chat.title}</h3>
              <p className="text-xs text-slate-500">{t.chat.subtitle}</p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body 2 columns */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 overflow-hidden">
          {/* Left / Sidebar Conversations */}
          <div className="border-e border-slate-200 flex flex-col bg-slate-50/40">
            <div className="p-3 border-b border-slate-200/70">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.chat.searchConversations}
                  className="w-full ps-9 pe-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#81A6C6]"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
              {filteredConversations.map((conv) => {
                const isSelected = conv.id === activeConversationId;
                return (
                  <button
                    key={conv.id}
                    type="button"
                    onClick={() => setActiveConversationId(conv.id)}
                    className={`w-full p-3 rounded-2xl border text-start transition-all flex items-start gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-white border-[#81A6C6] shadow-xs'
                        : 'bg-transparent border-transparent hover:bg-slate-100/70'
                    }`}
                  >
                    <img
                      src={conv.participantAvatar}
                      alt={conv.participantName}
                      className="w-10 h-10 rounded-xl object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h5 className="text-xs font-bold text-slate-800 truncate">{conv.participantName}</h5>
                        <span className="text-[10px] text-slate-400 shrink-0">{conv.lastMessageTime}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">{conv.lastMessage}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right / Chat Area */}
          <div className="md:col-span-2 flex flex-col bg-white overflow-hidden">
            {currentConv ? (
              <>
                {/* Active Chat Header */}
                <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-white">
                  <div className="flex items-center gap-3">
                    <img
                      src={currentConv.participantAvatar}
                      alt={currentConv.participantName}
                      className="w-10 h-10 rounded-xl object-cover"
                    />
                    <div>
                      <h4 className="font-bold text-xs text-slate-900">{currentConv.participantName}</h4>
                      <p className="text-[10px] text-slate-400">
                        {isArabic ? currentConv.participantTitleAr : currentConv.participantTitleEn}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{isArabic ? 'محادثة آمنة' : 'Encrypted'}</span>
                  </div>
                </div>

                {/* Messages Feed */}
                <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-3 bg-slate-50/30">
                  {currentMessages.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-xs text-slate-400">
                      {t.chat.noMessages}
                    </div>
                  ) : (
                    currentMessages.map((msg) => {
                      const isMe = msg.senderId === currentUser.id || msg.senderRole === currentUser.role;
                      return (
                        <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                          <div
                            className={`max-w-[78%] p-3.5 rounded-2xl text-xs leading-relaxed space-y-1 ${
                              isMe
                                ? 'bg-[#81A6C6] text-white rounded-br-none'
                                : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none shadow-2xs'
                            }`}
                          >
                            <p>{msg.content}</p>
                            <div
                              className={`flex items-center justify-end gap-1 text-[9px] ${
                                isMe ? 'text-blue-100' : 'text-slate-400'
                              }`}
                            >
                              <span>{msg.timestamp}</span>
                              {isMe && <CheckCheck className="w-3 h-3 text-white" />}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Bottom Input */}
                <form onSubmit={handleSend} className="p-3 border-t border-slate-100 bg-white flex items-center gap-2">
                  <button
                    type="button"
                    className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
                    title={t.chat.attachFile}
                  >
                    <Paperclip className="w-4 h-4" />
                  </button>

                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder={t.chat.typePlaceholder}
                    className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#81A6C6]"
                  />

                  <button
                    type="submit"
                    disabled={!inputMessage.trim()}
                    className="p-2.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white rounded-xl disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <Send className="w-4 h-4 rtl:rotate-180" />
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
                {t.chat.emptyChat}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
