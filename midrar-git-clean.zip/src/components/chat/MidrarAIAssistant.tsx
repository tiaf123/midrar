import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { motionTokens } from '../../motion/tokens';
import {
  Bot,
  Send,
  X,
  RotateCcw,
  Volume2,
  VolumeX,
  ExternalLink,
  Copy,
  Check,
  Maximize2,
  Minimize2,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  actionButton?: {
    labelAr: string;
    labelEn: string;
    actionType: 'modal' | 'lesson' | 'role' | 'faq';
    payload?: string;
  };
}

export const MidrarAIAssistant: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    setRole,
    setSelectedLessonId,
  } = useApp();
  const { isArabic } = useLanguage();

  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [showAlertBadge, setShowAlertBadge] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const streamIntervalRef = useRef<number | null>(null);

  // Initial direct & simple greeting message (no long philosophy)
  const getInitialMessages = (): ChatMessage[] => [
    {
      id: 'msg-welcome',
      sender: 'ai',
      text: isArabic
        ? 'أهلاً بك! أنا مساعد مِدْرار الذكي، كيف يمكنني مساعدتك؟'
        : 'Welcome! I am Midrar Smart Assistant, how can I help you?',
      timestamp: new Date().toLocaleTimeString(isArabic ? 'ar-SA' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    },
  ];

  const [messagesList, setMessagesList] = useState<ChatMessage[]>(getInitialMessages);

  // Cleanup stream interval on unmount
  useEffect(() => {
    return () => {
      if (streamIntervalRef.current) {
        clearInterval(streamIntervalRef.current);
      }
    };
  }, []);

  // Update initial message when language toggles
  useEffect(() => {
    setMessagesList((prev) => {
      if (prev.length === 1 && prev[0].id === 'msg-welcome') {
        return getInitialMessages();
      }
      return prev;
    });
  }, [isArabic]);

  // Scroll to bottom
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messagesList, isTyping, isOpen]);

  // Listen to open assistant modal triggers
  useEffect(() => {
    if (activeModal === 'chat') {
      setIsOpen(true);
      setShowAlertBadge(false);
      setActiveModal(null);
    }
  }, [activeModal, setActiveModal]);

  // Read aloud function (clean plain text)
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window) || !soundEnabled) return;
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*_#`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = isArabic ? 'ar-SA' : 'en-US';
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  // Concise responses without asterisks/markdown bolding
  const getConciseResponse = (userQuery: string): { text: string; actionButton?: ChatMessage['actionButton'] } => {
    const q = userQuery.toLowerCase().trim();

    // 1. Tracks & Modalities
    if (
      q.includes('مسار') ||
      q.includes('انماط') ||
      q.includes('أنماط') ||
      q.includes('بصري') ||
      q.includes('سمعي') ||
      q.includes('تفاعلي') ||
      q.includes('قرائي') ||
      q.includes('vark') ||
      q.includes('track') ||
      q.includes('modalit')
    ) {
      return {
        text: isArabic
          ? 'يوفر مِدْرار 4 مسارات متوازية لكل درس: البصري بالرسومات والخرائط، السمعي بالبودكاست، القرائي بالنصوص والملخصات، والتفاعلي بالمحاكاة والتجارب، مع إمكانية التبديل بينها في أي وقت.'
          : 'Midrar provides 4 parallel tracks for every lesson: Visual, Auditory, Reading, and Hands-on labs, with instant toggling between them anytime.',
        actionButton: {
          labelAr: 'تصفح درساً تفاعلياً',
          labelEn: 'Explore an interactive lesson',
          actionType: 'lesson',
          payload: 'les-1',
        },
      };
    }

    // 2. Diagnostic Assessment (25 Questions)
    if (
      q.includes('اختبار') ||
      q.includes('25') ||
      q.includes('تشخيص') ||
      q.includes('تفضيل') ||
      q.includes('diagnostic') ||
      q.includes('test') ||
      q.includes('quiz')
    ) {
      return {
        text: isArabic
          ? 'اختبار الـ 25 موقفاً يقيس النمط الأنسب لاستيعاب الطالب من خلال مواقف يومية بسيطة خلال 5 دقائق، ونتيجته مرنة تتطور مع تفاعل الطالب مع الدروس.'
          : 'The 25-scenario test assesses your preferred learning style through real-life scenarios in 5 minutes, providing an adaptive baseline that evolves over time.',
        actionButton: {
          labelAr: 'ابدأ اختبار التفضيلات',
          labelEn: 'Take the Diagnostic Test',
          actionType: 'modal',
          payload: 'learning-preference',
        },
      };
    }

    // 3. Guardians & Child safety
    if (
      q.includes('ولي امر') ||
      q.includes('ولي الأمر') ||
      q.includes('ابن') ||
      q.includes('ابني') ||
      q.includes('اطفال') ||
      q.includes('أطفال') ||
      q.includes('طفل') ||
      q.includes('parent') ||
      q.includes('guardian') ||
      q.includes('child')
    ) {
      return {
        text: isArabic
          ? 'تتيح لوحة ولي الأمر متابعة تقدم الأبناء والتواصل مع معلميهم بكل سهولة، ويدخل الطالب بأمان عبر رمز الطالب الخاص دون الحاجة لبريد إلكتروني.'
          : 'The Guardian portal lets you track child progress and message teachers securely, while students log in safely with a Student Code without personal emails.',
        actionButton: {
          labelAr: 'فتح لوحة ولي الأمر',
          labelEn: 'Open Guardian Portal',
          actionType: 'role',
          payload: 'guardian',
        },
      };
    }

    // 4. Teachers & AI Lesson Generator
    if (
      q.includes('معلم') ||
      q.includes('مدرس') ||
      q.includes('تحضير') ||
      q.includes('توليد') ||
      q.includes('واجب') ||
      q.includes('تصحيح') ||
      q.includes('teacher') ||
      q.includes('lesson plan') ||
      q.includes('grader')
    ) {
      return {
        text: isArabic
          ? 'يساعد مولد الدروس الذكي المعلم في إنشاء درس كامل بالمسارات الأربعة مع الأسئلة ونماذج الإجابة في ثوانٍ معدودة، مع إمكانية التعديل الكامل والتصحيح التلقائي.'
          : 'The AI lesson generator creates complete 4-track lessons and rubrics in seconds, giving teachers full editing control and smart homework grading.',
        actionButton: {
          labelAr: 'فتح مولد الدروس الذكي',
          labelEn: 'Open AI Lesson Generator',
          actionType: 'modal',
          payload: 'teacher-generator',
        },
      };
    }

    // 5. School leadership
    if (
      q.includes('مدرسة') ||
      q.includes('مدير') ||
      q.includes('مشرف') ||
      q.includes('إدارة') ||
      q.includes('تحليلات') ||
      q.includes('school') ||
      q.includes('principal') ||
      q.includes('kpi')
    ) {
      return {
        text: isArabic
          ? 'تقدم بوابة المدرسة مؤشرات أداء لحظية لنسب الإتقان وتوزيع أنماط التعلم بين الطلاب لمساعدة الإدارة في اتخاذ القرارات التربوية وتطوير البيئة التعليمية.'
          : 'The School Portal provides real-time mastery analytics and learning preference distributions across classes to support data-driven educational decisions.',
        actionButton: {
          labelAr: 'استعراض بوابة المدرسة',
          labelEn: 'View School Portal',
          actionType: 'role',
          payload: 'school',
        },
      };
    }

    // 6. Security, Privacy & PDF
    if (
      q.includes('أمان') ||
      q.includes('خصوصية') ||
      q.includes('بيانات') ||
      q.includes('pdf') ||
      q.includes('طباعة') ||
      q.includes('privacy') ||
      q.includes('security')
    ) {
      return {
        text: isArabic
          ? 'بيانات الطلاب مشفرة ومحمية بالكامل ولا تشارك مع أي طرف، كما تتيح المنصة تحميل الملخصات بصيغة PDF للمذاكرة بدون إنترنت.'
          : 'Student data is fully encrypted and protected, and learners can export lesson summaries as PDFs for offline study.',
      };
    }

    // 7. General fallback
    return {
      text: isArabic
        ? 'مِدْرار منصة تعليمية ذكية تخصص الدروس بـ 4 مسارات متوازية، مع اختبار لتشخيص نمط التعلم، وبوابات متكاملة للطالب وولي الأمر والمعلم والمدرسة.'
        : 'Midrar is an adaptive educational platform that customizes lessons across 4 parallel tracks, featuring a diagnostic test and connected portals for all roles.',
    };
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isTyping) return;

    if (streamIntervalRef.current) {
      clearInterval(streamIntervalRef.current);
      streamIntervalRef.current = null;
    }

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString(isArabic ? 'ar-SA' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setMessagesList((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // AI Response with real-time streaming effect
    setTimeout(() => {
      const responseData = getConciseResponse(text);
      const fullText = responseData.text;
      const aiMsgId = `ai-${Date.now()}`;
      const time = new Date().toLocaleTimeString(isArabic ? 'ar-SA' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
      });

      // Add empty initial AI message
      const initialAiMsg: ChatMessage = {
        id: aiMsgId,
        sender: 'ai',
        text: '',
        timestamp: time,
        actionButton: responseData.actionButton,
      };

      setMessagesList((prev) => [...prev, initialAiMsg]);

      // Stream character by character smoothly
      let currentIndex = 0;
      const charStep = 2; // smooth 2 chars per tick
      const speedMs = 20;

      streamIntervalRef.current = window.setInterval(() => {
        currentIndex += charStep;
        if (currentIndex >= fullText.length) {
          currentIndex = fullText.length;
          if (streamIntervalRef.current) {
            clearInterval(streamIntervalRef.current);
            streamIntervalRef.current = null;
          }
          setIsTyping(false);
          if (soundEnabled) {
            speakText(fullText);
          }
        }

        const currentStreamedText = fullText.slice(0, currentIndex);
        setMessagesList((prev) =>
          prev.map((msg) =>
            msg.id === aiMsgId ? { ...msg, text: currentStreamedText } : msg
          )
        );
      }, speedMs);
    }, 350);
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(id);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handleActionButtonClick = (actionButton: ChatMessage['actionButton']) => {
    if (!actionButton) return;
    if (actionButton.actionType === 'modal') {
      if (actionButton.payload === 'learning-preference') setActiveModal('learning-preference');
      else if (actionButton.payload === 'teacher-generator') setActiveModal('teacher-generator');
      else if (actionButton.payload === 'parent-report') setActiveModal('parent-report');
      else if (actionButton.payload === 'auth') setActiveModal('auth');
    } else if (actionButton.actionType === 'lesson') {
      setSelectedLessonId(actionButton.payload || 'les-1');
    } else if (actionButton.actionType === 'role') {
      setRole((actionButton.payload as any) || 'student');
      setIsOpen(false);
    }
  };

  const handleResetChat = () => {
    if (streamIntervalRef.current) {
      clearInterval(streamIntervalRef.current);
      streamIntervalRef.current = null;
    }
    setIsTyping(false);
    setMessagesList(getInitialMessages());
  };

  return (
    <>
      {/* 1. Clean, Fixed Floating Assistant Button */}
      <div
        className={`fixed z-40 pointer-events-auto select-none ${
          isArabic
            ? 'right-4 sm:right-6 bottom-24 md:bottom-6'
            : 'left-4 sm:left-6 bottom-24 md:bottom-6'
        }`}
      >
        <div className="relative">
          {/* Simple Dismissible Notification Badge (Positioned directly ABOVE the button, never displacing button!) */}
          <AnimatePresence>
            {!isOpen && showAlertBadge && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className={`absolute bottom-full mb-2 ${
                  isArabic ? 'right-0' : 'left-0'
                } bg-slate-900/95 text-white px-3 py-1.5 rounded-xl shadow-lg border border-slate-700 text-[11px] font-medium flex items-center gap-2 cursor-pointer backdrop-blur-xs whitespace-nowrap z-50`}
                onClick={() => {
                  setIsOpen(true);
                  setShowAlertBadge(false);
                }}
              >
                <span>
                  {isArabic ? 'لديك سؤال عن مِدْرار؟' : 'Have a question?'}
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowAlertBadge(false);
                  }}
                  className="text-slate-400 hover:text-white p-0.5 rounded-md hover:bg-slate-800 transition-colors"
                  title={isArabic ? 'إغلاق' : 'Dismiss'}
                >
                  <X className="w-3 h-3" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Clean Floating Robot Button (Anchored firmly in place) */}
          <button
            type="button"
            onClick={() => {
              setIsOpen(!isOpen);
              setShowAlertBadge(false);
            }}
            className={`w-13 h-13 sm:w-14 sm:h-14 rounded-2xl shadow-lg flex items-center justify-center transition-transform hover:scale-105 active:scale-95 cursor-pointer border border-white/80 ${
              isOpen
                ? 'bg-slate-900 text-white'
                : 'bg-[#81A6C6] hover:bg-[#6f95b7] text-white shadow-blue-500/20'
            }`}
            title={isArabic ? 'مساعد مِدْرار الذكي' : 'Midrar Smart Assistant'}
          >
            {isOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <div className="relative flex items-center justify-center">
                <Bot className="w-6 h-6 sm:w-7 sm:h-7" />
                <span className="absolute -top-1 -end-1 w-2.5 h-2.5 bg-emerald-400 border-2 border-white rounded-full" />
              </div>
            )}
          </button>
        </div>
      </div>

      {/* 2. Floating AI Assistant Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={motionTokens.spring.responsive}
            className={`fixed z-50 flex flex-col bg-white shadow-2xl border border-slate-200 overflow-hidden ${
              isExpanded
                ? 'inset-3 sm:inset-6 rounded-2xl'
                : `bottom-24 md:bottom-22 ${
                    isArabic ? 'right-3 sm:right-6' : 'left-3 sm:left-6'
                  } w-[calc(100vw-24px)] sm:w-[400px] h-[520px] max-h-[calc(100vh-120px)] rounded-2xl`
            }`}
          >
            {/* Header */}
            <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between shadow-xs shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#81A6C6] text-white flex items-center justify-center shadow-xs">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white leading-tight">
                    {isArabic ? 'مساعد مِدْرار الذكي' : 'Midrar Smart Assistant'}
                  </h3>
                  <p className="text-[10px] text-emerald-400 font-medium leading-tight">
                    {isArabic ? 'متصل وجاهز للإجابة' : 'Online'}
                  </p>
                </div>
              </div>

              {/* Header Controls */}
              <div className="flex items-center gap-1 text-slate-300">
                <button
                  type="button"
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className={`p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer ${
                    soundEnabled ? 'text-amber-400' : 'text-slate-400'
                  }`}
                  title={isArabic ? 'الصوت' : 'Voice'}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={handleResetChat}
                  className="p-1.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  title={isArabic ? 'إعادة ضبط المحادثة' : 'Reset'}
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors hidden sm:flex cursor-pointer"
                  title={isExpanded ? 'تصغير' : 'تكبير'}
                >
                  {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  title={isArabic ? 'إغلاق' : 'Close'}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Suggestions Bar */}
            <div className="bg-slate-50 border-b border-slate-100 px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
              {[
                { ar: 'المسارات الأربعة', en: 'The 4 Tracks' },
                { ar: 'اختبار الـ 25', en: '25-Scenario Test' },
                { ar: 'أولياء الأمور', en: 'Guardians' },
                { ar: 'توليد الدروس', en: 'Teacher Tools' },
                { ar: 'الأمان والـ PDF', en: 'Privacy & PDF' },
              ].map((pill, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendMessage(isArabic ? pill.ar : pill.en)}
                  className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 hover:border-[#81A6C6] hover:text-[#4B6B94] text-[11px] font-medium transition-colors whitespace-nowrap cursor-pointer shrink-0"
                >
                  {isArabic ? pill.ar : pill.en}
                </button>
              ))}
            </div>

            {/* Chat Body */}
            <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-slate-50/30">
              {messagesList.map((msg) => {
                const isAI = msg.sender === 'ai';
                const isCopied = copiedMsgId === msg.id;

                return (
                  <div key={msg.id} className={`flex gap-2 ${isAI ? 'justify-start' : 'justify-end'}`}>
                    {isAI && (
                      <div className="w-6 h-6 rounded-lg bg-[#81A6C6] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                        <Bot className="w-3.5 h-3.5" />
                      </div>
                    )}

                    <div
                      className={`max-w-[85%] p-3 rounded-xl text-xs sm:text-[13px] leading-relaxed space-y-2 ${
                        isAI
                          ? 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-2xs'
                          : 'bg-[#81A6C6] text-white rounded-tr-none shadow-2xs'
                      }`}
                    >
                      {/* Clean message text without asterisks or markdown stars */}
                      <p className="leading-relaxed whitespace-pre-line font-normal">
                        {msg.text}
                      </p>

                      {/* Optional Interactive Action Button */}
                      {msg.actionButton && (
                        <button
                          type="button"
                          onClick={() => handleActionButtonClick(msg.actionButton)}
                          className="mt-1 w-full py-1.5 px-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                        >
                          <span>{isArabic ? msg.actionButton.labelAr : msg.actionButton.labelEn}</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}

                      {/* Bottom tools */}
                      <div
                        className={`flex items-center justify-between pt-0.5 text-[10px] ${
                          isAI ? 'text-slate-400' : 'text-blue-100'
                        }`}
                      >
                        <span>{msg.timestamp}</span>
                        {isAI && msg.text && (
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => speakText(msg.text)}
                              className="hover:text-slate-700 transition-colors p-0.5"
                              title={isArabic ? 'قراءة صوتية' : 'Read Aloud'}
                            >
                              <Volume2 className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCopyMessage(msg.id, msg.text)}
                              className="hover:text-slate-700 transition-colors p-0.5 flex items-center gap-0.5"
                              title={isArabic ? 'نسخ النص' : 'Copy'}
                            >
                              {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Streaming / Typing Indicator */}
              {isTyping && (
                <div className="flex gap-2 items-center">
                  <div className="w-6 h-6 rounded-lg bg-[#81A6C6] text-white flex items-center justify-center shrink-0">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                  <div className="p-2.5 bg-white border border-slate-200 rounded-xl rounded-tl-none shadow-2xs flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#81A6C6] animate-bounce" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#81A6C6] animate-bounce [animation-delay:0.15s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#81A6C6] animate-bounce [animation-delay:0.3s]" />
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-1.5 shrink-0"
            >
              <input
                ref={inputRef}
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  isArabic
                    ? 'اكتب سؤالك عن مِدْرار...'
                    : 'Ask about Midrar...'
                }
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#81A6C6]/30 focus:border-[#81A6C6] transition-all"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || isTyping}
                className="p-2 bg-[#81A6C6] hover:bg-[#6f95b7] text-white rounded-xl disabled:opacity-40 shadow-xs transition-all cursor-pointer shrink-0"
                title={isArabic ? 'إرسال' : 'Send'}
              >
                <Send className="w-4 h-4 rtl:rotate-180" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
