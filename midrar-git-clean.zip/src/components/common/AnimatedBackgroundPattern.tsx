import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  baseAlpha: number;
  pulseSpeed: number;
  pulseVal: number;
}

export const AnimatedBackgroundPattern: React.FC<{ className?: string }> = ({ className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = container.offsetWidth || 1000);
    let height = (canvas.height = container.offsetHeight || 600);

    const handleResize = () => {
      if (!canvas || !container) return;
      const rect = container.getBoundingClientRect();
      width = canvas.width = rect.width || container.offsetWidth || 1000;
      height = canvas.height = rect.height || container.offsetHeight || 600;
    };

    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });
    resizeObserver.observe(container);

    // Harmonious, calm Midrar palette with clear contrast
    const colors = ['#81A6C6', '#4B6B94', '#60A5FA', '#AACDDC', '#D2C4B4'];

    // Balanced, elegant particle count (32 particles)
    const particleCount = 32;
    const particles: Particle[] = [];

    for (let i = 0; i < particleCount; i++) {
      const baseAlpha = Math.random() * 0.3 + 0.45; // Visible & clean opacity (0.45 - 0.75)
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.28,
        vy: (Math.random() - 0.5) * 0.28,
        radius: Math.random() * 1.8 + 1.4, // 1.4px - 3.2px
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: baseAlpha,
        baseAlpha: baseAlpha,
        pulseSpeed: 0.018 + Math.random() * 0.02,
        pulseVal: Math.random() * Math.PI * 2,
      });
    }

    let mouseX = -1000;
    let mouseY = -1000;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
      mouseX = -1000;
      mouseY = -1000;
    };

    window.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // 1. Subtle, gentle constellation lines
      const maxDistance = 125;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxDistance) {
            const lineAlpha = (1 - dist / maxDistance) * 0.28; // Clearer, crisp lines
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(100, 140, 175, ${lineAlpha})`;
            ctx.lineWidth = 0.9;
            ctx.stroke();
          }
        }

        // Soft magnetic link to mouse
        if (mouseX > 0 && mouseY > 0) {
          const mdx = particles[i].x - mouseX;
          const mdy = particles[i].y - mouseY;
          const mDist = Math.sqrt(mdx * mdx + mdy * mdy);
          if (mDist < 140) {
            const mAlpha = (1 - mDist / 140) * 0.4;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(mouseX, mouseY);
            ctx.strokeStyle = `rgba(129, 166, 198, ${mAlpha})`;
            ctx.lineWidth = 1.0;
            ctx.stroke();
          }
        }
      }

      // 2. Draw serene floating particles
      particles.forEach((p) => {
        p.pulseVal += p.pulseSpeed;
        const currentAlpha = p.baseAlpha + Math.sin(p.pulseVal) * 0.12;

        // Subtle mouse push
        const mdx = p.x - mouseX;
        const mdy = p.y - mouseY;
        const mDist = Math.sqrt(mdx * mdx + mdy * mdy);
        if (mDist < 100 && mDist > 0) {
          const force = (100 - mDist) / 100;
          p.x += (mdx / mDist) * force * 1.0;
          p.y += (mdy / mDist) * force * 1.0;
        }

        p.x += p.vx;
        p.y += p.vy;

        // Wrap softly
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;
        if (p.y < -10) p.y = height + 10;
        if (p.y > height + 10) p.y = -10;

        // Core distinct particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0.25, Math.min(currentAlpha, 0.85));
        ctx.fill();
        ctx.globalAlpha = 1.0;
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={`absolute -inset-x-4 sm:-inset-x-8 -inset-y-6 pointer-events-none overflow-hidden select-none z-0 ${className}`}
    >
      {/* 1. Refined, distinct dot grid */}
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.095]"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern
            id="hero-grid-pattern"
            width="32"
            height="32"
            patternUnits="userSpaceOnUse"
          >
            <circle cx="16" cy="16" r="1.3" fill="#4B6B94" />
          </pattern>
          <radialGradient id="hero-mask-radial" cx="50%" cy="50%" r="65%">
            <stop offset="0%" stopColor="#000" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#000" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#000" stopOpacity="0.05" />
          </radialGradient>
          <mask id="hero-grid-mask">
            <rect width="100%" height="100%" fill="url(#hero-mask-radial)" />
          </mask>
        </defs>
        <rect width="100%" height="100%" fill="url(#hero-grid-pattern)" mask="url(#hero-grid-mask)" />
      </svg>

      {/* 2. Distinct, smooth constellation canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-95" />

      {/* 3. Balanced ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[540px] h-[340px] bg-gradient-to-tr from-[#81A6C6]/18 via-[#AACDDC]/15 to-[#F3E3D0]/22 blur-3xl rounded-full -z-10 pointer-events-none" />

      {/* 4. Elegant decorative orbital rings */}
      <motion.div
        animate={{
          rotate: [0, 360],
          scale: [0.98, 1.02, 0.98],
        }}
        transition={{ duration: 50, repeat: Infinity, ease: 'linear' }}
        className="absolute -top-12 -right-12 w-64 h-64 border border-[#81A6C6]/22 rounded-full pointer-events-none -z-10"
      />

      <motion.div
        animate={{
          rotate: [360, 0],
          scale: [1.02, 0.98, 1.02],
        }}
        transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
        className="absolute -bottom-16 -left-12 w-80 h-80 border border-[#D2C4B4]/25 rounded-full pointer-events-none -z-10"
      />
    </div>
  );
};

