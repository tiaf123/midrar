import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, X, Smartphone, Share, PlusSquare, Check } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const InstallPWAButton: React.FC = () => {
  const { isArabic } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if app is already running as installed standalone PWA
    const inStandaloneMode = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
    if (inStandaloneMode) {
      setIsStandalone(true);
      return;
    }

    // Check iOS Safari
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIphoneOrIpad = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIphoneOrIpad);

    // Native Chrome / Android / Desktop Install Event listener
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // If on iOS Safari, show prompt after 2.5 seconds
    if (isIphoneOrIpad) {
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 2500);
      return () => clearTimeout(timer);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setShowPrompt(false);
      }
      setDeferredPrompt(null);
    } else if (isIOS) {
      setShowIOSInstructions(true);
    } else {
      setShowPrompt(false);
    }
  };

  if (isStandalone || !showPrompt) return null;

  return (
    <>
      <AnimatePresence>
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 260, damping: 25 }}
          className="fixed bottom-20 md:bottom-6 start-4 z-50 max-w-sm w-[calc(100%-2rem)]"
        >
          <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-3xl p-4 shadow-2xl text-white flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <img
                src="/midrar.png"
                alt="Midrar App Logo"
                className="w-11 h-11 rounded-2xl object-cover border border-slate-700 shadow-sm shrink-0"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-extrabold text-xs text-white truncate">
                    {isArabic ? 'تثبيت تطبيق مِدْرار' : 'Install Midrar App'}
                  </h4>
                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/40">
                    APP
                  </span>
                </div>
                <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                  {isArabic ? 'أيقونة باللوقو وتجربة تطبيق سريعة' : 'Instant access & app icon'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleInstallClick}
                className="px-3.5 py-2 bg-gradient-to-r from-[#81A6C6] to-[#608bb1] hover:from-[#7298b9] hover:to-[#527eab] text-white font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isArabic ? 'تثبيت' : 'Install'}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowPrompt(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* iOS Instructions Modal */}
      {showIOSInstructions && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl text-slate-800 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <img src="/midrar.png" alt="" className="w-9 h-9 rounded-xl object-cover" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  {isArabic ? 'تثبيت التطبيق على iPhone / iPad' : 'Add to iOS Home Screen'}
                </h3>
              </div>
              <button
                onClick={() => setShowIOSInstructions(false)}
                className="w-8 h-8 rounded-xl text-slate-400 hover:bg-slate-100 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <div className="p-3 bg-slate-50 rounded-2xl flex items-center gap-3 border border-slate-200">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
                  1
                </div>
                <div className="flex-1">
                  <span>{isArabic ? 'اضغط على زر المشاركة' : 'Tap the Share button'}</span>
                  <div className="inline-flex items-center gap-1 font-bold text-blue-600 mx-1">
                    <Share className="w-4 h-4 inline" />
                  </div>
                  <span>{isArabic ? 'أسفل المتصفح' : 'at bottom of Safari'}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl flex items-center gap-3 border border-slate-200">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-sm shrink-0">
                  2
                </div>
                <div className="flex-1">
                  <span>{isArabic ? 'اختر ' : 'Select '}</span>
                  <strong className="text-slate-900">{isArabic ? '"إضافة إلى الشاشة الرئيسية"' : '"Add to Home Screen"'}</strong>
                  <div className="inline-flex items-center gap-1 text-slate-700 mx-1 font-bold">
                    <PlusSquare className="w-4 h-4 inline text-slate-700" />
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setShowIOSInstructions(false);
                setShowPrompt(false);
              }}
              className="w-full py-3 bg-[#81A6C6] text-white font-bold text-xs rounded-2xl shadow-sm cursor-pointer"
            >
              {isArabic ? 'حسناً، فهمت' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
