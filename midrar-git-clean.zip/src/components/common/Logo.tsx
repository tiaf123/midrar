import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showSlogan?: boolean;
  className?: string;
  variant?: 'default' | 'inverted';
  onClick?: () => void;
}

export const LOGO_URL = "/midrar.png";

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  showSlogan = false,
  className = '',
  variant = 'default',
  onClick,
}) => {
  const { isArabic } = useLanguage();

  const sizeClasses = {
    sm: 'h-9 w-auto',
    md: 'h-13 w-auto',
    lg: 'h-16 w-auto',
    xl: 'h-24 w-auto',
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  const isLight = variant === 'inverted';

  return (
    <div
      id="app-brand-logo"
      onClick={onClick}
      className={`inline-flex items-center gap-3 select-none ${onClick ? 'cursor-pointer group' : ''} ${className}`}
    >
      <div className="relative flex items-center justify-center">
        {/* Soft atmospheric backlight halo */}
        <div className="absolute inset-0 bg-[#81A6C6]/25 blur-md rounded-full transform group-hover:scale-110 transition-transform duration-300 pointer-events-none" />
        
        {/* Logo Image */}
        <img
          src={LOGO_URL}
          alt="شعار مِدْرار - Midrar Logo"
          referrerPolicy="no-referrer"
          className={`${sizeClasses[size]} object-contain relative z-10 transition-transform duration-300 group-hover:scale-105 drop-shadow-sm rounded-lg`}
          loading="eager"
        />
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-extrabold tracking-tight ${isLight ? 'text-white' : 'text-slate-800'} ${textSizes[size]}`}>
              {isArabic ? 'مِدْرار' : 'Midrar'}
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#81A6C6] inline-block animate-pulse" />
          </div>
          {showSlogan && (
            <span className={`text-xs font-medium ${isLight ? 'text-slate-300' : 'text-slate-500'} max-w-[200px] truncate leading-tight`}>
              {isArabic ? 'تعليم يفهمك وينمو معك' : 'Understands & Grows With You'}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
