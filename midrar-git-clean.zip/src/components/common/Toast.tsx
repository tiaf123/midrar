import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { motionTokens, getDirectionalOffset } from '../../motion/tokens';

const ToastItem: React.FC<{
  toast: { id: string; message: string; type: 'success' | 'error' | 'info' | 'warning' };
  onRemove: (id: string) => void;
}> = ({ toast, onRemove }) => {
  const { isArabic } = useLanguage();
  const [isPaused, setIsPaused] = useState(false);

  const isSuccess = toast.type === 'success';
  const isError = toast.type === 'error';
  const isWarning = toast.type === 'warning';

  const offset = getDirectionalOffset(isArabic, 30);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: offset.enterX, scale: 0.95 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: offset.exitX, scale: 0.9 }}
      transition={motionTokens.spring.responsive}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className={`pointer-events-auto relative overflow-hidden p-4 rounded-2xl shadow-xl border backdrop-blur-xl flex items-start gap-3 text-xs sm:text-sm font-medium ${
        isSuccess
          ? 'bg-emerald-50/95 border-emerald-200 text-emerald-900'
          : isError
          ? 'bg-rose-50/95 border-rose-200 text-rose-900'
          : isWarning
          ? 'bg-amber-50/95 border-amber-200 text-amber-900'
          : 'bg-white/95 border-slate-200 text-slate-800'
      }`}
    >
      {isSuccess && <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />}
      {isError && <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />}
      {isWarning && <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />}
      {!isSuccess && !isError && !isWarning && <Info className="w-5 h-5 text-[#81A6C6] shrink-0 mt-0.5" />}

      <p className="flex-1 leading-relaxed">{toast.message}</p>

      <button
        onClick={() => onRemove(toast.id)}
        className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition-colors cursor-pointer"
        aria-label="Close notification"
      >
        <X className="w-4 h-4" />
      </button>

      {/* Auto-dismiss Countdown Progress line at bottom */}
      <motion.div
        initial={{ width: '100%' }}
        animate={{ width: isPaused ? undefined : '0%' }}
        transition={{ duration: 4.2, ease: 'linear' }}
        className={`absolute bottom-0 inset-x-0 h-1 ${
          isSuccess
            ? 'bg-emerald-400'
            : isError
            ? 'bg-rose-400'
            : isWarning
            ? 'bg-amber-400'
            : 'bg-[#81A6C6]'
        }`}
      />
    </motion.div>
  );
};

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  return (
    <div
      id="app-toast-container"
      className="fixed bottom-20 sm:bottom-6 inset-x-4 sm:inset-x-auto sm:end-6 z-50 flex flex-col gap-2.5 max-w-md w-full pointer-events-none"
    >
      <AnimatePresence mode="popLayout">
        {toasts.map((toast) => (
          <ToastItem key={toast.id} toast={toast} onRemove={removeToast} />
        ))}
      </AnimatePresence>
    </div>
  );
};

export const Toast = ToastContainer;
