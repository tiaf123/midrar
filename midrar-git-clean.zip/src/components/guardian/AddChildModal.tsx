import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  UserPlus,
  KeyRound,
  Copy,
  Check,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';

export const AddChildModal: React.FC = () => {
  const { activeModal, setActiveModal, addNewStudentToFamily, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [studentName, setStudentName] = useState('');
  const [gradeLevel, setGradeLevel] = useState('الصف الخامس الابتدائي');
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (activeModal !== 'add-child') return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) {
      showToast(isArabic ? 'يرجى كتابة اسم الطالب' : 'Please enter student name', 'warning');
      return;
    }
    const created = addNewStudentToFamily(studentName, gradeLevel);
    setGeneratedCode(created.studentCode);
  };

  const handleCopyCode = () => {
    if (generatedCode) {
      navigator.clipboard.writeText(generatedCode);
      setCopied(true);
      showToast(isArabic ? 'تم نسخ رمز الطالب بنجاح' : 'Student code copied');
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleClose = () => {
    setStudentName('');
    setGeneratedCode(null);
    setActiveModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50/50 via-white to-blue-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">{t.guardian.addNewStudent}</h3>
              <p className="text-xs text-slate-500">
                {isArabic ? 'إنشاء حساب آمن ورمز دخول للطالب' : 'Provision safe account & login code'}
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form or Success View */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
          {!generatedCode ? (
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {isArabic ? 'اسم الابن / الطالب الكامل' : 'Student Full Name'}
                </label>
                <input
                  type="text"
                  required
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="مثال: ريان عبد الله الرشيد"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {isArabic ? 'المرحلة الدراسية' : 'Grade Level'}
                </label>
                <select
                  value={gradeLevel}
                  onChange={(e) => setGradeLevel(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                >
                  <option value="الصف الرابع الابتدائي">{isArabic ? 'الصف الرابع الابتدائي' : '4th Grade'}</option>
                  <option value="الصف الخامس الابتدائي">{isArabic ? 'الصف الخامس الابتدائي' : '5th Grade'}</option>
                  <option value="الصف السادس الابتدائي">{isArabic ? 'الصف السادس الابتدائي' : '6th Grade'}</option>
                  <option value="الصف الأول المتوسط">{isArabic ? 'الصف الأول المتوسط' : '7th Grade'}</option>
                  <option value="الصف الثاني المتوسط">{isArabic ? 'الصف الثاني المتوسط' : '8th Grade'}</option>
                  <option value="الصف الثالث المتوسط">{isArabic ? 'الصف الثالث المتوسط' : '9th Grade'}</option>
                </select>
              </div>

              <div className="p-3.5 bg-blue-50/70 border border-blue-100 rounded-2xl flex items-start gap-2.5 text-xs text-blue-900">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  {isArabic
                    ? 'سيتم ربط حساب الطالب بحسابك مباشرة، وإنشاء رمز دخول رقمي آمن لا يتطلب بريداً إلكترونياً.'
                    : 'The student account will be safely linked to your family portal with a dedicated student code.'}
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <span>{isArabic ? 'إنشاء حساب الطالب وإصدار الرمز' : 'Generate Student Account'}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </form>
          ) : (
            <div className="text-center space-y-4 py-2">
              <div className="w-14 h-14 rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <KeyRound className="w-7 h-7" />
              </div>

              <div className="space-y-1">
                <h4 className="text-base font-bold text-slate-800">{t.guardian.studentCodeGenerated}</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {isArabic
                    ? `تم توليد الرمز وربطه بالداتابيز باسم الطالب (${studentName}) وحفظه في حسابك بشكل دائم.`
                    : `Code generated and permanently linked to ${studentName}'s profile in your family vault.`}
                </p>
              </div>

              {/* Code Display Box */}
              <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-between">
                <span className="text-2xl font-mono font-extrabold tracking-widest text-emerald-400">
                  {generatedCode}
                </span>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? (isArabic ? 'تم النسخ' : 'Copied') : (isArabic ? 'نسخ الرمز' : 'Copy')}</span>
                </button>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2 text-start">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  {isArabic
                    ? 'يمكنك الرجوع لهذا الرمز في أي وقت من خلال زر "رموز أبنائك" في لوحة ولي الأمر.'
                    : 'You can access this code anytime from the "Children Access Codes" vault in your dashboard.'}
                </span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    handleClose();
                    setActiveModal('children-codes');
                  }}
                  className="flex-1 py-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold text-xs rounded-xl shadow-2xs cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isArabic ? 'رموز أبنائك' : 'Children Codes'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  {t.common.finish}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
