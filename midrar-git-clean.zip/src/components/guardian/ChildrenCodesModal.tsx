import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  KeyRound,
  Copy,
  Check,
  ShieldCheck,
  UserPlus,
  LogIn,
  Sparkles,
  Smartphone,
  ExternalLink
} from 'lucide-react';

export const ChildrenCodesModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    students,
    allStudents,
    loginWithStudentCode,
    showToast
  } = useApp();
  const { isArabic, t } = useLanguage();

  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (activeModal !== 'children-codes') return null;

  const childrenList = students || allStudents || [];

  const handleCopy = (code: string, name: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    showToast(
      isArabic
        ? `تم نسخ رمز الطالب (${name}): ${code}`
        : `Student code for ${name} copied: ${code}`,
      'success'
    );
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleStudentDirectLogin = (code: string) => {
    loginWithStudentCode(code);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-lg">
                {isArabic ? 'رموز وبطاقات دخول أبنائك' : 'Children Access Codes'}
              </h3>
              <p className="text-xs text-slate-500">
                {isArabic
                  ? 'رموز الدخول المباشرة الآمنة المربوطة بملف كل ابن بشكل دائم'
                  : 'Permanent direct student codes linked to each child'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          {/* Top Info Banner */}
          <div className="p-4 bg-emerald-50/80 border border-emerald-200/80 rounded-2xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs text-emerald-950 space-y-1 leading-relaxed">
              <p className="font-bold">
                {isArabic
                  ? 'كيف يدخل ابنك المنصة؟'
                  : 'How does your child log in?'}
              </p>
              <p className="text-emerald-800">
                {isArabic
                  ? 'لا يحتاج ابنك إلى بريد إلكتروني أو كلمة مرور. يكفيه فتح المنصة واختيار "طالب" ثم إدخال رمزه الخاص ليدخل فوراً إلى خطته ودروسه التفاعلية ومساعده الذكي.'
                  : 'Your child does not need an email or password. Simply open Midrar, select Student, and enter their unique code to access their personalized curriculum.'}
              </p>
            </div>
          </div>

          {/* Children List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                {isArabic ? `الأبناء المسجلون (${childrenList.length})` : `Registered Children (${childrenList.length})`}
              </span>

              <button
                type="button"
                onClick={() => setActiveModal('add-child')}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1.5 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{isArabic ? '+ إضافة ابن جديد' : '+ Add Child'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3.5">
              {childrenList.map((child) => {
                const isCopied = copiedCode === child.studentCode;
                return (
                  <div
                    key={child.id}
                    className="p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-white border border-slate-200/90 shadow-xs hover:border-emerald-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                  >
                    {/* Child details */}
                    <div className="flex items-center gap-3.5 min-w-0">
                      <img
                        src={child.avatarUrl}
                        alt={child.name}
                        className="w-13 h-13 rounded-2xl object-cover border border-slate-200 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-slate-900 text-sm truncate">
                            {child.name}
                          </h4>
                          <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 font-semibold text-[10px] border border-blue-100">
                            {child.gradeLevel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {isArabic
                            ? `نسبة الإتقان: ${child.overallProgress}% | شعلة التعلم: ${child.currentStreakDays || child.streakDays || 1} أيام`
                            : `Mastery: ${child.overallProgress}% | Streak: ${child.currentStreakDays || child.streakDays || 1} days`}
                        </p>
                      </div>
                    </div>

                    {/* Code Box & Actions */}
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                      {/* Code Badge */}
                      <div className="px-3.5 py-2 bg-slate-900 rounded-xl border border-slate-800 flex items-center gap-2">
                        <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="font-mono font-extrabold text-emerald-400 text-sm tracking-wider">
                          {child.studentCode}
                        </span>
                      </div>

                      {/* Copy button */}
                      <button
                        type="button"
                        onClick={() => handleCopy(child.studentCode, child.name)}
                        className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                          isCopied
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                        title={isArabic ? 'نسخ الرمز' : 'Copy code'}
                      >
                        {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{isCopied ? (isArabic ? 'تم النسخ' : 'Copied') : (isArabic ? 'نسخ' : 'Copy')}</span>
                      </button>

                      {/* Test Login Button */}
                      <button
                        type="button"
                        onClick={() => handleStudentDirectLogin(child.studentCode)}
                        className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                        title={isArabic ? 'تجربة الدخول كطالب بهذا الرمز' : 'Test login as student'}
                      >
                        <LogIn className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{isArabic ? 'دخول كطالب' : 'Login'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Tip Footer */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-slate-500" />
              <span>
                {isArabic
                  ? 'يمكن للطالب حفظ هذا الرمز في جهازه أو كتابته في ورقة للدخول اليومي السريع.'
                  : 'Students can bookmark this code on their tablet for quick daily learning access.'}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setActiveModal('add-child')}
            className="px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-2 cursor-pointer shadow-2xs"
          >
            <UserPlus className="w-4 h-4 text-emerald-600" />
            <span>{isArabic ? 'إضافة ابن آخر' : 'Add Another Child'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModal(null)}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
          >
            {isArabic ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
