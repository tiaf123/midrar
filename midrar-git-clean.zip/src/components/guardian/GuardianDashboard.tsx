import React from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  Users,
  UserPlus,
  Sparkles,
  FileText,
  Clock,
  TrendingUp,
  Star,
  MessageSquare,
  ShieldCheck,
  Award,
  ChevronRight,
  Eye,
  Headphones,
  BookOpen,
  Wrench,
  KeyRound,
  Copy,
  Check,
  LogIn
} from 'lucide-react';

export const GuardianDashboard: React.FC = () => {
  const {
    students,
    allStudents,
    activeStudent,
    setActiveStudentId,
    setActiveModal,
    teachersCatalog,
    setSelectedTeacherId,
    setActiveConversationId,
    loginWithStudentCode,
    showToast
  } = useApp();
  const { isArabic, t } = useLanguage();
  const [copiedCode, setCopiedCode] = React.useState<string | null>(null);

  const studentList = students || allStudents || [];
  const currentActive = activeStudent || studentList[0];

  const handleCopyCode = (code: string, name: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    showToast(
      isArabic
        ? `تم نسخ رمز الطالب (${name}): ${code}`
        : `Student code for ${name} copied: ${code}`,
      'success'
    );
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const visualScore = currentActive?.modalityScores?.visual ?? currentActive?.learningPreferences?.visual ?? 38;
  const interactiveScore = currentActive?.modalityScores?.interactive_kinesthetic ?? currentActive?.learningPreferences?.interactiveHandsOn ?? 32;
  const auditoryScore = currentActive?.modalityScores?.auditory ?? currentActive?.learningPreferences?.auditory ?? 18;
  const streak = currentActive?.streakDays ?? currentActive?.currentStreakDays ?? 7;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Children Selector */}
      <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 rounded-3xl p-6 sm:p-8 border border-emerald-200/60 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
              {isArabic ? 'بوابة ولي الأمر والأسرة' : 'Family & Guardian Hub'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {isArabic ? 'متابعة وتوجيه مسيرة الأبناء التعليمية' : 'Child Growth & Academic Tracking'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
            {isArabic
              ? 'تابع تقدم أبنائك، واطلع على تقارير الذكاء الاصطناعي الأسبوعية، وتواصل مع الكادر التعليمي.'
              : 'Monitor your children’s mastery, generate weekly AI synthesis reports, and connect with faculty.'}
          </p>
        </div>

        {/* Top actions */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          <button
            type="button"
            onClick={() => setActiveModal('children-codes')}
            className="px-5 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-2xl shadow-sm flex items-center gap-2 cursor-pointer transition-all ring-2 ring-emerald-500/30"
          >
            <KeyRound className="w-4 h-4 text-emerald-200" />
            <span>{isArabic ? 'رموز دخول أبنائك' : 'Children Access Codes'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModal('parent-report')}
            className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-2xl shadow-sm flex items-center gap-2 cursor-pointer transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>{t.guardian.generateWeeklyReport}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModal('add-child')}
            className="px-5 py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 font-bold text-xs rounded-2xl shadow-xs flex items-center gap-2 cursor-pointer transition-all"
          >
            <UserPlus className="w-4 h-4 text-emerald-600" />
            <span>{t.guardian.addNewStudent}</span>
          </button>
        </div>
      </div>

      {/* 2. Permanent Children Access Codes Vault Section */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-900 text-base">
                  {isArabic ? 'رموز وبطاقات دخول الأبناء (محفوظة في حسابك)' : 'Permanent Children Access Codes'}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                  {studentList.length} {isArabic ? 'أبناء مرتبطون' : 'Children'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {isArabic
                  ? 'رموز دخول رقمية آمنة تتولد تلقائياً بالداتابيز وترتبط بملف كل ابن للرجوع إليها في أي وقت.'
                  : 'Direct unique child access keys linked permanently to each child profile.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveModal('children-codes')}
              className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold text-xs rounded-xl border border-emerald-200 flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isArabic ? 'عرض كافة الرموز والبطاقات' : 'View Full Cards'}</span>
            </button>
          </div>
        </div>

        {/* Children Cards Grid */}
        {studentList.length === 0 ? (
          <div className="p-8 sm:p-12 rounded-3xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-xs">
              <UserPlus className="w-8 h-8" />
            </div>
            <div className="max-w-md mx-auto space-y-1">
              <h3 className="font-extrabold text-slate-900 text-lg">
                {isArabic ? 'لا يوجد أطفال مضافون في حسابك بعد' : 'No children added to your account yet'}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                {isArabic
                  ? 'قم بإضافة طفلك الأول للبدء في توليد بطاقة الدخول الرقمية (STU-XXXX) وتتبع تقدمه الأكاديمي وتوصيات الذكاء الاصطناعي.'
                  : 'Add your first child to generate their COPPA-safe login code (STU-XXXX) and start tracking their academic journey.'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveModal('add-child')}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-2xl shadow-sm inline-flex items-center gap-2 transition-all cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>{isArabic ? 'إضافة طالب جديد للأسرة الآن' : 'Add First Student Now'}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {studentList.map((stu) => {
              const isCopied = copiedCode === stu.studentCode;
              return (
                <div
                  key={stu.id}
                  className="p-4 rounded-2xl bg-gradient-to-b from-slate-50 to-white border border-slate-200 hover:border-emerald-300 transition-all flex flex-col justify-between gap-3 group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={stu.avatarUrl}
                        alt={stu.name}
                        className="w-11 h-11 rounded-xl object-cover border border-slate-200"
                      />
                      <div>
                        <h4 className="font-bold text-slate-900 text-xs group-hover:text-emerald-800 transition-colors">
                          {stu.name}
                        </h4>
                        <p className="text-[10px] text-slate-500">{stu.gradeLevel}</p>
                      </div>
                    </div>

                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200/80">
                      {isArabic ? 'مرتبط بحسابك' : 'Linked'}
                    </span>
                  </div>

                  {/* The Code Box */}
                  <div className="p-3 bg-slate-900 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-emerald-400" />
                      <span className="font-mono font-extrabold text-emerald-400 text-sm tracking-wider">
                        {stu.studentCode}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCopyCode(stu.studentCode, stu.name)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isCopied ? (isArabic ? 'تم' : 'Copied') : (isArabic ? 'نسخ' : 'Copy')}</span>
                    </button>
                  </div>

                  {/* Direct quick login or switch */}
                  <div className="flex items-center justify-between pt-1 text-[11px]">
                    <span className="text-slate-400">
                      {isArabic ? 'إتقان عام: ' : 'Mastery: '}
                      <strong className="text-emerald-700">{stu.overallProgress}%</strong>
                    </span>

                    <button
                      type="button"
                      onClick={() => loginWithStudentCode(stu.studentCode)}
                      className="text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>{isArabic ? 'تجربة الدخول كطالب' : 'Login as child'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 3. Children Switcher Bar */}
      {studentList.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            {t.guardian.myChildren}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {studentList.map((stu) => {
              const isSelected = currentActive && stu.id === currentActive.id;
              return (
                <div
                  key={stu.id}
                  onClick={() => setActiveStudentId(stu.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-emerald-50/70 border-emerald-500 shadow-xs ring-1 ring-emerald-500'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={stu.avatarUrl}
                      alt={stu.name}
                      className="w-11 h-11 rounded-xl object-cover"
                    />
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs">{stu.name}</h4>
                      <p className="text-[10px] text-slate-500">{stu.gradeLevel}</p>
                      <span className="text-[10px] text-emerald-700 font-semibold font-mono">
                        {stu.studentCode}
                      </span>
                    </div>
                  </div>

                  <div className="text-end">
                    <span className="text-xs font-extrabold text-emerald-700">{stu.overallProgress}%</span>
                    <p className="text-[9px] text-slate-400">{isArabic ? 'إتقان عام' : 'Mastery'}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. Selected Child Analytics & Modality breakdown */}
      {currentActive && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Metric Cards */}
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase">{t.guardian.masteryRate}</span>
                <p className="text-2xl font-extrabold text-emerald-600">{currentActive.overallProgress}%</p>
                <span className="text-[10px] text-emerald-700 font-medium">+8% {isArabic ? 'هذا الأسبوع' : 'this week'}</span>
              </div>

              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase">{t.guardian.attendanceCommitment}</span>
                <p className="text-2xl font-extrabold text-[#81A6C6]">{currentActive.attendanceRate}%</p>
                <span className="text-[10px] text-blue-700 font-medium">96% {isArabic ? 'حضور منتظم' : 'on-time'}</span>
              </div>

              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase">{t.guardian.weeklyStudyHours}</span>
                <p className="text-2xl font-extrabold text-amber-600">{currentActive.weeklyStudyHours}h</p>
                <span className="text-[10px] text-amber-700 font-medium">{streak} {isArabic ? 'أيام متتالية' : 'day streak'}</span>
              </div>
            </div>

            {/* Modalities summary */}
            <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h4 className="font-bold text-slate-900 text-xs flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>{isArabic ? `توزيع الاستجابة لأساليب التعلم (${currentActive.name})` : `Modality Response (${currentActive.name})`}</span>
              </h4>

              <div className="space-y-3">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-600 flex items-center gap-1.5"><Eye className="w-3.5 h-3.5 text-blue-500" /> {t.test.visualModality}</span>
                    <span className="text-blue-700 font-bold">{visualScore}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-blue-500 h-full rounded-full" style={{ width: `${visualScore}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-600 flex items-center gap-1.5"><Wrench className="w-3.5 h-3.5 text-purple-500" /> {t.test.interactiveHandsOnModality}</span>
                    <span className="text-purple-700 font-bold">{interactiveScore}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-purple-500 h-full rounded-full" style={{ width: `${interactiveScore}%` }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-600 flex items-center gap-1.5"><Headphones className="w-3.5 h-3.5 text-amber-500" /> {t.test.auditoryModality}</span>
                    <span className="text-amber-700 font-bold">{auditoryScore}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full rounded-full" style={{ width: `${auditoryScore}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Strengths & AI Recommendations for Family */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900 text-xs flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span>{t.guardian.strengthsList}</span>
              </h4>
              <div className="space-y-2">
                {currentActive.strengths.map((st, i) => (
                  <div key={i} className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 text-xs font-medium text-emerald-900 flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                    <span>{isArabic ? st.ar : st.en}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-2">
              <button
                type="button"
                onClick={() => setActiveModal('parent-report')}
                className="w-full py-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold text-xs rounded-xl border border-emerald-200 flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>{t.guardian.generateWeeklyReport}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Verified Faculty Directory (Chat & Rating) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-slate-900 text-base">
            {isArabic ? 'معلمو أبنائك المعتمدون' : 'Assigned Faculty & Teachers'}
          </h3>
        </div>

        {teachersCatalog.length === 0 ? (
          <div className="p-8 sm:p-10 rounded-3xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto shadow-xs">
              <Users className="w-7 h-7" />
            </div>
            <div className="max-w-md mx-auto space-y-1">
              <h4 className="font-extrabold text-slate-900 text-base">
                {isArabic ? 'لا يوجد معلمون مسجلون أو مرتبطون بعد' : 'No teachers linked yet'}
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                {isArabic
                  ? 'سيظهر معلمو أبنائك هنا فور انضمام المعلمين للمنصة أو ربطهم بالصفوف الدراسية.'
                  : 'Your children’s assigned teachers will appear here as faculty join and link to their classes.'}
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {teachersCatalog.map((tch) => (
              <div
                key={tch.id}
                className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between"
              >
                <div className="flex items-start gap-3">
                  <img
                    src={tch.avatarUrl}
                    alt={tch.name}
                    className="w-14 h-14 rounded-2xl object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h4 className="font-bold text-slate-900 text-xs truncate">{tch.name}</h4>
                    <p className="text-[10px] text-slate-400 truncate">{isArabic ? tch.titleAr : tch.titleEn}</p>
                    <div className="flex items-center gap-1 text-amber-500 font-bold text-xs mt-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{tch.rating}</span>
                      <span className="text-[10px] text-slate-400 font-normal">({tch.reviewsCount})</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveConversationId('conv-1');
                      setActiveModal('chat');
                    }}
                    className="flex-1 py-2 bg-slate-100 hover:bg-slate-200/80 text-slate-800 font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{isArabic ? 'محادثة' : 'Chat'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedTeacherId(tch.id)}
                    className="py-2 px-3 bg-amber-50 hover:bg-amber-100 text-amber-900 font-semibold text-xs rounded-xl border border-amber-200 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Star className="w-3.5 h-3.5 text-amber-600" />
                    <span>{t.guardian.rateTeacher}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
