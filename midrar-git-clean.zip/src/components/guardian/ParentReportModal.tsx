import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  FileText,
  Sparkles,
  Printer,
  TrendingUp,
  BrainCircuit,
  HeartHandshake
} from 'lucide-react';

export const ParentReportModal: React.FC = () => {
  const { activeModal, setActiveModal, activeStudent } = useApp();
  const { isArabic, t } = useLanguage();

  const studentName = activeStudent?.name || (isArabic ? 'الطالب' : 'Student');
  const studentGrade = activeStudent?.gradeLevel || '';

  const [isGenerating, setIsGenerating] = useState(false);
  const [reportData, setReportData] = useState<{
    summaryAr: string;
    summaryEn: string;
    strengthsAr: string[];
    strengthsEn: string[];
    homeAdviceAr: string[];
    homeAdviceEn: string[];
  } | null>({
    summaryAr: `أظهر ${studentName} تفوقاً ملموساً هذا الأسبوع في مفاهيم الهندسة والعلوم الطبيعية، مع التزام عالي بنسبة 96% ومعدل دراسة أسبوعي 14.5 ساعة. الاستجابة للمسار البصري والتطبيقي كانت عاملاً حاسماً في سرعة الاستيعاب.`,
    summaryEn: `${studentName} demonstrated notable growth this week across Geometry and Natural Science, maintaining a 96% attendance rate and 14.5 weekly study hours. High engagement with visual and interactive tracks drove strong concept retention.`,
    strengthsAr: [
      "إتقان حساب نظرية فيثاغورس بنسبة 95%",
      "المثابرة في حل التحديات المعملية وتجارب الدفع",
      "الاستخدام الإيجابي لتلميحات المساعد الذكي دون استسلام"
    ],
    strengthsEn: [
      "95% score on Pythagorean Theorem problem set",
      "High curiosity and persistence in physical science labs",
      "Effective use of smart AI hints to overcome math roadblocks"
    ],
    homeAdviceAr: [
      "تشجيع الطالب على شرح المسائل الرياضية لكم بالرسم على ورقة خارجية لتثبيت المعلومة.",
      "تخصيص 15 دقيقة بعد كل جلسة دراسية لمناقشة الأفكار شفهياً في جو عائلي مريح.",
      "مكافأة الالتزام بالاستمرار في شعلة الأيام المتواصلة (7 أيام حالياً)."
    ],
    homeAdviceEn: [
      "Encourage the student to explain math concepts by drawing them on paper for you.",
      "Set aside 15 minutes of relaxed dialogue after study sessions to reinforce takeaways.",
      "Celebrate the 7-day study streak milestone to maintain positive momentum."
    ]
  });

  if (activeModal !== 'parent-report') return null;

  const handleGenerateAiReport = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/gemini/parent-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: studentName,
          gradeLevel: studentGrade,
          progress: activeStudent?.overallProgress || 0,
          strengths: activeStudent?.strengths?.map((s) => s.ar) || [],
          improvementAreas: activeStudent?.improvementAreas?.map((a) => a.ar) || [],
          locale: isArabic ? 'ar' : 'en'
        })
      });
      const data = await res.json();
      if (data.report) {
        setReportData({
          summaryAr: data.report.summaryAr || data.report.summary || data.report.weeklySummary || reportData!.summaryAr,
          summaryEn: data.report.summaryEn || data.report.summary || data.report.weeklySummary || reportData!.summaryEn,
          strengthsAr: data.report.strengthsAr || data.report.key_highlights || data.report.topAchievements || reportData!.strengthsAr,
          strengthsEn: data.report.strengthsEn || data.report.key_highlights || data.report.topAchievements || reportData!.strengthsEn,
          homeAdviceAr: data.report.homeAdviceAr || data.report.home_support_tips || data.report.recommendationsForParents || reportData!.homeAdviceAr,
          homeAdviceEn: data.report.homeAdviceEn || data.report.home_support_tips || data.report.recommendationsForParents || reportData!.homeAdviceEn
        });
      }
    } catch (e) {
      console.error("Error generating AI report:", e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50/50 via-white to-blue-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">
                {isArabic ? 'التقرير الأسبوعي الشامل للأسرة' : 'Weekly Family Progress Report'}
              </h3>
              <p className="text-xs text-slate-500">
                {isArabic ? `تقرير الطالب: ${studentName}` : `Student: ${studentName}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              title={t.guardian.exportReportPdf}
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveModal(null)}
              className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 overflow-y-auto custom-scrollbar space-y-5">
          {/* Key Metrics Bar */}
          <div className="grid grid-cols-3 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200/80 text-center">
            <div>
              <span className="text-[11px] font-medium text-slate-400">{t.guardian.masteryRate}</span>
              <p className="text-lg font-bold text-emerald-600">{activeStudent.overallProgress}%</p>
            </div>
            <div className="border-x border-slate-200">
              <span className="text-[11px] font-medium text-slate-400">{t.guardian.attendanceCommitment}</span>
              <p className="text-lg font-bold text-[#81A6C6]">{activeStudent.attendanceRate}%</p>
            </div>
            <div>
              <span className="text-[11px] font-medium text-slate-400">{t.guardian.weeklyStudyHours}</span>
              <p className="text-lg font-bold text-amber-600">{activeStudent.weeklyStudyHours}h</p>
            </div>
          </div>

          {/* AI Synthesis Summary */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-50/70 to-indigo-50/40 border border-blue-100 space-y-2">
            <h4 className="text-xs font-bold text-blue-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600" />
              {t.guardian.aiParentInsightsTitle}
            </h4>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              {isArabic ? reportData?.summaryAr : reportData?.summaryEn}
            </p>
          </div>

          {/* Strengths List */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              {t.guardian.strengthsList}
            </h4>
            <div className="space-y-1.5">
              {(isArabic ? reportData?.strengthsAr : reportData?.strengthsEn)?.map((str, idx) => (
                <div key={idx} className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100/80 text-xs text-emerald-900 flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                  <span>{str}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Practical Advice for Parents at Home */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <HeartHandshake className="w-4 h-4 text-amber-600" />
              {isArabic ? 'إرشادات عملية موصى بها للأسرة في المنزل:' : 'Actionable Home Support Tips:'}
            </h4>
            <div className="space-y-1.5">
              {(isArabic ? reportData?.homeAdviceAr : reportData?.homeAdviceEn)?.map((adv, idx) => (
                <div key={idx} className="p-3 bg-amber-50/50 rounded-xl border border-amber-100/80 text-xs text-amber-900 flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-1.5 shrink-0" />
                  <span>{adv}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            disabled={isGenerating}
            onClick={handleGenerateAiReport}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isGenerating ? (isArabic ? 'جاري التوليد بمساعد مدرار...' : 'Generating with Midrar Assistant...') : t.guardian.generateWeeklyReport}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModal(null)}
            className="px-5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            {t.common.close}
          </button>
        </div>
      </div>
    </div>
  );
};
