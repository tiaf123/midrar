import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { motionTokens, getDirectionalOffset } from '../../motion/tokens';
import { MotionSection, StaggerContainer, StaggerItem } from '../motion/MotionSection';
import { AnimatedCard } from '../motion/AnimatedCard';
import { AnimatedButton } from '../motion/AnimatedButton';
import { AnimatedBackgroundPattern } from '../common/AnimatedBackgroundPattern';
import { FAQ_ITEMS, FAQ_CATEGORIES, FAQItem } from '../../data/faqData';
import {
  Sparkles,
  ArrowRight,
  Eye,
  Headphones,
  BookOpen,
  Wrench,
  GraduationCap,
  Users,
  School,
  ChevronDown,
  ChevronUp,
  Play,
  CheckCircle2,
  Search,
  HelpCircle,
  X,
  MessageSquare,
  ShieldCheck,
  Cpu,
  Layers,
  ThumbsUp,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setActiveModal, setRole, setSelectedLessonId } = useApp();
  const { isArabic, t } = useLanguage();

  const [activeFaqCategory, setActiveFaqCategory] = useState<string>('all');
  const [faqSearch, setFaqSearch] = useState<string>('');
  const [expandedFaqIds, setExpandedFaqIds] = useState<Set<string>>(
    new Set(['faq-differentiation', 'faq-child-safety-login'])
  );
  const [helpfulFeedback, setHelpfulFeedback] = useState<Record<string, boolean>>({});
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const toggleFaqItem = (id: string) => {
    setExpandedFaqIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleHelpfulClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHelpfulFeedback((prev) => ({ ...prev, [id]: true }));
  };

  // Filtered FAQ Items
  const filteredFaqs = useMemo(() => {
    return FAQ_ITEMS.filter((item) => {
      // Category match
      const matchesCat = activeFaqCategory === 'all' || item.category === activeFaqCategory;
      if (!matchesCat) return false;

      // Search query match
      if (!faqSearch.trim()) return true;
      const query = faqSearch.trim().toLowerCase();
      const qText = (isArabic ? item.questionAr : item.questionEn).toLowerCase();
      const aText = (isArabic ? item.answerAr : item.answerEn).toLowerCase();
      const tags = (isArabic ? item.tagsAr : item.tagsEn).join(' ').toLowerCase();

      return qText.includes(query) || aText.includes(query) || tags.includes(query);
    });
  }, [activeFaqCategory, faqSearch, isArabic]);

  const expandAllFiltered = () => {
    setExpandedFaqIds(new Set(filteredFaqs.map((f) => f.id)));
  };

  const collapseAll = () => {
    setExpandedFaqIds(new Set());
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: ((e.clientX - rect.left) / rect.width - 0.5) * 20,
      y: ((e.clientY - rect.top) / rect.height - 0.5) * 20,
    });
  };

  const offset = getDirectionalOffset(isArabic, 20);

  return (
    <div className="space-y-12 sm:space-y-16 pb-14 overflow-hidden">
      {/* 1. Hero Section with Soft Ambient Mouse Reaction & Premium Animation */}
      <section
        id="hero"
        onMouseMove={handleMouseMove}
        className="relative pt-6 sm:pt-10 pb-6 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center space-y-5 sm:space-y-6"
      >
        {/* Subtle, calm Hero Background Pattern with soft opacity */}
        <AnimatedBackgroundPattern />

        {/* Floating Ambient Glowing Orbs with Smooth Continuous Floating Animation */}
        <motion.div
          animate={{
            x: mousePos.x,
            y: [mousePos.y - 10, mousePos.y + 10, mousePos.y - 10],
            scale: [1, 1.08, 1],
          }}
          transition={{
            x: { type: 'spring', damping: 40, stiffness: 200 },
            y: { duration: 6, repeat: Infinity, ease: 'easeInOut' },
            scale: { duration: 8, repeat: Infinity, ease: 'easeInOut' },
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[580px] h-[380px] bg-gradient-to-tr from-[#81A6C6]/25 via-[#AACDDC]/25 to-[#F3E3D0]/35 blur-3xl rounded-full pointer-events-none -z-10"
        />

        {/* Floating Secondary Ambient Accent Orb */}
        <motion.div
          animate={{
            y: [-12, 12, -12],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 14, repeat: Infinity, ease: 'linear' }}
          className="absolute -top-10 right-1/4 w-72 h-72 bg-[#81A6C6]/15 blur-2xl rounded-full pointer-events-none -z-10 hidden sm:block"
        />

        {/* Hero Tagline pill with Shimmer effect */}
        <motion.div
          initial={{ opacity: 0, y: 10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={motionTokens.spring.responsive}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/90 border border-[#81A6C6]/35 shadow-xs backdrop-blur-md relative overflow-hidden group"
        >
          <motion.div
            animate={{ x: ['-100%', '200%'] }}
            transition={{ repeat: Infinity, duration: 3.5, ease: 'easeInOut' }}
            className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-[#81A6C6]/20 to-transparent skew-x-12 pointer-events-none"
          />
          <Sparkles className="w-3.5 h-3.5 text-[#81A6C6] animate-pulse" />
          <span className="text-xs font-bold text-slate-800 relative z-10">
            {t.landing.heroTagline}
          </span>
        </motion.div>

        {/* Hero Headline */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: motionTokens.duration.normal, delay: 0.08, ease: motionTokens.easing.enter }}
          className="space-y-2.5 sm:space-y-3 max-w-4xl mx-auto"
        >
          <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-snug">
            {isArabic ? (
              <>
                <span className="bg-gradient-to-r from-[#81A6C6] via-[#618fae] to-[#456b8a] bg-clip-text text-transparent">
                  مِدْرار
                </span>{' '}
                — تعليم يفهمك وينمو معك
              </>
            ) : (
              <>
                <span className="bg-gradient-to-r from-[#81A6C6] via-[#618fae] to-[#456b8a] bg-clip-text text-transparent">
                  Midrar
                </span>{' '}
                — Learning that understands & grows with you
              </>
            )}
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl mx-auto font-normal">
            {t.landing.heroSubheadline}
          </p>
        </motion.div>

        {/* Action Buttons: "ابدأ الآن" & "اكتشف المزيد" */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: motionTokens.duration.normal, delay: 0.16, ease: motionTokens.easing.enter }}
          className="flex flex-row items-center justify-center gap-3 pt-1"
        >
          <AnimatedButton
            size="md"
            variant="primary"
            onClick={() => setActiveModal('auth')}
            icon={<Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />}
            className="min-w-[140px] shadow-md shadow-[#81A6C6]/25 hover:shadow-lg hover:shadow-[#81A6C6]/35"
          >
            <span>{isArabic ? 'ابدأ الآن' : 'Start Now'}</span>
            <ArrowRight className="w-4 h-4 rtl:rotate-180" />
          </AnimatedButton>

          <AnimatedButton
            size="md"
            variant="outline"
            onClick={() => {
              const target = document.getElementById('how-it-works');
              if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            icon={<ChevronDown className="w-4 h-4 text-[#81A6C6]" />}
            className="min-w-[140px] hover:bg-slate-50 border-slate-300"
          >
            <span>{isArabic ? 'اكتشف المزيد' : 'Explore More'}</span>
          </AnimatedButton>
        </motion.div>

        {/* 4 Modalities Interactive Cards Strip with Animated Hover Physics */}
        <StaggerContainer
          staggerDelay={0.07}
          className="pt-4 sm:pt-5 max-w-3xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3"
        >
          <StaggerItem>
            <motion.div
              whileHover={{ y: -4, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="p-3 bg-white/90 hover:bg-white rounded-2xl border border-blue-100/90 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer text-center group"
            >
              <div className="w-7 h-7 rounded-lg bg-blue-50 group-hover:bg-blue-500 group-hover:text-white text-blue-600 flex items-center justify-center transition-colors">
                <Eye className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs font-bold text-blue-950">{isArabic ? 'مسار بصري' : 'Visual Track'}</span>
              <span className="text-[10px] text-blue-600/80 font-medium">{isArabic ? 'خرائط ورسوم' : 'Maps & Diagrams'}</span>
            </motion.div>
          </StaggerItem>

          <StaggerItem>
            <motion.div
              whileHover={{ y: -4, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="p-3 bg-white/90 hover:bg-white rounded-2xl border border-amber-100/90 shadow-2xs hover:shadow-md hover:border-amber-300 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer text-center group"
            >
              <div className="w-7 h-7 rounded-lg bg-amber-50 group-hover:bg-amber-500 group-hover:text-white text-amber-600 flex items-center justify-center transition-colors">
                <Headphones className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs font-bold text-amber-950">{isArabic ? 'مسار سمعي' : 'Auditory Track'}</span>
              <span className="text-[10px] text-amber-600/80 font-medium">{isArabic ? 'سرد صوتي وحوار' : 'Audio & Dialogue'}</span>
            </motion.div>
          </StaggerItem>

          <StaggerItem>
            <motion.div
              whileHover={{ y: -4, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="p-3 bg-white/90 hover:bg-white rounded-2xl border border-emerald-100/90 shadow-2xs hover:shadow-md hover:border-emerald-300 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer text-center group"
            >
              <div className="w-7 h-7 rounded-lg bg-emerald-50 group-hover:bg-emerald-500 group-hover:text-white text-emerald-600 flex items-center justify-center transition-colors">
                <BookOpen className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs font-bold text-emerald-950">{isArabic ? 'مسار قرائي' : 'Reading Track'}</span>
              <span className="text-[10px] text-emerald-600/80 font-medium">{isArabic ? 'ملخصات ونصوص' : 'Notes & Text'}</span>
            </motion.div>
          </StaggerItem>

          <StaggerItem>
            <motion.div
              whileHover={{ y: -4, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="p-3 bg-white/90 hover:bg-white rounded-2xl border border-purple-100/90 shadow-2xs hover:shadow-md hover:border-purple-300 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer text-center group"
            >
              <div className="w-7 h-7 rounded-lg bg-purple-50 group-hover:bg-purple-500 group-hover:text-white text-purple-600 flex items-center justify-center transition-colors">
                <Wrench className="w-3.5 h-3.5" />
              </div>
              <span className="text-xs font-bold text-purple-950">{isArabic ? 'مسار تطبيقي' : 'Hands-on Track'}</span>
              <span className="text-[10px] text-purple-600/80 font-medium">{isArabic ? 'تجارب ومحاكاة' : 'Labs & Simulation'}</span>
            </motion.div>
          </StaggerItem>
        </StaggerContainer>
      </section>

      {/* 2. How It Works Cycle Section */}
      <MotionSection id="how-it-works" className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-extrabold text-[#81A6C6] uppercase tracking-wider">
            {t.landing.howItWorksSubtitle}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {t.landing.howItWorksTitle}
          </h2>
        </div>

        <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          <StaggerItem>
            <AnimatedCard clickable className="p-5 bg-white rounded-3xl border border-slate-200 shadow-2xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-extrabold text-base">
                1
              </div>
              <h3 className="text-sm font-bold text-slate-900">{t.landing.step1Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.landing.step1Desc}</p>
            </AnimatedCard>
          </StaggerItem>

          <StaggerItem>
            <AnimatedCard clickable className="p-5 bg-white rounded-3xl border border-slate-200 shadow-2xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-extrabold text-base">
                2
              </div>
              <h3 className="text-sm font-bold text-slate-900">{t.landing.step2Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.landing.step2Desc}</p>
            </AnimatedCard>
          </StaggerItem>

          <StaggerItem>
            <AnimatedCard clickable className="p-5 bg-white rounded-3xl border border-slate-200 shadow-2xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-extrabold text-base">
                3
              </div>
              <h3 className="text-sm font-bold text-slate-900">{t.landing.step3Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.landing.step3Desc}</p>
            </AnimatedCard>
          </StaggerItem>

          <StaggerItem>
            <AnimatedCard clickable className="p-5 bg-white rounded-3xl border border-slate-200 shadow-2xs space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-extrabold text-base">
                4
              </div>
              <h3 className="text-sm font-bold text-slate-900">{t.landing.step4Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.landing.step4Desc}</p>
            </AnimatedCard>
          </StaggerItem>
        </StaggerContainer>
      </MotionSection>

      {/* 3. Four Roles Portals Showcase */}
      <MotionSection id="four-roles" className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-extrabold text-[#81A6C6] uppercase tracking-wider">
            {isArabic ? 'بوابات متكاملة لكل دور' : 'Tailored Experiences'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {t.landing.fourRolesTitle}
          </h2>
        </div>

        <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Student Portal Card */}
          <StaggerItem>
            <AnimatedCard className="p-6 bg-gradient-to-br from-blue-50/70 via-white to-blue-50/20 rounded-3xl border border-blue-100 shadow-2xs space-y-3.5 flex flex-col justify-between h-full">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{t.roles.student}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{t.roles.studentDesc}</p>
                <ul className="space-y-1 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{isArabic ? 'دخول فوري برمز الطالب دون بريد' : 'Direct code login without email'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{isArabic ? 'مساعد مدرار يوجهك بأسلوب ذكي وتفاعلي' : 'Midrar smart adaptive study buddy'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{isArabic ? 'تحديات ونقاط تميز وشارات إنجاز' : 'XP points, streaks, and mastery badges'}</span>
                  </li>
                </ul>
              </div>
              <AnimatedButton
                onClick={() => setRole('student')}
                variant="primary"
                size="sm"
                className="mt-3 w-full bg-blue-600 hover:bg-blue-700"
              >
                <span>{isArabic ? 'دخول بوابة الطالب' : 'Open Student Portal'}</span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
              </AnimatedButton>
            </AnimatedCard>
          </StaggerItem>

          {/* Guardian Portal Card */}
          <StaggerItem>
            <AnimatedCard className="p-6 bg-gradient-to-br from-emerald-50/70 via-white to-emerald-50/20 rounded-3xl border border-emerald-100 shadow-2xs space-y-3.5 flex flex-col justify-between h-full">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <Users className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{t.roles.guardian}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{t.roles.guardianDesc}</p>
                <ul className="space-y-1 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{isArabic ? 'إدارة حسابات الأبناء وإصدار الرموز' : 'Manage family students & codes'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{isArabic ? 'تقارير أسبوعية تفاعلية ونصائح منزلية' : 'AI Weekly progress summaries'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{isArabic ? 'محادثة آمنة وتقييم تجربة المعلمين' : 'Direct teacher messaging & ratings'}</span>
                  </li>
                </ul>
              </div>
              <AnimatedButton
                onClick={() => setRole('guardian')}
                variant="primary"
                size="sm"
                className="mt-3 w-full bg-emerald-600 hover:bg-emerald-700"
              >
                <span>{isArabic ? 'دخول بوابة ولي الأمر' : 'Open Guardian Portal'}</span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
              </AnimatedButton>
            </AnimatedCard>
          </StaggerItem>

          {/* Teacher Portal Card */}
          <StaggerItem>
            <AnimatedCard className="p-6 bg-gradient-to-br from-amber-50/70 via-white to-amber-50/20 rounded-3xl border border-amber-100 shadow-2xs space-y-3.5 flex flex-col justify-between h-full">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-xs">
                  <BookOpen className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{t.roles.teacher}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{t.roles.teacherDesc}</p>
                <ul className="space-y-1 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>{isArabic ? 'توليد 4 مسارات متكيفة بمساعد مدرار' : 'Midrar 4-track adaptive lesson generator'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>{isArabic ? 'اختبارات ذكية بتلميحات تدريجية' : 'Adaptive quizzes with smart hints'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>{isArabic ? 'ملف مهني لاستقطاب المدارس الأهلية' : 'Teacher profile open to school offers'}</span>
                  </li>
                </ul>
              </div>
              <AnimatedButton
                onClick={() => setRole('teacher')}
                variant="primary"
                size="sm"
                className="mt-3 w-full bg-amber-600 hover:bg-amber-700"
              >
                <span>{isArabic ? 'دخول بوابة المعلم' : 'Open Teacher Portal'}</span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
              </AnimatedButton>
            </AnimatedCard>
          </StaggerItem>

          {/* School Portal Card */}
          <StaggerItem>
            <AnimatedCard className="p-6 bg-gradient-to-br from-purple-50/70 via-white to-purple-50/20 rounded-3xl border border-purple-100 shadow-2xs space-y-3.5 flex flex-col justify-between h-full">
              <div className="space-y-2.5">
                <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
                  <School className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">{t.roles.school}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{t.roles.schoolDesc}</p>
                <ul className="space-y-1 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span>{isArabic ? 'اكتشاف واستقطاب الكفاءات التعليمية' : 'Discover and recruit verified faculty'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span>{isArabic ? 'إرسال عروض استقطاب رسمية ومباشرة' : 'Send institutional recruitment offers'}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span>{isArabic ? 'مؤشرات الأداء الأكاديمي ورضا الأسرة' : 'Cohort analytics & satisfaction index'}</span>
                  </li>
                </ul>
              </div>
              <AnimatedButton
                onClick={() => setRole('school')}
                variant="primary"
                size="sm"
                className="mt-3 w-full bg-purple-600 hover:bg-purple-700"
              >
                <span>{isArabic ? 'دخول بوابة المدرسة' : 'Open School Portal'}</span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
              </AnimatedButton>
            </AnimatedCard>
          </StaggerItem>
        </StaggerContainer>
      </MotionSection>

      {/* 4. Live Interactive Progress Report Showcase */}
      <MotionSection id="interactive-report" className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl p-6 sm:p-10 shadow-2xl border border-slate-700 space-y-6 relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                {t.landing.interactiveReportTitle}
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                {isArabic ? 'رؤية بصرية واضحة تنمي ثقة الطالب والأسرة' : 'Visual Growth Insights that Build Confidence'}
              </h2>
              <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
                {t.landing.interactiveReportDesc}
              </p>
            </div>

            <AnimatedButton
              onClick={() => setSelectedLessonId('les-1')}
              variant="primary"
              size="md"
              icon={<Play className="w-4 h-4" />}
              className="shrink-0"
            >
              <span>{isArabic ? 'تجربة درس تفاعلي حي الآن' : 'Try Live Interactive Lesson'}</span>
            </AnimatedButton>
          </div>

          {/* Interactive Report Grid Simulation */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-700/80 relative z-10">
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2.5 backdrop-blur-xs">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{t.test.visualModality}</span>
                <span className="text-blue-400 font-bold">38%</span>
              </div>
              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: '38%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, ease: motionTokens.easing.enter }}
                  className="bg-blue-400 h-full rounded-full"
                />
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isArabic ? 'استجابة سريعة للخرائط الذهنية وتلوين خطوات الحل' : 'High response to concept maps & colored formulas'}
              </p>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2.5 backdrop-blur-xs">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{t.test.interactiveHandsOnModality}</span>
                <span className="text-purple-400 font-bold">32%</span>
              </div>
              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: '32%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, delay: 0.1, ease: motionTokens.easing.enter }}
                  className="bg-purple-400 h-full rounded-full"
                />
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isArabic ? 'شغف كبير بتجارب المختبر والأنشطة المعملية العملية' : 'Strong retention with physical experiments & labs'}
              </p>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2.5 backdrop-blur-xs">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{isArabic ? 'نسبة الإتقان الأكاديمي' : 'Overall Mastery'}</span>
                <span className="text-emerald-400 font-bold">88%</span>
              </div>
              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: '88%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, delay: 0.2, ease: motionTokens.easing.enter }}
                  className="bg-emerald-400 h-full rounded-full"
                />
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isArabic ? 'تطور بنسبة +14% مقارنة بالشهر السابق' : '+14% mastery surge compared to previous month'}
              </p>
            </div>
          </div>
        </div>
      </MotionSection>

      {/* 5. Frequently Asked Questions with Categories, Live Search & Detailed Insights */}
      <MotionSection id="faq" className="px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#81A6C6]/15 text-[#4B6B94] text-xs font-extrabold">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>{t.navigation.faq}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {isArabic ? 'كل ما تود معرفته عن منصة مِدْرار' : 'Everything You Need to Know About Midrar'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
            {isArabic
              ? 'إجابات شاملة ومفصلة لجميع استفسارات الطلاب، أولياء الأمور، المعلمين وإدارات المدارس.'
              : 'Comprehensive answers to all inquiries from students, guardians, educators, and school leaders.'}
          </p>
        </div>

        {/* FAQ Search Bar & Quick Controls */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
              <input
                type="text"
                value={faqSearch}
                onChange={(e) => setFaqSearch(e.target.value)}
                placeholder={
                  isArabic
                    ? 'ابحث في الأسئلة (مثال: المسارات، رمز الطالب، ولي الأمر، الذكاء، PDF)...'
                    : 'Search questions (e.g. tracks, student code, guardian, AI, PDF)...'
                }
                className="w-full ps-10 pe-9 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#81A6C6]/40 focus:border-[#81A6C6] transition-all shadow-2xs"
              />
              {faqSearch && (
                <button
                  type="button"
                  onClick={() => setFaqSearch('')}
                  className="absolute top-1/2 -translate-y-1/2 end-3 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Expand / Collapse All Controls */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={expandAllFiltered}
                className="px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition-all shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                <span>{isArabic ? 'فتح الكل' : 'Expand All'}</span>
              </button>
              <button
                type="button"
                onClick={collapseAll}
                className="px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition-all shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
                <span>{isArabic ? 'طي الكل' : 'Collapse All'}</span>
              </button>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-none no-scrollbar">
            {FAQ_CATEGORIES.map((cat) => {
              const isActive = activeFaqCategory === cat.id;
              const count =
                cat.id === 'all'
                  ? FAQ_ITEMS.length
                  : FAQ_ITEMS.filter((f) => f.category === cat.id).length;

              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveFaqCategory(cat.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <span>{isArabic ? cat.labelAr : cat.labelEn}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3">
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map((item) => {
              const isExpanded = expandedFaqIds.has(item.id);
              const isHelpful = helpfulFeedback[item.id];

              return (
                <AnimatedCard
                  key={item.id}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                    isExpanded
                      ? 'bg-white border-[#81A6C6]/50 shadow-sm ring-1 ring-[#81A6C6]/20'
                      : 'bg-white border-slate-200/90 shadow-2xs hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleFaqItem(item.id)}
                    className="w-full flex items-start justify-between gap-4 text-start font-bold text-sm sm:text-base text-slate-900 cursor-pointer select-none group"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* Category badge */}
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-[10px] font-extrabold text-slate-600">
                          {item.category === 'students'
                            ? isArabic ? 'الطلاب والتعلم' : 'Students'
                            : item.category === 'guardians'
                            ? isArabic ? 'أولياء الأمور' : 'Guardians'
                            : item.category === 'teachers'
                            ? isArabic ? 'المعلمون' : 'Teachers'
                            : item.category === 'schools'
                            ? isArabic ? 'إدارة المدرسة' : 'Schools'
                            : isArabic ? 'الذكاء والخصوصية' : 'AI & Privacy'}
                        </span>
                      </div>
                      <span className="group-hover:text-[#4B6B94] transition-colors leading-snug block pt-1">
                        {isArabic ? item.questionAr : item.questionEn}
                      </span>
                    </div>

                    <div
                      className={`p-1.5 rounded-full transition-transform duration-200 shrink-0 ${
                        isExpanded ? 'bg-[#81A6C6]/20 text-[#4B6B94] rotate-180' : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: motionTokens.duration.fast, ease: motionTokens.easing.standard }}
                        className="overflow-hidden"
                      >
                        <div className="pt-3.5 mt-3 border-t border-slate-100 space-y-3">
                          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
                            {isArabic ? item.answerAr : item.answerEn}
                          </p>

                          {/* Interactive Tags and Feedback Bar */}
                          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                            <div className="flex flex-wrap items-center gap-1.5">
                              {(isArabic ? item.tagsAr : item.tagsEn).map((tag, tIdx) => (
                                <span
                                  key={tIdx}
                                  className="px-2 py-0.5 rounded-full bg-slate-50 border border-slate-200 text-[10px] text-slate-500"
                                >
                                  #{tag}
                                </span>
                              ))}
                            </div>

                            <button
                              type="button"
                              onClick={(e) => handleHelpfulClick(item.id, e)}
                              className={`text-[11px] font-bold px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                                isHelpful
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'text-slate-400 hover:text-slate-700 hover:bg-slate-50'
                              }`}
                            >
                              <ThumbsUp className="w-3 h-3" />
                              <span>
                                {isHelpful
                                  ? isArabic
                                    ? 'شكراً لتقييمك!'
                                    : 'Helpful feedback noted!'
                                  : isArabic
                                  ? 'هل كانت الإجابة مفيدة؟'
                                  : 'Was this helpful?'}
                              </span>
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </AnimatedCard>
              );
            })
          ) : (
            <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-sm text-slate-800">
                {isArabic ? 'لم نتمكن من العثور على سؤال يطابق بحثك' : 'No matching questions found'}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {isArabic
                  ? 'جرب البحث بكلمات أخرى أو اختر فئة مختلفة من الأزرار أعلاه.'
                  : 'Try adjusting your search terms or selecting a different category above.'}
              </p>
              <button
                type="button"
                onClick={() => {
                  setFaqSearch('');
                  setActiveFaqCategory('all');
                }}
                className="px-4 py-2 bg-[#81A6C6] text-white rounded-xl text-xs font-bold hover:bg-[#6f95b7] transition-all cursor-pointer"
              >
                {isArabic ? 'عرض جميع الأسئلة' : 'View All Questions'}
              </button>
            </div>
          )}
        </div>

        {/* Need More Assistance Banner */}
        <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3.5 text-center sm:text-start">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5 text-[#81A6C6]" />
            </div>
            <div className="space-y-0.5">
              <h4 className="font-extrabold text-sm sm:text-base">
                {isArabic ? 'هل لديك سؤال أو استفسار لم تجد إجابته هنا؟' : 'Still have unanswered questions?'}
              </h4>
              <p className="text-xs text-slate-300">
                {isArabic
                  ? 'فريق الدعم ومساعد مِدْرار الذكي متواجدون لمساعدتك فوراً.'
                  : 'Our support team and AI Assistant are ready to help you 24/7.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setActiveModal('chat')}
            className="px-4 py-2.5 bg-white text-slate-900 hover:bg-slate-100 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#81A6C6]" />
            <span>{isArabic ? 'تحدث مع الدعم الذكي' : 'Chat with Smart Support'}</span>
          </button>
        </div>
      </MotionSection>

      {/* 6. Bottom Call to Action */}
      <MotionSection className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-[#81A6C6] via-[#AACDDC] to-[#D2C4B4] rounded-3xl p-6 sm:p-10 text-center space-y-4 shadow-xl relative overflow-hidden">
          <div className="max-w-2xl mx-auto space-y-2">
            <h2 className="text-xl sm:text-3xl font-extrabold text-slate-900">
              {t.landing.ctaHeadline}
            </h2>
            <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium">
              {t.landing.ctaSubheadline}
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            <AnimatedButton
              size="md"
              variant="secondary"
              onClick={() => setActiveModal('auth')}
            >
              <span>{t.landing.ctaButton}</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </AnimatedButton>
          </div>
        </div>
      </MotionSection>
    </div>
  );
};
