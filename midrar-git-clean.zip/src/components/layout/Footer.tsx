import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useApp } from '../../context/AppContext';
import { Logo } from '../common/Logo';
import { ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  const { isArabic, t, language, setLanguage } = useLanguage();
  const { setRole } = useApp();

  return (
    <footer id="app-main-footer" className="bg-slate-900 text-slate-300 border-t border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 pb-12 border-b border-slate-800">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white/5 p-3.5 rounded-2xl inline-block border border-white/10 shadow-sm">
              <Logo size="md" showSlogan={true} variant="inverted" />
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              {t.common.appDescription}
            </p>
            <div className="flex items-center gap-3 pt-2 text-xs text-slate-400">
              <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <ShieldCheck className="w-4 h-4" />
                {isArabic ? 'بيئة آمنة ومشفرة للطلاب' : 'Child-Safe & COPPA/GDPR Compliant'}
              </span>
            </div>
          </div>

          {/* Quick Portals */}
          <div className="space-y-3">
            <h5 className="text-xs font-bold text-white uppercase tracking-wider">
              {isArabic ? 'بوابات المنظومة' : 'Platform Portals'}
            </h5>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => setRole('student')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.roles.student}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setRole('guardian')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.roles.guardian}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setRole('teacher')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.roles.teacher}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setRole('school')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.roles.school}
                </button>
              </li>
            </ul>
          </div>

          {/* Language & Info */}
          <div className="space-y-3">
            <h5 className="text-xs font-bold text-white uppercase tracking-wider">
              {t.common.language}
            </h5>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setLanguage('ar')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                  language === 'ar' ? 'bg-[#81A6C6] text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                العربية
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                  language === 'en' ? 'bg-[#81A6C6] text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
            <p className="text-[11px] text-slate-500 pt-2">
              {isArabic ? 'مدعوم بمساعد مِدْرار الذكي للتعليم المخصص المتكيف' : 'Powered by Midrar Smart Assistant for Adaptive Pedagogy'}
            </p>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-center text-xs text-slate-400 text-center">
          <p>© 2026 {isArabic ? 'منصة مِدْرار التعليمية الذكية. جميع الحقوق محفوظة.' : 'Midrar Adaptive Learning Platform. All rights reserved.'}</p>
        </div>
      </div>
    </footer>
  );
};
