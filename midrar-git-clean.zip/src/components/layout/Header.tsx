import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Logo } from '../common/Logo';
import {
  Globe,
  Bell,
  MessageSquare,
  LogOut,
  Menu,
  X,
  Sparkles,
  GraduationCap,
  Users,
  BookOpen,
  School,
  ChevronDown,
  KeyRound
} from 'lucide-react';

interface HeaderProps {
  onNavigateSection?: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onNavigateSection }) => {
  const {
    role,
    setRole,
    currentUser,
    unreadNotifsCount,
    unreadMessagesCount,
    setActiveModal,
    logout,
    notifications,
    markNotificationRead
  } = useApp();

  const { language, setLanguage, isArabic, t } = useLanguage();

  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotifPopover, setShowNotifPopover] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  const handleNavClick = (sectionId: string) => {
    setShowMobileMenu(false);
    if (onNavigateSection) {
      onNavigateSection(sectionId);
    } else {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header
      id="app-main-header"
      className="fixed top-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all shadow-xs"
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Left / Brand Logo */}
        <div className="flex items-center gap-4 lg:gap-8 shrink-0">
          <Logo
            size="md"
            showText={false}
            showSlogan={false}
            onClick={() => {
              if (role === 'guest') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
          />

          {/* Desktop Navigation Links */}
          {role === 'guest' && (
            <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-semibold text-slate-600">
              <button
                type="button"
                onClick={() => handleNavClick('hero')}
                className="hover:text-[#81A6C6] transition-colors cursor-pointer whitespace-nowrap"
              >
                {t.navigation.home}
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('how-it-works')}
                className="hover:text-[#81A6C6] transition-colors cursor-pointer whitespace-nowrap"
              >
                {t.navigation.howItWorks}
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('four-roles')}
                className="hover:text-[#81A6C6] transition-colors cursor-pointer whitespace-nowrap"
              >
                {t.navigation.portals}
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('interactive-report')}
                className="hover:text-[#81A6C6] transition-colors cursor-pointer whitespace-nowrap"
              >
                {t.navigation.report}
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('faq')}
                className="hover:text-[#81A6C6] transition-colors cursor-pointer whitespace-nowrap"
              >
                {t.navigation.faq}
              </button>
            </nav>
          )}
        </div>

        {/* Right Tools & Actions */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* Language Switcher */}
          <button
            type="button"
            onClick={toggleLanguage}
            className="inline-flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-all cursor-pointer whitespace-nowrap"
            title={language === 'ar' ? 'Switch to English' : 'التحويل للعربية'}
          >
            <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-500" />
            <span>{language === 'ar' ? 'English' : 'العربية'}</span>
          </button>

          {/* If Logged In */}
          {role !== 'guest' ? (
            <>
              {/* Chat icon */}
              {role === 'guardian' && (
                <button
                  type="button"
                  onClick={() => setActiveModal('children-codes')}
                  className="px-2.5 sm:px-3 py-1.5 sm:py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                  title={isArabic ? 'رموز دخول أبنائك' : 'Children Access Codes'}
                >
                  <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">{isArabic ? 'رموز أبنائك' : 'Children Codes'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setActiveModal('chat')}
                className="relative p-2 sm:p-2.5 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                title={t.common.messages}
              >
                <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5 text-slate-600" />
                {unreadMessagesCount > 0 && (
                  <span className="absolute top-1 end-1 w-4 h-4 bg-blue-600 text-white font-bold text-[10px] rounded-full flex items-center justify-center">
                    {unreadMessagesCount}
                  </span>
                )}
              </button>

              {/* Notification Popover */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowNotifPopover(!showNotifPopover)}
                  className="relative p-2 sm:p-2.5 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  title={t.common.notifications}
                >
                  <Bell className="w-4 h-4 sm:w-5 sm:h-5 text-slate-600" />
                  {unreadNotifsCount > 0 && (
                    <span className="absolute top-1.5 end-1.5 w-2.5 h-2.5 bg-rose-500 rounded-full" />
                  )}
                </button>

                {showNotifPopover && (
                  <div className="absolute end-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 space-y-2 z-50 animate-in fade-in">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                      <span className="text-xs font-bold text-slate-800">{t.common.notifications}</span>
                      <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-semibold">
                        {unreadNotifsCount} {isArabic ? 'جديد' : 'new'}
                      </span>
                    </div>
                    <div className="max-h-60 overflow-y-auto space-y-2 custom-scrollbar">
                      {notifications.map((n) => (
                        <div
                          key={n.id}
                          onClick={() => markNotificationRead(n.id)}
                          className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                            !n.isRead
                              ? 'bg-blue-50/50 border-blue-100 text-blue-950 font-medium'
                              : 'bg-white border-slate-100 text-slate-600'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-[11px]">{isArabic ? n.titleAr : n.titleEn}</span>
                            <span className="text-[9px] text-slate-400">{n.timestamp}</span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">{isArabic ? n.bodyAr : n.bodyEn}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Role Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                  className="flex items-center gap-1.5 sm:gap-2 ps-2 sm:ps-2.5 pe-2.5 sm:pe-3.5 py-1.5 sm:py-2 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-all cursor-pointer text-xs font-bold text-slate-800"
                >
                  {currentUser.avatarUrl ? (
                    <img
                      src={currentUser.avatarUrl}
                      alt={currentUser.name}
                      className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg object-cover"
                    />
                  ) : (
                    <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-[#81A6C6] text-white flex items-center justify-center font-bold text-[10px]">
                      {role[0].toUpperCase()}
                    </div>
                  )}
                  <span className="hidden sm:inline truncate max-w-[120px]">{currentUser.name}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {showRoleDropdown && (
                  <div className="absolute end-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in space-y-1">
                    <div className="p-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900 truncate">{currentUser.name}</p>
                      <p className="text-[10px] text-slate-500 capitalize font-medium">{t.roles[role]}</p>
                      {currentUser.email && (
                        <p className="text-[10px] text-slate-400 truncate mt-0.5" dir="ltr">{currentUser.email}</p>
                      )}
                    </div>

                    {role === 'guardian' && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowRoleDropdown(false);
                          setActiveModal('children-codes');
                        }}
                        className="w-full p-2 rounded-xl text-xs text-emerald-800 hover:bg-emerald-50 flex items-center gap-2 font-medium cursor-pointer"
                      >
                        <KeyRound className="w-4 h-4 text-emerald-600" />
                        <span>{isArabic ? 'رموز دخول أبنائك' : 'Children Access Codes'}</span>
                      </button>
                    )}

                    <div className="pt-1 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => {
                          setShowRoleDropdown(false);
                          logout();
                        }}
                        className="w-full p-2 rounded-xl text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-semibold cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>{t.common.logout}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Primary CTA Button for Guest */
            <button
              type="button"
              onClick={() => setActiveModal('auth')}
              className="hidden sm:flex px-4 sm:px-5 py-2 sm:py-2.5 rounded-xl text-xs font-extrabold text-white bg-[#81A6C6] hover:bg-[#7298b9] shadow-xs hover:shadow-md transition-all items-center gap-1.5 sm:gap-2 cursor-pointer whitespace-nowrap"
            >
              <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300" />
              <span>{t.common.startNow}</span>
            </button>
          )}

          {/* Mobile Menu Toggle Button */}
          <button
            type="button"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            className="md:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer flex items-center justify-center"
            aria-label="Toggle Menu"
          >
            {showMobileMenu ? <X className="w-6 h-6 text-slate-900" /> : <Menu className="w-6 h-6 text-slate-900" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu with AnimatePresence */}
      <AnimatePresence>
        {showMobileMenu && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-white border-b border-slate-200 overflow-hidden shadow-lg"
          >
            <div className="p-4 space-y-3">
              {role === 'guest' ? (
                <div className="flex flex-col gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleNavClick('hero')}
                    className="text-start py-2.5 px-3 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-between"
                  >
                    <span>{t.navigation.home}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('how-it-works')}
                    className="text-start py-2.5 px-3 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-between"
                  >
                    <span>{t.navigation.howItWorks}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('four-roles')}
                    className="text-start py-2.5 px-3 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-between"
                  >
                    <span>{t.navigation.portals}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('interactive-report')}
                    className="text-start py-2.5 px-3 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-between"
                  >
                    <span>{t.navigation.report}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('faq')}
                    className="text-start py-2.5 px-3 rounded-xl hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-between"
                  >
                    <span>{t.navigation.faq}</span>
                  </button>

                  {/* Start Now Button inside Mobile Menu */}
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setShowMobileMenu(false);
                        setActiveModal('auth');
                      }}
                      className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-[#81A6C6] hover:bg-[#7298b9] flex items-center justify-center gap-2 shadow-xs"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>{t.common.startNow}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="p-3 bg-slate-50 rounded-2xl flex items-center gap-3">
                    {currentUser.avatarUrl && (
                      <img src={currentUser.avatarUrl} alt="" className="w-8 h-8 rounded-xl object-cover" />
                    )}
                    <div>
                      <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                      <p className="text-[10px] text-slate-500 capitalize">{t.roles[role]}</p>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setShowMobileMenu(false);
                        logout();
                      }}
                      className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t.common.logout}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
