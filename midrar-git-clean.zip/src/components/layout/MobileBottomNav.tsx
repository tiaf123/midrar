import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { motionTokens } from '../../motion/tokens';
import {
  Home,
  Sparkles,
  BookOpen,
  Users,
  MessageSquare,
  User,
  GraduationCap,
  Layers,
  School
} from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    role,
    setRole,
    currentUser,
    setActiveModal,
    unreadMessagesCount,
    setSelectedLessonId,
  } = useApp();

  const { isArabic, t } = useLanguage();

  const [isVisible, setIsVisible] = useState(true);
  const [showRoleDrawer, setShowRoleDrawer] = useState(false);
  const [activeTab, setActiveTab] = useState<'home' | 'learn' | 'action' | 'portals' | 'profile'>('home');
  const lastScrollY = useRef(0);
  const scrollTimeout = useRef<NodeJS.Timeout | null>(null);

  // Dynamic Scroll Listeners (hides on scroll down, reappears on scroll up or on stop)
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      // Always show near the very top of page
      if (currentScrollY < 40) {
        setIsVisible(true);
        lastScrollY.current = currentScrollY;
        return;
      }

      // Scrolling Down -> Hide with spring
      if (currentScrollY > lastScrollY.current + 8) {
        setIsVisible(false);
      }
      // Scrolling Up -> Show
      else if (currentScrollY < lastScrollY.current - 8) {
        setIsVisible(true);
      }

      lastScrollY.current = currentScrollY;

      // When scroll stops, bring bar back
      if (scrollTimeout.current) clearTimeout(scrollTimeout.current);
      scrollTimeout.current = setTimeout(() => {
        setIsVisible(true);
      }, 750);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeout.current) clearTimeout(scrollTimeout.current);
    };
  }, []);

  const scrollToSection = (id: string) => {
    setActiveTab('home');
    if (role !== 'guest') {
      setRole('guest');
      setTimeout(() => {
        const el = document.getElementById(id);
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Account Sheet on Mobile */}
      <AnimatePresence>
        {showRoleDrawer && (
          <div className="fixed inset-0 z-50 md:hidden flex flex-col justify-end">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: motionTokens.duration.fast }}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
              onClick={() => setShowRoleDrawer(false)}
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={motionTokens.spring.responsive}
              className="relative bg-white rounded-t-3xl p-5 border-t border-slate-200 shadow-2xl space-y-4 z-10"
            >
              <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-1" />
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{currentUser?.name || 'Guest'}</h4>
                  <p className="text-xs text-slate-500 capitalize">{t.roles[role as keyof typeof t.roles]}</p>
                </div>
                <button
                  onClick={() => setShowRoleDrawer(false)}
                  className="text-xs font-bold text-slate-400 p-1"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowRoleDrawer(false);
                    logout();
                  }}
                  className="w-full py-3 px-4 rounded-xl text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>{t.common.logout}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating Dynamic Bottom App Bar for Mobile */}
      <motion.div
        id="app-mobile-bottom-nav"
        initial={{ y: 0, opacity: 1 }}
        animate={{
          y: isVisible ? 0 : 'calc(100% + 24px)',
          opacity: isVisible ? 1 : 0,
        }}
        transition={motionTokens.spring.responsive}
        className="md:hidden fixed bottom-3 inset-x-3 z-40"
        style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      >
        <div className="bg-white/95 backdrop-blur-xl border border-slate-200/90 rounded-3xl shadow-xl px-2 py-1.5 flex items-center justify-around text-slate-600 relative">
          {/* Item 1: Home */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('home');
              if (role !== 'guest') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              } else {
                scrollToSection('hero');
              }
            }}
            className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl active:scale-95 transition-transform ${
              activeTab === 'home' ? 'text-[#81A6C6] font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">{t.navigation.home}</span>
            {activeTab === 'home' && (
              <motion.div
                layoutId="active-mobile-tab-indicator"
                className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#81A6C6]"
                transition={motionTokens.spring.playful}
              />
            )}
          </button>

          {/* Item 2: Tracks or Lessons */}
          {role === 'guest' ? (
            <button
              type="button"
              onClick={() => {
                setActiveTab('learn');
                scrollToSection('how-it-works');
              }}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl active:scale-95 transition-transform ${
                activeTab === 'learn' ? 'text-[#81A6C6] font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">{isArabic ? 'المسارات' : 'Tracks'}</span>
              {activeTab === 'learn' && (
                <motion.div
                  layoutId="active-mobile-tab-indicator"
                  className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#81A6C6]"
                  transition={motionTokens.spring.playful}
                />
              )}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setActiveTab('learn');
                if (role === 'student') setSelectedLessonId('les-1');
                else if (role === 'teacher') setActiveModal('teacher-generator');
                else if (role === 'guardian') setActiveModal('parent-report');
                else setShowRoleDrawer(true);
              }}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl active:scale-95 transition-transform ${
                activeTab === 'learn' ? 'text-[#81A6C6] font-bold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">
                {role === 'student' ? (isArabic ? 'الدروس' : 'Lessons') : (isArabic ? 'المحتوى' : 'Content')}
              </span>
              {activeTab === 'learn' && (
                <motion.div
                  layoutId="active-mobile-tab-indicator"
                  className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#81A6C6]"
                  transition={motionTokens.spring.playful}
                />
              )}
            </button>
          )}

          {/* Item 3: Center Highlight Action */}
          {role === 'guest' ? (
            <motion.button
              type="button"
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: 0.94 }}
              onClick={() => setActiveModal('auth')}
              className="relative -top-3.5 bg-gradient-to-tr from-[#81A6C6] to-[#AACDDC] text-white p-3.5 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center border-2 border-white"
            >
              <GraduationCap className="w-6 h-6" />
            </motion.button>
          ) : (
            <motion.button
              type="button"
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: 0.94 }}
              onClick={() => setActiveModal('chat')}
              className="relative -top-3.5 bg-[#81A6C6] text-white p-3.5 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center border-2 border-white"
            >
              <MessageSquare className="w-6 h-6" />
              {unreadMessagesCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -end-1 w-4 h-4 bg-rose-500 text-white font-bold text-[9px] rounded-full flex items-center justify-center border-2 border-white"
                >
                  {unreadMessagesCount}
                </motion.span>
              )}
            </motion.button>
          )}

          {/* Item 4: Portals / Codes */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('portals');
              if (role === 'guest') {
                scrollToSection('four-roles');
              } else if (role === 'guardian') {
                setActiveModal('children-codes');
              }
            }}
            className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl active:scale-95 transition-transform ${
              activeTab === 'portals' ? 'text-[#81A6C6] font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">
              {role === 'guardian' ? (isArabic ? 'الرموز' : 'Codes') : t.navigation.portals}
            </span>
            {activeTab === 'portals' && (
              <motion.div
                layoutId="active-mobile-tab-indicator"
                className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#81A6C6]"
                transition={motionTokens.spring.playful}
              />
            )}
          </button>

          {/* Item 5: Account / Login */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('profile');
              if (role === 'guest') setActiveModal('auth');
              else setShowRoleDrawer(true);
            }}
            className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl active:scale-95 transition-transform ${
              activeTab === 'profile' ? 'text-[#81A6C6] font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">
              {role === 'guest' ? (isArabic ? 'دخول' : 'Login') : currentUser.name.split(' ')[0]}
            </span>
            {activeTab === 'profile' && (
              <motion.div
                layoutId="active-mobile-tab-indicator"
                className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#81A6C6]"
                transition={motionTokens.spring.playful}
              />
            )}
          </button>
        </div>
      </motion.div>
    </>
  );
};
