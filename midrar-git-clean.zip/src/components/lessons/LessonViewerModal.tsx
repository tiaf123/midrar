import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  Eye,
  Headphones,
  BookOpen,
  Wrench,
  Sparkles,
  Bot,
  Send,
  CheckCircle2,
  Clock,
  HelpCircle,
  Play,
  Volume2
} from 'lucide-react';

export const LessonViewerModal: React.FC = () => {
  const { selectedLessonId, setSelectedLessonId, lessons, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'visual' | 'auditory' | 'reading' | 'handsOn'>('visual');
  const [tutorQuery, setTutorQuery] = useState('');
  const [tutorChat, setTutorChat] = useState<Array<{ sender: 'student' | 'tutor'; text: string }>>([
    {
      sender: 'tutor',
      text: isArabic
        ? 'مرحباً يا بطل! أنا مساعدك الذكي في هذا الدرس. ما الجزء الذي ترغب في استكشافه أو طلب تلميح حوله؟'
        : 'Hello! I am your AI study tutor for this lesson. What concept would you like to explore or need a hint on?'
    }
  ]);
  const [isAskingTutor, setIsAskingTutor] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  if (!selectedLessonId) return null;
  const lesson = lessons.find((l) => l.id === selectedLessonId);
  if (!lesson) return null;

  const handleAskTutor = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!tutorQuery.trim() || isAskingTutor) return;

    const userText = tutorQuery;
    setTutorQuery('');
    setTutorChat((prev) => [...prev, { sender: 'student', text: userText }]);
    setIsAskingTutor(true);

    try {
      const response = await fetch('/api/gemini/tutor-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentMessage: userText,
          currentTopic: lesson.titleAr,
          gradeLevel: 'الصف الثاني المتوسط',
          preferredModality: activeTab
        })
      });

      const data = await response.json();
      const reply = data.reply || (isArabic ? 'أحسنت التفكير! دعنا نحللها معاً خطوة بخطوة.' : 'Great thinking! Let us break it down step by step.');
      setTutorChat((prev) => [...prev, { sender: 'tutor', text: reply }]);
    } catch (err) {
      console.error(err);
      setTutorChat((prev) => [
        ...prev,
        {
          sender: 'tutor',
          text: isArabic
            ? 'فكرة ممتازة! تذكر أن مساحة المربع المنشأ على الوتر تساوي مجموع مساحتي المربعين الآخرين.'
            : 'Excellent idea! Recall that the square of the hypotenuse equals the sum of the other two squares.'
        }
      ]);
    } finally {
      setIsAskingTutor(false);
    }
  };

  const toggleAudio = () => {
    setIsPlayingAudio(!isPlayingAudio);
    if (!isPlayingAudio) {
      showToast(isArabic ? 'بدأ تشغيل السرد الصوتي للدرس...' : 'Playing audio narration...');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[94vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 via-white to-blue-50/30">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#81A6C6]/20 text-[#81A6C6]">
                {isArabic ? lesson.subjectTitleAr : lesson.subjectTitleEn}
              </span>
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {lesson.estimatedMinutes} {isArabic ? 'دقيقة' : 'min'}
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-800">
              {isArabic ? lesson.titleAr : lesson.titleEn}
            </h3>
          </div>

          <button
            onClick={() => setSelectedLessonId(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4-Modality Tabs Selector */}
        <div className="px-5 pt-3 pb-0 bg-slate-50/70 border-b border-slate-200/80 flex gap-2 overflow-x-auto custom-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('visual')}
            className={`pb-3 px-4 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'visual'
                ? 'border-blue-600 text-blue-700 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Eye className="w-4 h-4 text-blue-600" />
            <span>{t.student.lessonModalityVisual}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('auditory')}
            className={`pb-3 px-4 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'auditory'
                ? 'border-amber-600 text-amber-700 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Headphones className="w-4 h-4 text-amber-600" />
            <span>{t.student.lessonModalityAuditory}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reading')}
            className={`pb-3 px-4 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'reading'
                ? 'border-emerald-600 text-emerald-700 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <span>{t.student.lessonModalityReading}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('handsOn')}
            className={`pb-3 px-4 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              activeTab === 'handsOn'
                ? 'border-purple-600 text-purple-700 bg-white shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Wrench className="w-4 h-4 text-purple-600" />
            <span>{t.student.lessonModalityHandsOn}</span>
          </button>
        </div>

        {/* Content Layout: Left/Main Content + Right/AI Tutor Assistant */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 overflow-hidden">
          {/* Main Content Area */}
          <div className="lg:col-span-2 p-6 overflow-y-auto custom-scrollbar space-y-6">
            {/* Visual Track */}
            {activeTab === 'visual' && lesson.visualContent && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="bg-blue-50/50 border border-blue-200/80 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-blue-950 text-base flex items-center gap-2">
                      <Eye className="w-5 h-5 text-blue-600" />
                      {isArabic ? lesson.visualContent.titleAr : lesson.visualContent.titleEn}
                    </h4>
                    <span className="text-xs bg-blue-200/70 text-blue-900 font-semibold px-2.5 py-0.5 rounded-full">
                      {isArabic ? 'خريطة بصرية تفاعلية' : 'Interactive Visual Map'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {isArabic ? lesson.visualContent.diagramDescriptionAr : lesson.visualContent.diagramDescriptionEn}
                  </p>

                  {/* Visual Diagram Representation Box */}
                  <div className="bg-white p-6 rounded-2xl border border-blue-100 flex flex-col items-center justify-center text-center relative overflow-hidden">
                    <div className="w-48 h-48 border-2 border-dashed border-blue-300 rounded-2xl flex items-center justify-center bg-blue-50/40 relative">
                      {/* Triangle schematic */}
                      <svg viewBox="0 0 120 120" className="w-40 h-40">
                        <polygon points="20,100 100,100 20,20" fill="rgba(129, 166, 198, 0.2)" stroke="#81A6C6" strokeWidth="3" />
                        <rect x="20" y="88" width="12" height="12" fill="none" stroke="#81A6C6" strokeWidth="1.5" />
                        {/* Leg labels */}
                        <text x="55" y="115" fontSize="10" fontWeight="bold" fill="#1e293b" textAnchor="middle">أ = 6 سم</text>
                        <text x="8" y="60" fontSize="10" fontWeight="bold" fill="#1e293b" textAnchor="middle">ب = 8 سم</text>
                        <text x="65" y="50" fontSize="11" fontWeight="bold" fill="#0284c7" textAnchor="middle">الوتر ج = 10 سم</text>
                      </svg>
                    </div>
                    <span className="text-xs font-mono text-slate-400 mt-2">a² + b² = c² (36 + 64 = 100)</span>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {isArabic ? 'النقاط البصرية الأساسية' : 'Visual Key Takeaways'}
                  </h5>
                  <div className="space-y-2">
                    {(isArabic ? lesson.visualContent.keyPointsAr : lesson.visualContent.keyPointsEn).map((pt, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-start gap-2.5 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Auditory Track */}
            {activeTab === 'auditory' && lesson.auditoryContent && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="bg-amber-50/50 border border-amber-200/80 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-amber-950 text-base flex items-center gap-2">
                      <Headphones className="w-5 h-5 text-amber-600" />
                      {isArabic ? lesson.auditoryContent.titleAr : lesson.auditoryContent.titleEn}
                    </h4>
                    <span className="text-xs bg-amber-200/70 text-amber-900 font-semibold px-2.5 py-0.5 rounded-full">
                      {lesson.auditoryContent.duration}
                    </span>
                  </div>

                  {/* Audio Player Simulator */}
                  <div className="p-4 bg-white rounded-2xl border border-amber-100 flex items-center gap-4">
                    <button
                      onClick={toggleAudio}
                      className="w-12 h-12 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center transition-all shadow-md cursor-pointer"
                    >
                      {isPlayingAudio ? <Volume2 className="w-6 h-6 animate-pulse" /> : <Play className="w-6 h-6 ms-0.5" />}
                    </button>
                    <div className="flex-1 space-y-1.5">
                      <div className="flex justify-between text-xs font-bold text-slate-700">
                        <span>{isPlayingAudio ? (isArabic ? 'جاري الاستماع...' : 'Playing Narration...') : (isArabic ? 'انقر للبدء بالاستماع' : 'Click to start audio')}</span>
                        <span>{lesson.auditoryContent.duration}</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div className={`bg-amber-500 h-full rounded-full transition-all ${isPlayingAudio ? 'w-2/3 animate-pulse' : 'w-0'}`} />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-white/80 rounded-xl border border-amber-100/60 text-xs text-slate-700 leading-relaxed font-serif">
                    <p className="italic">
                      "{isArabic ? lesson.auditoryContent.audioScriptAr : lesson.auditoryContent.audioScriptEn}"
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5 font-medium">
                  <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">{isArabic ? 'النغمة التذكارية: ' : 'Mnemonic Soundbite: '}</span>
                    <span>{isArabic ? lesson.auditoryContent.keyTakeawayAr : lesson.auditoryContent.keyTakeawayEn}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Reading Track */}
            {activeTab === 'reading' && lesson.readingContent && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="bg-emerald-50/50 border border-emerald-200/80 rounded-2xl p-5 space-y-4">
                  <h4 className="font-bold text-emerald-950 text-base flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-emerald-600" />
                    {isArabic ? lesson.readingContent.titleAr : lesson.readingContent.titleEn}
                  </h4>
                  <p className="text-xs text-slate-700 leading-relaxed font-medium">
                    {isArabic ? lesson.readingContent.textAr : lesson.readingContent.textEn}
                  </p>
                </div>

                <div className="space-y-2.5">
                  <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {isArabic ? 'التعريفات والمعادلات الهيكلية' : 'Core Definitions & Formulas'}
                  </h5>
                  <div className="space-y-2">
                    {(isArabic ? lesson.readingContent.bulletPointsAr : lesson.readingContent.bulletPointsEn).map((bp, idx) => (
                      <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-800 font-mono">
                        • {bp}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Hands-on Track */}
            {activeTab === 'handsOn' && lesson.handsOnContent && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="bg-purple-50/50 border border-purple-200/80 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-purple-950 text-base flex items-center gap-2">
                      <Wrench className="w-5 h-5 text-purple-600" />
                      {isArabic ? lesson.handsOnContent.titleAr : lesson.handsOnContent.titleEn}
                    </h4>
                    <span className="text-xs bg-purple-200/70 text-purple-900 font-semibold px-2.5 py-0.5 rounded-full">
                      {isArabic ? 'نشاط معملي تفاعلي' : 'Hands-on Lab'}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-purple-900">
                    {isArabic ? 'الهدف المعملي: ' : 'Lab Goal: '}
                    <span className="font-normal text-slate-700">
                      {isArabic ? lesson.handsOnContent.experimentGoalAr : lesson.handsOnContent.experimentGoalEn}
                    </span>
                  </p>
                </div>

                <div className="space-y-2.5">
                  <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {isArabic ? 'خطوات التنفيذ العملي' : 'Step-by-Step Practical Lab'}
                  </h5>
                  <div className="space-y-2">
                    {(isArabic ? lesson.handsOnContent.stepsAr : lesson.handsOnContent.stepsEn).map((st, idx) => (
                      <div key={idx} className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/70 flex items-start gap-3 text-xs text-slate-700">
                        <span className="w-5 h-5 rounded-full bg-purple-600 text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed">{st}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {lesson.handsOnContent.challengeAr && (
                  <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200 text-xs text-amber-950 space-y-1">
                    <div className="font-bold flex items-center gap-1.5 text-amber-800">
                      <Sparkles className="w-4 h-4" />
                      {isArabic ? 'تحدي الـ 5 دقائق الذكي:' : '5-Minute Smart Challenge:'}
                    </div>
                    <p>{isArabic ? lesson.handsOnContent.challengeAr : lesson.handsOnContent.challengeEn}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Interactive AI Study Tutor Drawer */}
          <div className="bg-slate-50 border-t lg:border-t-0 lg:border-s border-slate-200 flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-200/80 bg-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="font-bold text-xs text-slate-800">{t.student.askAiTutor}</h5>
                  <p className="text-[10px] text-slate-400">{isArabic ? 'مساعد مدرار الذكي التفاعلي' : 'Midrar AI Learning Assistant'}</p>
                </div>
              </div>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            </div>

            {/* Chat message list */}
            <div className="flex-1 p-3.5 overflow-y-auto custom-scrollbar space-y-3">
              {tutorChat.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.sender === 'student' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${
                      msg.sender === 'student'
                        ? 'bg-[#81A6C6] text-white rounded-br-none'
                        : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none shadow-2xs'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isAskingTutor && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-200 p-3 rounded-2xl text-xs text-slate-400 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#81A6C6] animate-bounce" />
                    <span>{isArabic ? 'المساعد الذكي يفكر في أفضل تلميح...' : 'AI Tutor thinking...'}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Input Form */}
            <form onSubmit={handleAskTutor} className="p-3 bg-white border-t border-slate-200 flex gap-2">
              <input
                type="text"
                value={tutorQuery}
                onChange={(e) => setTutorQuery(e.target.value)}
                placeholder={t.student.aiTutorPlaceholder}
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#81A6C6]"
              />
              <button
                type="submit"
                disabled={!tutorQuery.trim() || isAskingTutor}
                className="p-2.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white rounded-xl disabled:opacity-40 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5 rtl:rotate-180" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
