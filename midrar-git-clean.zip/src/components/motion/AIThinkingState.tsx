import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../../i18n/LanguageContext';
import { motionTokens } from '../../motion/tokens';
import { Sparkles, BrainCircuit } from 'lucide-react';

interface AIThinkingStateProps {
  customMessages?: string[];
  className?: string;
}

export const AIThinkingState: React.FC<AIThinkingStateProps> = ({
  customMessages,
  className = '',
}) => {
  const { isArabic } = useLanguage();

  const defaultMessages = isArabic
    ? [
        'نحلل مستوى الطالب ونمط التعلم المفضل...',
        'نراجع الأداء الأخير ونقاط القوة والفرص...',
        'نبني خطة وتوصيات شخصية مخصصة بالذكاء الاصطناعي...',
      ]
    : [
        'Analyzing student proficiency and learning modality...',
        'Evaluating recent performance and knowledge milestones...',
        'Synthesizing adaptive recommendations with Midrar Assistant...',
      ];

  const messages = customMessages || defaultMessages;
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % messages.length);
    }, 1800);
    return () => clearInterval(interval);
  }, [messages.length]);

  return (
    <div className={`flex flex-col items-center justify-center p-6 space-y-4 text-center ${className}`}>
      {/* Dynamic Glowing Halo + Pulsing Neural Core */}
      <div className="relative flex items-center justify-center">
        {/* Soft atmospheric ambient glow */}
        <motion.div
          animate={{
            scale: [1, 1.25, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute w-20 h-20 rounded-full bg-gradient-to-tr from-[#81A6C6]/40 via-[#AACDDC]/40 to-[#F3E3D0]/60 blur-xl pointer-events-none"
        />

        {/* Outer Orbiting Particle */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
          className="absolute w-16 h-16 pointer-events-none"
        >
          <div className="w-2.5 h-2.5 rounded-full bg-[#81A6C6] shadow-sm shadow-[#81A6C6]/50" />
        </motion.div>

        {/* Central Brain/AI Icon */}
        <div className="relative z-10 w-12 h-12 rounded-2xl bg-white/90 border border-white/90 shadow-md backdrop-blur-md flex items-center justify-center text-[#81A6C6]">
          <BrainCircuit className="w-6 h-6 animate-pulse" />
        </div>
      </div>

      {/* Dynamic Step Text */}
      <div className="h-7 flex items-center justify-center overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.p
            key={activeStep}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: motionTokens.duration.fast, ease: motionTokens.easing.standard }}
            className="text-xs sm:text-sm font-semibold text-slate-700 max-w-sm"
          >
            {messages[activeStep]}
          </motion.p>
        </AnimatePresence>
      </div>

      {/* Subtle Step Dots */}
      <div className="flex items-center gap-1.5">
        {messages.map((_, idx) => (
          <motion.div
            key={idx}
            animate={{
              scale: activeStep === idx ? 1.3 : 1,
              backgroundColor: activeStep === idx ? '#81A6C6' : '#E2E8F0',
            }}
            transition={{ duration: 0.25 }}
            className="w-2 h-2 rounded-full"
          />
        ))}
      </div>
    </div>
  );
};
