import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { motionTokens } from '../../motion/tokens';
import { Sparkles, Trophy, Star } from 'lucide-react';

interface AchievementCelebrationProps {
  title: string;
  subtitle?: string;
  points?: number;
  onDismiss?: () => void;
}

export const AchievementCelebration: React.FC<AchievementCelebrationProps> = ({
  title,
  subtitle,
  points,
  onDismiss,
}) => {
  const [show, setShow] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShow(false);
      onDismiss?.();
    }, 3800);
    return () => clearTimeout(timer);
  }, [onDismiss]);

  // Subtle floating confetti particles
  const particles = Array.from({ length: 18 });

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: motionTokens.duration.fast }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs pointer-events-auto"
        >
          {/* Confetti Particles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {particles.map((_, i) => {
              const startX = (i % 6) * 16 + 10;
              const randomDelay = (i * 0.08) % 0.6;
              const colors = ['#81A6C6', '#AACDDC', '#F3E3D0', '#F59E0B', '#10B981'];
              const color = colors[i % colors.length];

              return (
                <motion.div
                  key={i}
                  initial={{
                    x: `${startX}vw`,
                    y: '45vh',
                    scale: 0,
                    rotate: 0,
                    opacity: 1,
                  }}
                  animate={{
                    x: `${startX + (i % 2 === 0 ? 8 : -8)}vw`,
                    y: ['45vh', '20vh', '80vh'],
                    scale: [0, 1.2, 0.8],
                    rotate: [0, 180, 360],
                    opacity: [1, 1, 0],
                  }}
                  transition={{
                    duration: 2.2,
                    delay: randomDelay,
                    ease: 'easeOut',
                  }}
                  className="absolute w-2.5 h-2.5 rounded-sm"
                  style={{ backgroundColor: color }}
                />
              );
            })}
          </div>

          {/* Celebration Card */}
          <motion.div
            initial={{ scale: 0.8, y: 30, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 20, opacity: 0 }}
            transition={motionTokens.spring.playful}
            className="relative z-10 max-w-sm w-full bg-white/95 rounded-3xl p-6 border border-white/90 shadow-2xl backdrop-blur-xl text-center space-y-4"
          >
            {/* Animated Trophy Icon */}
            <motion.div
              initial={{ scale: 0, rotate: -25 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.15, ...motionTokens.spring.playful }}
              className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 to-amber-200 text-amber-900 flex items-center justify-center shadow-lg shadow-amber-300/40"
            >
              <Trophy className="w-8 h-8 fill-amber-300" />
            </motion.div>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 fill-amber-400" />
                <span>إنجاز جديد رائع! • Achievement Unlocked!</span>
              </div>
              <h3 className="text-xl font-extrabold text-slate-800 pt-1">{title}</h3>
              {subtitle && <p className="text-xs text-slate-500 font-medium">{subtitle}</p>}
            </div>

            {points && (
              <div className="py-2 px-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-800 font-extrabold text-sm flex items-center justify-center gap-2">
                <Star className="w-4 h-4 fill-emerald-500 text-emerald-500" />
                <span>+{points} نقطة خبرة (XP)</span>
              </div>
            )}

            <button
              onClick={() => {
                setShow(false);
                onDismiss?.();
              }}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
            >
              متابعة التعلم • Continue
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
