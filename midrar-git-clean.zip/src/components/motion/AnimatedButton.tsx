import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { motionTokens } from '../../motion/tokens';
import { Loader2, Check } from 'lucide-react';

interface AnimatedButtonProps extends HTMLMotionProps<'button'> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'glass';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  isSuccess?: boolean;
  isError?: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  id?: string;
}

export const AnimatedButton: React.FC<AnimatedButtonProps> = ({
  variant = 'primary',
  size = 'md',
  isLoading = false,
  isSuccess = false,
  isError = false,
  icon,
  children,
  className = '',
  disabled,
  id,
  ...props
}) => {
  const variantStyles = {
    primary: 'bg-[#81A6C6] hover:bg-[#7095b5] text-white shadow-sm hover:shadow-md border border-transparent',
    secondary: 'bg-slate-800 hover:bg-slate-900 text-white shadow-sm hover:shadow-md',
    outline: 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300',
    ghost: 'bg-transparent hover:bg-slate-100/80 text-slate-700',
    glass: 'bg-white/80 hover:bg-white/95 text-slate-800 border border-white/90 backdrop-blur-md shadow-2xs',
  };

  const sizeStyles = {
    sm: 'px-3.5 py-1.5 text-xs rounded-xl gap-1.5',
    md: 'px-5 py-2.5 text-xs sm:text-sm rounded-xl gap-2',
    lg: 'px-6 py-3.5 text-sm sm:text-base rounded-2xl gap-2.5 font-bold',
  };

  return (
    <motion.button
      id={id}
      whileHover={!disabled && !isLoading ? { y: -1.5, scale: 1.01 } : undefined}
      whileTap={!disabled && !isLoading ? { scale: 0.975 } : undefined}
      animate={
        isError
          ? {
              x: [0, -4, 4, -4, 4, 0],
              transition: { duration: 0.3 },
            }
          : undefined
      }
      transition={motionTokens.spring.responsive}
      disabled={disabled || isLoading}
      className={`inline-flex items-center justify-center font-bold tracking-tight whitespace-nowrap select-none cursor-pointer transition-all duration-200 ${
        variantStyles[variant]
      } ${sizeStyles[size]} ${
        disabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''
      } ${className}`}
      {...props}
    >
      {isLoading ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin shrink-0" />
          <span className="whitespace-nowrap inline-flex items-center gap-1.5">{children}</span>
        </>
      ) : isSuccess ? (
        <>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={motionTokens.spring.playful}
          >
            <Check className="w-4 h-4 text-emerald-300 stroke-[3]" />
          </motion.div>
          <span className="whitespace-nowrap inline-flex items-center gap-1.5">{children}</span>
        </>
      ) : (
        <>
          {icon && <span className="shrink-0 inline-flex items-center">{icon}</span>}
          <span className="whitespace-nowrap inline-flex items-center gap-2">{children}</span>
        </>
      )}
    </motion.button>
  );
};
