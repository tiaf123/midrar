import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { motionTokens } from '../../motion/tokens';

interface AnimatedCardProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
  clickable?: boolean;
  id?: string;
}

export const AnimatedCard: React.FC<AnimatedCardProps> = ({
  children,
  className = '',
  glow = false,
  clickable = false,
  id,
  ...props
}) => {
  return (
    <motion.div
      id={id}
      whileHover={
        clickable
          ? {
              y: -3,
              boxShadow: '0 12px 28px -6px rgba(0, 0, 0, 0.08), 0 4px 10px -2px rgba(0, 0, 0, 0.03)',
              transition: motionTokens.spring.responsive,
            }
          : undefined
      }
      whileTap={
        clickable
          ? {
              scale: 0.985,
              transition: { duration: motionTokens.duration.instant },
            }
          : undefined
      }
      className={`relative rounded-3xl transition-colors duration-200 ${
        glow ? 'hover:border-[#81A6C6]/60' : ''
      } ${className}`}
      {...props}
    >
      {children}
    </motion.div>
  );
};
