import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../i18n/LanguageContext';
import { motionTokens, getDirectionalOffset } from '../../motion/tokens';

interface MotionPageProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
}

export const MotionPage: React.FC<MotionPageProps> = ({ children, className = '', id }) => {
  const { isArabic } = useLanguage();
  const offset = getDirectionalOffset(isArabic, 16);

  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, x: offset.enterX, y: 8 }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      exit={{ opacity: 0, x: offset.exitX, y: -8 }}
      transition={{
        duration: motionTokens.duration.normal,
        ease: motionTokens.easing.standard,
      }}
      className={`w-full ${className}`}
    >
      {children}
    </motion.div>
  );
};
