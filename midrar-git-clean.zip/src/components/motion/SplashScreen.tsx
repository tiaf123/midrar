import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { motionTokens } from '../../motion/tokens';
import { Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete?: () => void;
  forceShow?: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete, forceShow = false }) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Check if splash was already shown in this session
    const hasSeenSplash = sessionStorage.getItem('midrar_splash_shown');
    if (hasSeenSplash && !forceShow) {
      setIsVisible(false);
      onComplete?.();
      return;
    }

    const timer = setTimeout(() => {
      handleDismiss();
    }, 1600);

    return () => clearTimeout(timer);
  }, [forceShow]);

  const handleDismiss = () => {
    sessionStorage.setItem('midrar_splash_shown', 'true');
    setIsVisible(false);
    onComplete?.();
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          key="splash-screen"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: motionTokens.duration.normal, ease: motionTokens.easing.exit }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-[#FAF9F6] via-[#F3E3D0]/40 to-[#AACDDC]/30 backdrop-blur-2xl"
        >
          {/* Ambient Glows */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [0.8, 1.2, 1], opacity: [0, 0.4, 0.25] }}
            transition={{ duration: 1.4, ease: 'easeInOut' }}
            className="absolute w-96 h-96 rounded-full bg-[#81A6C6]/30 blur-3xl pointer-events-none"
          />

          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: [0.6, 1.1, 0.9], opacity: [0, 0.35, 0.2] }}
            transition={{ duration: 1.5, delay: 0.2, ease: 'easeInOut' }}
            className="absolute w-72 h-72 rounded-full bg-[#F3E3D0]/60 blur-2xl pointer-events-none"
          />

          {/* Central Animated Book Emblem & Rays */}
          <div className="relative z-10 flex flex-col items-center">
            {/* Outer Knowledge Rays SVG */}
            <motion.svg
              className="w-44 h-44 absolute -top-8 text-[#81A6C6]/40 pointer-events-none"
              viewBox="0 0 100 100"
              initial={{ rotate: -20, opacity: 0, scale: 0.7 }}
              animate={{ rotate: 0, opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: motionTokens.easing.enter }}
            >
              <motion.circle
                cx="50"
                cy="50"
                r="44"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeDasharray="4 6"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              />
            </motion.svg>

            {/* Book Opening / Unfurling Graphic */}
            <motion.div
              initial={{ scale: 0.7, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              transition={motionTokens.spring.responsive}
              className="relative p-5 rounded-3xl bg-white/80 shadow-2xl border border-white/90 backdrop-blur-md"
            >
              <img
                src="/midrar.png"
                alt="Midrar Emblem"
                className="w-20 h-20 object-contain drop-shadow-md"
              />

              {/* AI Beam Light Point */}
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: [0, 1.4, 1], opacity: [0, 1, 0.8] }}
                transition={{ delay: 0.4, duration: 0.6, ease: motionTokens.easing.enter }}
                className="absolute -top-2 -end-2 p-1.5 rounded-full bg-gradient-to-tr from-amber-400 to-amber-200 text-amber-900 shadow-md"
              >
                <Sparkles className="w-4 h-4 fill-amber-300" />
              </motion.div>
            </motion.div>

            {/* Platform Slogan & Brand reveal */}
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35, duration: motionTokens.duration.normal, ease: motionTokens.easing.enter }}
              className="mt-6 text-center space-y-1.5"
            >
              <h1 className="text-2xl font-extrabold text-slate-800 tracking-tight flex items-center justify-center gap-2">
                <span>مِدْرار</span>
                <span className="w-2 h-2 rounded-full bg-[#81A6C6] inline-block animate-ping" />
                <span className="text-slate-400 text-base font-normal">| Midrar</span>
              </h1>
              <p className="text-xs font-semibold text-slate-500 max-w-xs">
                تعليم يفهمك وينمو معك — Adaptive Learning Platform
              </p>
            </motion.div>

            {/* Subtle Loading Progress Bar */}
            <div className="mt-8 w-40 h-1.5 bg-slate-200/80 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: '0%' }}
                animate={{ width: '100%' }}
                transition={{ duration: 1.3, ease: motionTokens.easing.standard }}
                className="h-full bg-gradient-to-r from-[#81A6C6] via-[#AACDDC] to-[#D2C4B4] rounded-full"
              />
            </div>
          </div>

          {/* Quick Skip button */}
          <button
            onClick={handleDismiss}
            className="absolute bottom-6 text-xs text-slate-400 hover:text-slate-700 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
          >
            تخطي • Skip
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
