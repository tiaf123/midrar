import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Trophy,
  RotateCcw
} from 'lucide-react';

export const QuizRunnerModal: React.FC = () => {
  const { selectedQuizId, setSelectedQuizId, quizzes, completeQuiz, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [hintsUnlocked, setHintsUnlocked] = useState<Record<string, number>>({}); // questionId -> 1 or 2
  const [isFinished, setIsFinished] = useState(false);

  if (!selectedQuizId) return null;
  const quiz = quizzes.find((q) => q.id === selectedQuizId);
  if (!quiz) return null;

  const currentQ = quiz.questions[currentIndex];
  const totalQ = quiz.questions.length;

  const handleSelect = (idx: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentQ.id]: idx
    }));
  };

  const handleUnlockHint = () => {
    const currentHintLevel = hintsUnlocked[currentQ.id] || 0;
    if (currentHintLevel < 2) {
      setHintsUnlocked((prev) => ({
        ...prev,
        [currentQ.id]: currentHintLevel + 1
      }));
      showToast(isArabic ? `تم فتح التلميح رقم ${currentHintLevel + 1}` : `Unlocked Hint #${currentHintLevel + 1}`, 'info');
    }
  };

  const handleNext = () => {
    if (selectedAnswers[currentQ.id] === undefined) {
      showToast(isArabic ? 'يرجى اختيار إجابة للمتابعة' : 'Please choose an answer', 'warning');
      return;
    }

    if (currentIndex < totalQ - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Calculate score
      let correctCount = 0;
      quiz.questions.forEach((q) => {
        if (selectedAnswers[q.id] === q.correctIndex) {
          correctCount++;
        }
      });
      const score = Math.round((correctCount / totalQ) * 100);
      completeQuiz(quiz.id, score);
      setIsFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedAnswers({});
    setHintsUnlocked({});
    setIsFinished(false);
  };

  const hintLevel = hintsUnlocked[currentQ?.id] || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50/40 via-white to-purple-50/40">
          <div>
            <span className="text-xs font-bold text-[#81A6C6]">
              {isArabic ? quiz.subjectTitleAr : quiz.subjectTitleEn}
            </span>
            <h3 className="text-lg font-bold text-slate-800">
              {isArabic ? quiz.titleAr : quiz.titleEn}
            </h3>
          </div>
          <button
            onClick={() => setSelectedQuizId(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!isFinished ? (
          <div className="flex-1 p-6 overflow-y-auto custom-scrollbar flex flex-col">
            {/* Progress */}
            <div className="mb-4 flex items-center justify-between text-xs font-bold text-slate-400">
              <span>{isArabic ? `السؤال ${currentIndex + 1} من ${totalQ}` : `Question ${currentIndex + 1} of ${totalQ}`}</span>
              <span>{Math.round(((currentIndex + 1) / totalQ) * 100)}%</span>
            </div>

            {/* Question Text */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 mb-5">
              <h4 className="text-base font-bold text-slate-800 leading-relaxed">
                {isArabic ? currentQ.questionAr : currentQ.questionEn}
              </h4>
            </div>

            {/* Options */}
            <div className="space-y-2.5 flex-1">
              {(isArabic ? currentQ.optionsAr : currentQ.optionsEn).map((opt, idx) => {
                const isSelected = selectedAnswers[currentQ.id] === idx;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelect(idx)}
                    className={`w-full p-4 rounded-2xl border text-start transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-[#81A6C6]/15 border-[#81A6C6] text-slate-900 font-bold shadow-xs ring-1 ring-[#81A6C6]'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/70 text-slate-700'
                    }`}
                  >
                    <span className="text-sm">{opt}</span>
                    <span
                      className={`w-5 h-5 rounded-full border flex items-center justify-center text-xs ${
                        isSelected ? 'border-[#81A6C6] bg-[#81A6C6] text-white' : 'border-slate-300'
                      }`}
                    >
                      {isSelected ? '✓' : ''}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Smart Hint Box */}
            <div className="mt-5 p-4 bg-amber-50/70 border border-amber-200/80 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  {isArabic ? 'تلميحات المساعد الذكي التدرجية' : 'Smart Hints'}
                </span>
                {hintLevel < 2 && (
                  <button
                    type="button"
                    onClick={handleUnlockHint}
                    className="text-xs font-bold text-amber-800 hover:text-amber-950 underline cursor-pointer"
                  >
                    {isArabic ? (hintLevel === 0 ? 'طلب تلميح 1' : 'طلب تلميح 2') : (hintLevel === 0 ? 'Get Hint 1' : 'Get Hint 2')}
                  </button>
                )}
              </div>

              {hintLevel >= 1 && (
                <div className="text-xs text-amber-900 font-medium p-2.5 bg-white/70 rounded-xl border border-amber-100 animate-in fade-in">
                  💡 {isArabic ? currentQ.hint1Ar : currentQ.hint1En}
                </div>
              )}
              {hintLevel >= 2 && (
                <div className="text-xs text-amber-900 font-medium p-2.5 bg-white/70 rounded-xl border border-amber-100 animate-in fade-in">
                  🎯 {isArabic ? currentQ.hint2Ar : currentQ.hint2En}
                </div>
              )}
            </div>

            {/* Bottom Nav */}
            <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex((prev) => prev - 1)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 disabled:opacity-30 cursor-pointer"
              >
                {t.common.previous}
              </button>

              <button
                type="button"
                onClick={handleNext}
                className="px-6 py-2.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <span>{currentIndex === totalQ - 1 ? t.common.finish : t.common.next}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
          </div>
        ) : (
          /* Results summary */
          <div className="flex-1 p-6 overflow-y-auto custom-scrollbar space-y-6 text-center">
            <div className="w-16 h-16 rounded-3xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto shadow-inner">
              <Trophy className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h4 className="text-xl font-bold text-slate-800">
                {isArabic ? 'رائع جداً! تم إكمال الاختبار' : 'Outstanding! Quiz Completed'}
              </h4>
              <p className="text-xs text-slate-500">
                {isArabic ? `لقد أحرزت ${quiz.scoreAchieved || 100}% في هذا التقييم` : `You scored ${quiz.scoreAchieved || 100}%`}
              </p>
            </div>

            {/* Explanations list */}
            <div className="space-y-3 text-start">
              {quiz.questions.map((q, i) => {
                const userAns = selectedAnswers[q.id];
                const isCorrect = userAns === q.correctIndex;
                return (
                  <div key={q.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-slate-800">{isArabic ? `سؤال ${i + 1}` : `Question ${i + 1}`}</span>
                      {isCorrect ? (
                        <span className="text-emerald-700 flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" /> {isArabic ? 'إجابة صحيحة' : 'Correct'}
                        </span>
                      ) : (
                        <span className="text-rose-700 flex items-center gap-1">
                          <AlertCircle className="w-4 h-4" /> {isArabic ? 'بحاجة لمراجعة' : 'Incorrect'}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 font-medium">
                      {isArabic ? q.questionAr : q.questionEn}
                    </p>
                    <p className="text-xs text-blue-900 bg-blue-50 p-2.5 rounded-xl border border-blue-100">
                      💡 {isArabic ? q.explanationAr : q.explanationEn}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleRestart}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{isArabic ? 'إعادة المحاولة' : 'Retake Quiz'}</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedQuizId(null)}
                className="px-6 py-2.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white text-xs font-bold rounded-xl shadow-md cursor-pointer"
              >
                {t.common.close}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
