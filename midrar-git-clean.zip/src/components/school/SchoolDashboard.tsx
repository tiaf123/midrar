import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  School,
  Briefcase,
  Search,
  Star,
  MapPin,
  Sparkles,
  TrendingUp,
  Award,
  Send,
  MessageSquare,
  Users,
  CheckCircle2,
  Filter
} from 'lucide-react';

export const SchoolDashboard: React.FC = () => {
  const {
    teachersCatalog,
    setSelectedTeacherId,
    setActiveConversationId,
    setActiveModal
  } = useApp();
  const { isArabic, t } = useLanguage();

  const [searchSubject, setSearchSubject] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTeachers = teachersCatalog.filter((t) => {
    const matchesQuery = t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.titleAr.includes(searchQuery) ||
      t.titleEn.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (searchSubject === 'all') return matchesQuery;
    return matchesQuery && (t.subjectsAr.includes(searchSubject) || t.subjectsEn.includes(searchSubject));
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* 1. School Institutional Banner */}
      <div className="bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-blue-500/10 rounded-3xl p-6 sm:p-8 border border-purple-200/60 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-purple-800 uppercase tracking-wider">
              {isArabic ? 'بوابة المدارس واستقطاب الكفاءات' : 'Institutional & Faculty Recruitment Hub'}
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-600 text-white">
              {isArabic ? 'مدارس التميز الأهلية' : 'Al-Tamyoz Private Academy'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {isArabic ? 'اكتشاف واستقطاب نخبة المعلمين المتميزين' : 'Discover & Recruit Top-Tier Verified Faculty'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
            {isArabic
              ? 'تصفح سجلات الإنجاز وتقييمات أولياء الأمور وأرسل عروض استقطاب رسمية ومباشرة للكوادر التعليمية.'
              : 'Browse verified teacher track records, parent satisfaction index, and send direct recruitment contracts.'}
          </p>
        </div>

        {/* Institutional Metrics */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs text-center min-w-[110px]">
            <span className="text-[10px] font-bold text-slate-400 uppercase">{t.school.satisfactionIndex}</span>
            <p className="text-xl font-extrabold text-purple-600">94.8%</p>
          </div>
          <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-2xs text-center min-w-[110px]">
            <span className="text-[10px] font-bold text-slate-400 uppercase">{t.school.cohortProgress}</span>
            <p className="text-xl font-extrabold text-emerald-600">89.2%</p>
          </div>
        </div>
      </div>

      {/* 2. Search & Filter Faculty Market */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-purple-600" />
              <span>{t.school.talentMarketTitle}</span>
            </h3>
            <p className="text-xs text-slate-500">{t.school.talentMarketSubtitle}</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute start-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isArabic ? 'ابحث بالاسم أو التخصص...' : 'Search by name or subject...'}
                className="ps-9 pe-4 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500 w-52 sm:w-64"
              />
            </div>

            <select
              value={searchSubject}
              onChange={(e) => setSearchSubject(e.target.value)}
              className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
            >
              <option value="all">{isArabic ? 'جميع التخصصات' : 'All Subjects'}</option>
              <option value="الرياضيات">{isArabic ? 'الرياضيات' : 'Mathematics'}</option>
              <option value="العلوم الطبيعية">{isArabic ? 'العلوم الطبيعية' : 'Science'}</option>
              <option value="اللغة الإنجليزية">{isArabic ? 'اللغة الإنجليزية' : 'English'}</option>
            </select>
          </div>
        </div>

        {/* Teachers Catalog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filteredTeachers.map((teacher) => (
            <div
              key={teacher.id}
              className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start gap-3.5">
                  <img
                    src={teacher.avatarUrl}
                    alt={teacher.name}
                    className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-slate-100"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 text-sm truncate">{teacher.name}</h4>
                      {teacher.isAvailableForRecruitment && (
                        <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full shrink-0">
                          {t.teacher.available}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 truncate">{isArabic ? teacher.titleAr : teacher.titleEn}</p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1 text-amber-500 font-bold">
                        <Star className="w-3.5 h-3.5 fill-amber-400" /> {teacher.rating}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" /> {isArabic ? teacher.cityAr : teacher.cityEn}
                      </span>
                      <span>•</span>
                      <span>{teacher.experienceYears} {isArabic ? 'سنوات' : 'yrs'}</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                  {isArabic ? teacher.bioAr : teacher.bioEn}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {(isArabic ? teacher.subjectsAr : teacher.subjectsEn).map((subj, idx) => (
                    <span key={idx} className="text-[10px] bg-blue-50 text-blue-800 font-semibold px-2.5 py-0.5 rounded-lg border border-blue-100">
                      {subj}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedTeacherId(teacher.id)}
                  className="flex-1 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <Send className="w-3.5 h-3.5 rtl:rotate-180" />
                  <span>{t.school.sendOffer}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveConversationId('conv-1');
                    setActiveModal('chat');
                  }}
                  className="p-2.5 bg-slate-100 hover:bg-slate-200/80 text-slate-700 rounded-xl cursor-pointer transition-colors"
                  title={t.common.messages}
                >
                  <MessageSquare className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
