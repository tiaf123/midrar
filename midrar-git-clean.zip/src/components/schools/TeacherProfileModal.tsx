import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  Star,
  MapPin,
  Briefcase,
  GraduationCap,
  MessageSquare,
  Send,
  Sparkles,
  CheckCircle2,
  ShieldCheck
} from 'lucide-react';

export const TeacherProfileModal: React.FC = () => {
  const {
    selectedTeacherId,
    setSelectedTeacherId,
    teachersCatalog,
    role,
    sendRecruitmentOffer,
    rateTeacherExperience,
    setActiveConversationId,
    setActiveModal,
    showToast
  } = useApp();
  const { isArabic, t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'profile' | 'offer' | 'rate'>('profile');
  const [offerSubject, setOfferSubject] = useState('');
  const [offerMessage, setOfferMessage] = useState('');
  const [ratingStars, setRatingStars] = useState(5);
  const [ratingFeedback, setRatingFeedback] = useState('');

  if (!selectedTeacherId) return null;
  const teacher = teachersCatalog.find((t) => t.id === selectedTeacherId);
  if (!teacher) return null;

  const handleSendOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offerSubject.trim() || !offerMessage.trim()) {
      showToast(isArabic ? 'يرجى كتابة المادة والرسالة' : 'Please fill all offer fields', 'warning');
      return;
    }
    sendRecruitmentOffer(teacher.id, offerSubject, offerMessage);
    setOfferSubject('');
    setOfferMessage('');
    setSelectedTeacherId(null);
  };

  const handleSendRating = (e: React.FormEvent) => {
    e.preventDefault();
    rateTeacherExperience(teacher.id, ratingStars, ratingFeedback);
    setRatingFeedback('');
    setSelectedTeacherId(null);
  };

  const handleDirectChat = () => {
    setActiveConversationId('conv-1');
    setSelectedTeacherId(null);
    setActiveModal('chat');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-start justify-between bg-gradient-to-br from-slate-50 via-white to-blue-50/30">
          <div className="flex items-center gap-4">
            <img
              src={teacher.avatarUrl}
              alt={teacher.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-white shadow-md shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900">{teacher.name}</h3>
                {teacher.isAvailableForRecruitment && (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                    {t.teacher.available}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{isArabic ? teacher.titleAr : teacher.titleEn}</p>
              <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                <span className="flex items-center gap-1 text-amber-500 font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-400" /> {teacher.rating} ({teacher.reviewsCount})
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" /> {isArabic ? teacher.cityAr : teacher.cityEn}
                </span>
                <span className="flex items-center gap-1">
                  <Briefcase className="w-3.5 h-3.5 text-slate-400" /> {teacher.experienceYears} {isArabic ? 'سنوات خبرة' : 'yrs exp'}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setSelectedTeacherId(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-6 pt-2 border-b border-slate-100 flex gap-4 bg-slate-50/50">
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`pb-2.5 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              activeTab === 'profile' ? 'border-[#81A6C6] text-[#81A6C6]' : 'border-transparent text-slate-400'
            }`}
          >
            {t.teacher.teacherProfile}
          </button>

          {role === 'school' && (
            <button
              type="button"
              onClick={() => setActiveTab('offer')}
              className={`pb-2.5 text-xs font-bold transition-all border-b-2 cursor-pointer ${
                activeTab === 'offer' ? 'border-[#81A6C6] text-[#81A6C6]' : 'border-transparent text-slate-400'
              }`}
            >
              {t.school.sendOffer}
            </button>
          )}

          {role === 'guardian' && (
            <button
              type="button"
              onClick={() => setActiveTab('rate')}
              className={`pb-2.5 text-xs font-bold transition-all border-b-2 cursor-pointer ${
                activeTab === 'rate' ? 'border-[#81A6C6] text-[#81A6C6]' : 'border-transparent text-slate-400'
              }`}
            >
              {t.guardian.rateTeacher}
            </button>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 p-6 overflow-y-auto custom-scrollbar space-y-6">
          {activeTab === 'profile' && (
            <div className="space-y-5">
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  {isArabic ? 'نبذة عن المعلم وفلسفته التعليمية' : 'Biography & Teaching Philosophy'}
                </h5>
                <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                  {isArabic ? teacher.bioAr : teacher.bioEn}
                </p>
              </div>

              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {isArabic ? 'المواد والمراحل الدراسية' : 'Subjects & Grade Levels'}
                </h5>
                <div className="flex flex-wrap gap-2">
                  {(isArabic ? teacher.subjectsAr : teacher.subjectsEn).map((subj, i) => (
                    <span key={i} className="px-3 py-1 bg-blue-50 text-blue-800 text-xs font-semibold rounded-xl border border-blue-200/60">
                      {subj}
                    </span>
                  ))}
                  {(isArabic ? teacher.gradeLevelsAr : teacher.gradeLevelsEn).map((gl, i) => (
                    <span key={i} className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-semibold rounded-xl border border-emerald-200/60">
                      {gl}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  {isArabic ? 'ملخص آراء وتقييمات أولياء الأمور' : 'Parent Reviews Summary'}
                </h5>
                <div className="p-4 bg-amber-50/60 border border-amber-200/80 rounded-2xl flex items-start gap-3 text-xs text-amber-950">
                  <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <p className="leading-relaxed font-medium">
                    {isArabic ? teacher.guardianReviewsSummaryAr : teacher.guardianReviewsSummaryEn}
                  </p>
                </div>
              </div>

              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={handleDirectChat}
                  className="flex-1 py-3 px-4 bg-[#81A6C6] hover:bg-[#7298b9] text-white text-xs font-bold rounded-xl shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>{isArabic ? 'محادثة المعلم المباشرة' : 'Direct Message'}</span>
                </button>

                {role === 'school' && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('offer')}
                    className="py-3 px-6 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow-sm cursor-pointer"
                  >
                    {t.school.sendOffer}
                  </button>
                )}
              </div>
            </div>
          )}

          {activeTab === 'offer' && (
            <form onSubmit={handleSendOffer} className="space-y-4">
              <div className="p-3.5 bg-purple-50 rounded-2xl border border-purple-200 flex items-center gap-2 text-xs text-purple-900">
                <ShieldCheck className="w-4 h-4 text-purple-600" />
                <span>{isArabic ? 'عرض استقطاب رسمي من إدارة المدرسة إلى المعلم' : 'Official institutional recruitment proposal'}</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.school.offerSubject}</label>
                <input
                  type="text"
                  required
                  value={offerSubject}
                  onChange={(e) => setOfferSubject(e.target.value)}
                  placeholder="مثال: معلم أول لمادة الرياضيات للمرحلة الثانوية"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.school.offerMessage}</label>
                <textarea
                  rows={4}
                  required
                  value={offerMessage}
                  onChange={(e) => setOfferMessage(e.target.value)}
                  placeholder="اكتب تفاصيل المزايا والموقع والحوافز الأكاديمية..."
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4 rtl:rotate-180" />
                <span>{t.school.sendOffer}</span>
              </button>
            </form>
          )}

          {activeTab === 'rate' && (
            <form onSubmit={handleSendRating} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">{t.guardian.rateStars}</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingStars(star)}
                      className="p-1.5 rounded-lg hover:scale-110 transition-transform cursor-pointer"
                    >
                      <Star
                        className={`w-7 h-7 ${
                          star <= ratingStars ? 'text-amber-400 fill-amber-400' : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.guardian.teacherRatingTitle}</label>
                <textarea
                  rows={4}
                  value={ratingFeedback}
                  onChange={(e) => setRatingFeedback(e.target.value)}
                  placeholder={t.guardian.ratingFeedbackPlaceholder}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#81A6C6] hover:bg-[#7298b9] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{t.common.submit}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
