import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  FileText,
  Calendar,
  Send,
  UploadCloud,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export const StudentAssignmentModal: React.FC = () => {
  const { activeModal, setActiveModal, assignments, submitAssignment, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [assignmentId, setAssignmentId] = useState<string>("ass-2");
  const [submissionText, setSubmissionText] = useState('');
  const [fileName, setFileName] = useState<string | null>(null);

  if (activeModal !== 'submit-assignment') return null;

  const currentAssignment = assignments.find((a) => a.id === assignmentId) || assignments[1] || assignments[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!submissionText.trim() && !fileName) {
      showToast(isArabic ? 'يرجى كتابة نص الحل أو إرفاق ملف' : 'Please provide answer text or attach a file', 'warning');
      return;
    }
    submitAssignment(currentAssignment.id, submissionText || `ملف مرفق: ${fileName}`);
    setActiveModal(null);
  };

  const handleSimulateUpload = () => {
    setFileName("Lab_Report_Newton_Ahmed.pdf");
    showToast(isArabic ? 'تم إرفاق ملف التقرير بنجاح' : 'Attached Lab_Report_Newton_Ahmed.pdf', 'info');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50/50 via-white to-purple-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">
                {isArabic ? currentAssignment.titleAr : currentAssignment.titleEn}
              </h3>
              <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                <Calendar className="w-3.5 h-3.5" />
                {isArabic ? `موعد التسليم: ${currentAssignment.dueDate}` : `Due: ${currentAssignment.dueDate}`}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
          {/* Instructions */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/70 space-y-2">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              {isArabic ? 'تعليمات الواجب والمعايير' : 'Assignment Instructions & Rubric'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              {isArabic ? currentAssignment.descriptionAr : currentAssignment.descriptionEn}
            </p>
            {currentAssignment.rubricAr && (
              <div className="flex flex-wrap gap-2 pt-1">
                {(isArabic ? currentAssignment.rubricAr : currentAssignment.rubricEn)?.map((r, i) => (
                  <span key={i} className="text-[11px] bg-blue-50 text-blue-800 font-medium px-2.5 py-0.5 rounded-lg border border-blue-100">
                    ✓ {r}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Solution Textarea */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isArabic ? 'اكتب إجابتك أو ملاحظات التجربة هنا:' : 'Write your answer or lab observations:'}
            </label>
            <textarea
              rows={4}
              value={submissionText}
              onChange={(e) => setSubmissionText(e.target.value)}
              placeholder="اكتب خطوات الحل أو استنتاجك العلمي بالتفصيل..."
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
            />
          </div>

          {/* File Upload Zone */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isArabic ? 'إرفاق ملف أو صور التجربة' : 'Attach File or Lab Photos'}
            </label>
            <button
              type="button"
              onClick={handleSimulateUpload}
              className="w-full p-4 border-2 border-dashed border-slate-200 hover:border-[#81A6C6] bg-slate-50/50 hover:bg-blue-50/30 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <UploadCloud className="w-6 h-6 text-[#81A6C6]" />
              <span className="text-xs font-medium text-slate-600">
                {fileName ? fileName : (isArabic ? 'انقر لإرفاق ملف PDF أو صورة للحل' : 'Click to attach PDF or solution photo')}
              </span>
              <span className="text-[10px] text-slate-400">PDF, PNG, JPG (Max 15MB)</span>
            </button>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Send className="w-4 h-4 rtl:rotate-180" />
            <span>{isArabic ? 'تسليم الواجب الآن' : 'Submit Assignment Now'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
