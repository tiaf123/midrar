import React from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  Flame,
  Zap,
  Award,
  BookOpen,
  Play,
  HelpCircle,
  FileCheck,
  Sparkles,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  BrainCircuit,
  Eye,
  Headphones,
  Wrench
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const {
    activeStudent,
    lessons,
    quizzes,
    assignments,
    setSelectedLessonId,
    setSelectedQuizId,
    setActiveModal
  } = useApp();
  const { isArabic, t } = useLanguage();

  const visualScore = activeStudent?.modalityScores?.visual ?? activeStudent?.learningPreferences?.visual ?? 38;
  const auditoryScore = activeStudent?.modalityScores?.auditory ?? activeStudent?.learningPreferences?.auditory ?? 25;
  const readingScore = activeStudent?.modalityScores?.reading ?? activeStudent?.learningPreferences?.readingWriting ?? 15;
  const interactiveScore = activeStudent?.modalityScores?.interactive_kinesthetic ?? activeStudent?.learningPreferences?.interactiveHandsOn ?? 30;

  const streak = activeStudent?.streakDays ?? activeStudent?.currentStreakDays ?? 7;
  const xp = activeStudent?.xpPoints ?? 1420;
  const badgesList = activeStudent?.badges ?? ['مستكشف الأنماط', 'بطل الرياضيات', 'المثابرة الذهبية'];

  const modalityIcons = {
    visual: Eye,
    auditory: Headphones,
    reading: BookOpen,
    interactive_kinesthetic: Wrench
  };

  const primaryModality = activeStudent?.primaryModality || (
    visualScore >= auditoryScore && visualScore >= readingScore && visualScore >= interactiveScore
      ? 'visual'
      : auditoryScore >= readingScore && auditoryScore >= interactiveScore
      ? 'auditory'
      : interactiveScore >= readingScore
      ? 'interactive_kinesthetic'
      : 'reading'
  );

  const PrimaryIcon = modalityIcons[primaryModality] || Eye;

  // Mandatory 25-Question Test Onboarding Gate if test not completed
  if (activeStudent && activeStudent.hasCompletedPreferenceTest === false) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-10 sm:py-16 space-y-8 animate-in fade-in duration-300">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#81A6C6]/15 via-white to-[#F3E3D0]/30 border border-[#81A6C6]/30 shadow-xl text-center space-y-6">
          {/* Animated Glowing Icon Core */}
          <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-3xl bg-[#81A6C6]/20 animate-ping opacity-30" />
            <div className="relative w-20 h-20 rounded-3xl bg-gradient-to-br from-[#81A6C6] to-[#6087a9] text-white flex items-center justify-center shadow-lg shadow-[#81A6C6]/40">
              <BrainCircuit className="w-10 h-10 animate-pulse" />
            </div>
          </div>

          <div className="space-y-3 max-w-xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100/90 text-amber-900 text-xs font-bold border border-amber-200">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>{isArabic ? 'خطوة أولى ضرورية لتخصيص تجربتك' : 'Mandatory Step: Diagnostic Assessment'}</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {isArabic ? `أهلاً بك يا ${activeStudent.name}! 🌟` : `Welcome, ${activeStudent.name}! 🌟`}
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              {isArabic
                ? 'قبل أن تبدأ، يرجى إكمال مقياس تفضيلات التعلم الذكي المكون من 25 سؤالاً وموقفاً دراسياً واقعياً. سيقوم مساعد مِدْرار الذكي بتحليل نمطك وتثبيت تفضيلاتك (بصري، سمعي، قرائي، وتطبيقي) بشكل دائم لتخصيص مسارك التعليمي ودروسك.'
                : 'Before starting, please complete the 25-question smart modality assessment. Midrar Smart Assistant will analyze your style and permanently save your learning preferences (Visual, Auditory, Reading, and Hands-on) to tailor your lessons.'}
            </p>
          </div>

          {/* 4 Modalities Preview */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto pt-2">
            <div className="p-4 rounded-2xl bg-blue-50/90 border border-blue-100/80 text-center space-y-1.5 shadow-2xs hover:scale-105 transition-transform">
              <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
                <Eye className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-blue-900 block">{isArabic ? 'مسار بصري' : 'Visual Track'}</span>
              <p className="text-[10px] text-blue-700/80">{isArabic ? 'رسوم ومخططات' : 'Diagrams & Maps'}</p>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50/90 border border-amber-100/80 text-center space-y-1.5 shadow-2xs hover:scale-105 transition-transform">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
                <Headphones className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-amber-900 block">{isArabic ? 'مسار سمعي' : 'Auditory Track'}</span>
              <p className="text-[10px] text-amber-700/80">{isArabic ? 'سرد وحوار صوتي' : 'Voice & Audio'}</p>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/90 border border-emerald-100/80 text-center space-y-1.5 shadow-2xs hover:scale-105 transition-transform">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <BookOpen className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-emerald-900 block">{isArabic ? 'مسار قرائي' : 'Reading Track'}</span>
              <p className="text-[10px] text-emerald-700/80">{isArabic ? 'ملخصات ونقاط' : 'Summaries & Texts'}</p>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50/90 border border-purple-100/80 text-center space-y-1.5 shadow-2xs hover:scale-105 transition-transform">
              <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mx-auto">
                <Wrench className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-purple-900 block">{isArabic ? 'مسار تطبيقي' : 'Hands-on Track'}</span>
              <p className="text-[10px] text-purple-700/80">{isArabic ? 'تجارب ومحاكاة' : 'Labs & Practice'}</p>
            </div>
          </div>

          {/* Call to Action Button */}
          <div className="pt-4 flex justify-center">
            <button
              onClick={() => setActiveModal('learning-test')}
              className="px-8 py-4 rounded-2xl bg-[#81A6C6] hover:bg-[#6f96b9] text-white font-bold text-sm sm:text-base shadow-xl shadow-[#81A6C6]/30 flex items-center gap-3 cursor-pointer transition-all transform hover:scale-[1.03] active:scale-[0.98]"
            >
              <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
              <span>{isArabic ? 'ابدأ اختبار تفضيلات التعلم الآن (25 سؤالاً)' : 'Start 25-Question Assessment Now'}</span>
              <ArrowRight className="w-5 h-5 rtl:rotate-180" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* 1. Welcome & Gamification Banner */}
      <div className="bg-gradient-to-r from-[#81A6C6]/20 via-[#AACDDC]/20 to-[#F3E3D0]/30 rounded-3xl p-6 sm:p-8 border border-[#81A6C6]/30 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#81A6C6] uppercase tracking-wider">
              {isArabic ? 'بوابة الطالب الذكية' : 'Student Adaptive Hub'}
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#81A6C6] text-white">
              {activeStudent?.gradeLevel || (isArabic ? 'المرحلة المتوسطة' : 'Middle School')}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {isArabic ? `مرحباً بك يا ${activeStudent?.name || 'البطل'}! 👋` : `Welcome back, ${activeStudent?.name || 'Student'}! 👋`}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
            {isArabic
              ? 'خطتك التعليمية الشخصية مهيأة اليوم وفق مسارك البصري والتطبيقي، مع 3 دروس وتحديات ذكية.'
              : 'Your personalized plan is tailored today based on your visual & interactive learning modality.'}
          </p>
        </div>

        {/* Gamification Stats */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          {/* Streak */}
          <div className="flex-1 sm:flex-none p-3.5 bg-white/90 rounded-2xl border border-amber-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center">
              <Flame className="w-5 h-5 fill-amber-500" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">{t.student.streak}</span>
              <p className="text-base font-extrabold text-slate-800">{streak} {isArabic ? 'أيام' : 'days'}</p>
            </div>
          </div>

          {/* XP Points */}
          <div className="flex-1 sm:flex-none p-3.5 bg-white/90 rounded-2xl border border-blue-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Zap className="w-5 h-5 fill-blue-500" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">{t.student.xpPoints}</span>
              <p className="text-base font-extrabold text-slate-800">{xp} XP</p>
            </div>
          </div>

          {/* Badges Count */}
          <div className="flex-1 sm:flex-none p-3.5 bg-white/90 rounded-2xl border border-purple-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">{t.student.badges}</span>
              <p className="text-base font-extrabold text-slate-800">{badgesList.length} {isArabic ? 'شارات' : 'badges'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Modality Radar & Diagnostic Test Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Modality Breakdown */}
        <div className="lg:col-span-2 p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PrimaryIcon className="w-5 h-5 text-[#81A6C6]" />
              <h3 className="font-bold text-slate-900 text-sm">{t.student.myLearningProfile}</h3>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isArabic ? 'نمط معتمد ومثبت بالذكاء الاصطناعي 🔒' : 'AI-Verified Profile (Locked) 🔒'}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            {/* Visual */}
            <div className="p-3 bg-blue-50/60 rounded-2xl border border-blue-100 text-center space-y-1">
              <span className="text-[10px] font-semibold text-blue-700">{t.test.visualModality}</span>
              <p className="text-lg font-bold text-blue-900">{visualScore}%</p>
              <div className="w-full bg-blue-200 h-1.5 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full rounded-full" style={{ width: `${visualScore}%` }} />
              </div>
            </div>

            {/* Auditory */}
            <div className="p-3 bg-amber-50/60 rounded-2xl border border-amber-100 text-center space-y-1">
              <span className="text-[10px] font-semibold text-amber-700">{t.test.auditoryModality}</span>
              <p className="text-lg font-bold text-amber-900">{auditoryScore}%</p>
              <div className="w-full bg-amber-200 h-1.5 rounded-full overflow-hidden">
                <div className="bg-amber-600 h-full rounded-full" style={{ width: `${auditoryScore}%` }} />
              </div>
            </div>

            {/* Reading */}
            <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-100 text-center space-y-1">
              <span className="text-[10px] font-semibold text-emerald-700">{t.test.readingWritingModality}</span>
              <p className="text-lg font-bold text-emerald-900">{readingScore}%</p>
              <div className="w-full bg-emerald-200 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${readingScore}%` }} />
              </div>
            </div>

            {/* Interactive */}
            <div className="p-3 bg-purple-50/60 rounded-2xl border border-purple-100 text-center space-y-1">
              <span className="text-[10px] font-semibold text-purple-700">{t.test.interactiveHandsOnModality}</span>
              <p className="text-lg font-bold text-purple-900">{interactiveScore}%</p>
              <div className="w-full bg-purple-200 h-1.5 rounded-full overflow-hidden">
                <div className="bg-purple-600 h-full rounded-full" style={{ width: `${interactiveScore}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Strengths & Growth Areas */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              {isArabic ? 'نقاط القوة الحالية' : 'Key Strengths'}
            </h4>
            <div className="space-y-1.5">
              {(activeStudent?.strengths || []).map((s, idx) => (
                <div key={idx} className="p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-100 text-xs font-medium text-emerald-900 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                  <span>{isArabic ? s.ar : s.en}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">{isArabic ? 'معدل الإتقان العام' : 'Overall Mastery'}</span>
              <span className="font-bold text-slate-800">{activeStudent?.overallProgress ?? 88}%</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full mt-1.5 overflow-hidden">
              <div className="bg-[#81A6C6] h-full rounded-full" style={{ width: `${activeStudent?.overallProgress ?? 88}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* 3. Daily Adaptive Lessons Track */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#81A6C6]" />
            <span>{t.student.myAdaptiveLessons}</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {lessons.map((lesson) => (
            <div
              key={lesson.id}
              className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="px-2.5 py-0.5 rounded-lg bg-blue-50 text-blue-800 font-bold border border-blue-100">
                    {isArabic ? lesson.unitTitleAr : lesson.unitTitleEn}
                  </span>
                  <span className="text-slate-400 flex items-center gap-1 font-medium">
                    <Clock className="w-3.5 h-3.5" />
                    {lesson.estimatedMinutes} {isArabic ? 'دقيقة' : 'min'}
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 text-sm leading-snug">
                  {isArabic ? lesson.titleAr : lesson.titleEn}
                </h4>

                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {isArabic ? lesson.summaryAr : lesson.summaryEn}
                </p>
              </div>

              {/* Progress and button */}
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{isArabic ? 'نسبة الإكمال' : 'Completion'}</span>
                  <span className="font-bold text-slate-700">{lesson.progressPercent}%</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-[#81A6C6] h-full rounded-full" style={{ width: `${lesson.progressPercent}%` }} />
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedLessonId(lesson.id)}
                  className="w-full py-2.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Play className="w-4 h-4" />
                  <span>{lesson.progressPercent > 0 ? (isArabic ? 'متابعة الدرس' : 'Resume Lesson') : (isArabic ? 'بدء الدرس' : 'Start Lesson')}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Adaptive Quizzes & Homework */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quizzes */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-amber-500" />
              <span>{t.student.adaptiveQuizzes}</span>
            </h3>
          </div>

          <div className="space-y-3">
            {quizzes.map((quiz) => (
              <div
                key={quiz.id}
                className="p-4 rounded-2xl border border-slate-100 bg-slate-50/60 flex items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-[#81A6C6]">
                    {isArabic ? quiz.subjectTitleAr : quiz.subjectTitleEn}
                  </span>
                  <h4 className="text-xs font-bold text-slate-800">
                    {isArabic ? quiz.titleAr : quiz.titleEn}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    {quiz.questions.length} {isArabic ? 'أسئلة مع تلميحات ذكية' : 'questions with smart hints'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedQuizId(quiz.id)}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer shrink-0 transition-colors"
                >
                  {quiz.isCompleted ? (isArabic ? 'إعادة الاختبار' : 'Retake') : (isArabic ? 'بدء التقييم' : 'Take Quiz')}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Homework / Assignments */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-emerald-600" />
              <span>{t.student.myAssignments}</span>
            </h3>
            <button
              type="button"
              onClick={() => setActiveModal('submit-assignment')}
              className="text-xs font-bold text-[#81A6C6] hover:underline cursor-pointer"
            >
              {isArabic ? 'تسليم حل جديد' : 'Submit Work'}
            </button>
          </div>

          <div className="space-y-3">
            {assignments.map((ass) => (
              <div
                key={ass.id}
                className="p-4 rounded-2xl border border-slate-100 bg-slate-50/60 space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <h4 className="font-bold text-slate-800">{isArabic ? ass.titleAr : ass.titleEn}</h4>
                  {ass.status === 'graded' ? (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      {isArabic ? `تم التصحيح: ${ass.score}/100` : `Graded: ${ass.score}/100`}
                    </span>
                  ) : (
                    <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full">
                      {isArabic ? `موعد التسليم: ${ass.dueDate}` : `Due: ${ass.dueDate}`}
                    </span>
                  )}
                </div>

                {ass.teacherFeedbackAr && (
                  <p className="text-[11px] text-slate-600 bg-white p-2.5 rounded-xl border border-slate-200/60">
                    👨‍🏫 {isArabic ? ass.teacherFeedbackAr : ass.teacherFeedbackEn}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
