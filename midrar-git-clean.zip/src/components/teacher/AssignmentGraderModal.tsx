import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  FileCheck,
  CheckCircle2,
  Send,
  Star,
  User,
  Calendar
} from 'lucide-react';

export const AssignmentGraderModal: React.FC = () => {
  const { activeModal, setActiveModal, assignments, gradeAssignment, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string>("ass-1");
  const [scoreInput, setScoreInput] = useState<number>(95);
  const [feedbackArInput, setFeedbackArInput] = useState('إجابات ممتازة جداً! تم استخدام المخططات البصرية وحساب القوانين بدقة.');
  const [feedbackEnInput, setFeedbackEnInput] = useState('Outstanding work! Accurate calculations and clear visual geometry sketches.');

  if (activeModal !== 'grade-assignment') return null;

  const currentAssignment = assignments.find((a) => a.id === selectedAssignmentId) || assignments[0];

  const handleSubmitGrade = (e: React.FormEvent) => {
    e.preventDefault();
    gradeAssignment(currentAssignment.id, scoreInput, feedbackArInput, feedbackEnInput);
    setActiveModal(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50/50 via-white to-blue-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">{t.teacher.gradeSubmission}</h3>
              <p className="text-xs text-slate-500">
                {isArabic ? currentAssignment.titleAr : currentAssignment.titleEn}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmitGrade} className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
          {/* Submission Info */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/70 space-y-2 text-xs">
            <div className="flex items-center justify-between font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                {isArabic ? 'الطالب: أحمد عبد الله الرشيد' : 'Student: Ahmed Abdullah'}
              </span>
              <span className="flex items-center gap-1 text-slate-400">
                <Calendar className="w-3.5 h-3.5" />
                {currentAssignment.submittedAt || '2026-08-16'}
              </span>
            </div>
            <p className="text-slate-600 bg-white p-3 rounded-xl border border-slate-100 leading-relaxed">
              "{currentAssignment.submissionContent || 'تم تسليم الحل وإرفاق الحسابات الهندسية ورسم المثلثات القائمة.'}"
            </p>
          </div>

          {/* Score Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">{t.teacher.enterScore}</label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min="0"
                max="100"
                required
                value={scoreInput}
                onChange={(e) => setScoreInput(Number(e.target.value))}
                className="w-28 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center text-lg font-bold text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
              />
              <div className="text-xs text-slate-500 font-medium">
                {scoreInput >= 90 ? '🌟 ' + (isArabic ? 'ممتاز مرتفع' : 'Excellent') : '👍 ' + (isArabic ? 'جيد جداً' : 'Very Good')}
              </div>
            </div>
          </div>

          {/* Feedback Area */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isArabic ? 'ملاحظات المعلم التوجيهية' : 'Teacher Guidance Notes'}
            </label>
            <textarea
              rows={3}
              value={isArabic ? feedbackArInput : feedbackEnInput}
              onChange={(e) => {
                if (isArabic) setFeedbackArInput(e.target.value);
                else setFeedbackEnInput(e.target.value);
              }}
              placeholder={t.teacher.feedbackPlaceholder}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <Send className="w-4 h-4 rtl:rotate-180" />
            <span>{t.teacher.sendFeedback}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
