import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  BookOpen,
  Sparkles,
  Wand2,
  FileCheck,
  Users,
  Star,
  Plus,
  Play,
  CheckCircle2,
  Clock,
  Briefcase,
  MessageSquare
} from 'lucide-react';

export const TeacherDashboard: React.FC = () => {
  const {
    lessons,
    assignments,
    setActiveModal,
    setSelectedLessonId,
    setActiveConversationId,
    showToast
  } = useApp();
  const { isArabic, t } = useLanguage();

  const [isAvailable, setIsAvailable] = useState(true);

  const toggleAvailability = () => {
    setIsAvailable(!isAvailable);
    showToast(
      isArabic
        ? (!isAvailable ? 'أصبحت متاحاً لاستقبال عروض المدارس' : 'تم إيقاف استقبال عروض التوظيف')
        : (!isAvailable ? 'Available for school recruitment' : 'Hidden from school recruitment'),
      'info'
    );
  };

  const pendingAssignments = assignments.filter((a) => a.status === 'submitted');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-200">
      {/* 1. Top Teacher Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-blue-500/10 rounded-3xl p-6 sm:p-8 border border-amber-200/60 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-800 uppercase tracking-wider">
              {isArabic ? 'بوابة المعلم الذكي' : 'Teacher & Curriculum Hub'}
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white">
              {isArabic ? 'معلم خبير معتمد' : 'Verified Faculty'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {isArabic ? 'إدارة الفصول وصناعة المحتوى المتكيف' : 'Adaptive Classrooms & AI Content Creation'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
            {isArabic
              ? 'قم بتوليد مسارات تعليمية رباعية الأنماط بضغطة زر واحدة عبر مساعد مدرار، وصحح التكليفات وقدم التوجيه.'
              : 'Generate 4-track adaptive lessons via Midrar Assistant, grade student work, and manage recruitment status.'}
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          <button
            type="button"
            onClick={() => setActiveModal('teacher-generator')}
            className="px-6 py-3 bg-[#81A6C6] hover:bg-[#7298b9] text-white font-bold text-xs rounded-2xl shadow-md flex items-center gap-2 cursor-pointer transition-all"
          >
            <Wand2 className="w-4 h-4 text-amber-300" />
            <span>{t.teacher.generateWithGemini}</span>
          </button>
        </div>
      </div>

      {/* 2. Key Teacher Stats & School Recruitment Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">{isArabic ? 'إجمالي الطلاب' : 'Total Students'}</span>
          <p className="text-2xl font-extrabold text-slate-800">48</p>
          <span className="text-[10px] text-blue-600 font-medium">{isArabic ? 'عبر 2 فصول دراسية' : 'across 2 cohorts'}</span>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">{isArabic ? 'الدروس المتكيفة المنشورة' : 'Published Lessons'}</span>
          <p className="text-2xl font-extrabold text-[#81A6C6]">{lessons.length}</p>
          <span className="text-[10px] text-blue-600 font-medium">{isArabic ? 'رباعية المسارات' : '4-track multi-modal'}</span>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase">{isArabic ? 'واجبات قيد التصحيح' : 'Pending Grading'}</span>
          <p className="text-2xl font-extrabold text-amber-600">{pendingAssignments.length}</p>
          <span className="text-[10px] text-amber-600 font-medium">{isArabic ? 'بحاجة لملاحظاتك' : 'awaiting feedback'}</span>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-2 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase">{t.teacher.available}</span>
            <button
              type="button"
              onClick={toggleAvailability}
              className={`w-11 h-6 rounded-full p-1 transition-colors cursor-pointer ${
                isAvailable ? 'bg-emerald-500' : 'bg-slate-200'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  isAvailable ? 'ltr:translate-x-5 rtl:-translate-x-5' : ''
                }`}
              />
            </button>
          </div>
          <span className="text-[10px] text-slate-500">
            {isAvailable ? (isArabic ? 'ملفك مرئي للمدارس الأهلية' : 'Visible to school scouts') : (isArabic ? 'مخفي عن عروض التوظيف' : 'Hidden from recruit')}
          </span>
        </div>
      </div>

      {/* 3. Published Adaptive Lessons */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-600" />
            <span>{isArabic ? 'الدروس والوحدات التفاعلية المجهزة' : 'Prepared Multi-Modal Lessons'}</span>
          </h3>

          <button
            type="button"
            onClick={() => setActiveModal('teacher-generator')}
            className="text-xs font-bold text-[#81A6C6] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{isArabic ? 'إضافة درس بمساعد مدرار' : 'Create Lesson'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {lessons.map((lesson) => (
            <div
              key={lesson.id}
              className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="px-2.5 py-0.5 rounded-lg bg-amber-50 text-amber-800 font-bold border border-amber-100">
                    {isArabic ? lesson.unitTitleAr : lesson.unitTitleEn}
                  </span>
                  <span className="text-slate-400 font-medium">{lesson.estimatedMinutes} min</span>
                </div>
                <h4 className="font-bold text-slate-900 text-xs leading-snug">
                  {isArabic ? lesson.titleAr : lesson.titleEn}
                </h4>
                <p className="text-[11px] text-slate-500 line-clamp-2">
                  {isArabic ? lesson.summaryAr : lesson.summaryEn}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedLessonId(lesson.id)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200/80 text-slate-800 font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isArabic ? 'معاينة الدرس' : 'Preview'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Pending Homework & Grading Submissions */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
            <FileCheck className="w-5 h-5 text-emerald-600" />
            <span>{isArabic ? 'تسليمات الواجبات والتصحيح' : 'Student Submissions & Grading'}</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {assignments.map((ass) => (
            <div
              key={ass.id}
              className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <h4 className="font-bold text-slate-900">{isArabic ? ass.titleAr : ass.titleEn}</h4>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      ass.status === 'graded'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {ass.status === 'graded' ? (isArabic ? `مكتمل (${ass.score}%)` : `Graded (${ass.score}%)`) : (isArabic ? 'تسليم ينتظر التصحيح' : 'Awaiting Grading')}
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {isArabic ? ass.descriptionAr : ass.descriptionEn}
                </p>
                {ass.teacherFeedbackAr && (
                  <p className="text-[11px] text-emerald-900 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">
                    ✓ {isArabic ? ass.teacherFeedbackAr : ass.teacherFeedbackEn}
                  </p>
                )}
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('grade-assignment')}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>{ass.status === 'graded' ? (isArabic ? 'تعديل الدرجة والملاحظات' : 'Edit Grade & Feedback') : (isArabic ? 'تصحيح وإرسال التقييم' : 'Grade Submission')}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
