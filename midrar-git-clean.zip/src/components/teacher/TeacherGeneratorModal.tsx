import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  X,
  Sparkles,
  BookOpen,
  HelpCircle,
  Wand2,
  CheckCircle2,
  Send
} from 'lucide-react';

export const TeacherGeneratorModal: React.FC = () => {
  const { activeModal, setActiveModal, createCustomLesson, createCustomQuiz, showToast } = useApp();
  const { isArabic, t } = useLanguage();

  const [generatorType, setGeneratorType] = useState<'lesson' | 'quiz'>('lesson');
  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState('الرياضيات');
  const [gradeLevel, setGradeLevel] = useState('الصف الثاني المتوسط');
  const [difficulty, setDifficulty] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [isGenerating, setIsGenerating] = useState(false);

  if (activeModal !== 'teacher-generator') return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() || isGenerating) return;

    setIsGenerating(true);
    showToast(isArabic ? 'جاري بناء المحتوى المتكيف باستخدام مساعد مدرار الذكي...' : 'Generating multi-modal content with Midrar Assistant...', 'info');

    try {
      if (generatorType === 'lesson') {
        const res = await fetch('/api/gemini/generate-lesson', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            topic,
            subject,
            gradeLevel,
            difficulty
          })
        });
        const data = await res.json();
        if (data.lesson) {
          createCustomLesson({
            titleAr: data.lesson.titleAr || topic,
            titleEn: data.lesson.titleEn || topic,
            unitTitleAr: `وحدة ${subject}`,
            unitTitleEn: `${subject} Unit`,
            estimatedMinutes: data.lesson.estimatedMinutes || 25,
            difficulty,
            summaryAr: data.lesson.summaryAr,
            summaryEn: data.lesson.summaryEn,
            visualContent: data.lesson.visualContent,
            auditoryContent: data.lesson.auditoryContent,
            readingContent: data.lesson.readingContent,
            handsOnContent: data.lesson.handsOnContent
          });
        } else {
          // Fallback creation
          createCustomLesson({
            titleAr: topic,
            titleEn: topic,
            difficulty
          });
        }
      } else {
        const res = await fetch('/api/gemini/generate-quiz', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            topic,
            subject,
            difficulty,
            questionCount: 3
          })
        });
        const data = await res.json();
        if (data.quiz && data.quiz.questions) {
          createCustomQuiz({
            titleAr: `اختبار تقييم: ${topic}`,
            titleEn: `Assessment: ${topic}`,
            questions: data.quiz.questions
          });
        } else {
          createCustomQuiz({
            titleAr: `اختبار تقييم: ${topic}`,
            titleEn: `Assessment: ${topic}`
          });
        }
      }
      setActiveModal(null);
    } catch (err) {
      console.error(err);
      createCustomLesson({
        titleAr: topic,
        titleEn: topic,
        difficulty
      });
      setActiveModal(null);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-amber-50/50 via-white to-blue-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <Wand2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">
                {isArabic ? 'منشئ المحتوى التعليمي بمساعد مدرار الذكي' : 'Midrar AI Content Architect'}
              </h3>
              <p className="text-xs text-slate-500">
                {isArabic ? 'توليد مسارات متكيفة (بصري، سمعي، قرائي، وتطبيقي)' : 'Generate 4 multi-modal learning tracks'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Type Tabs */}
        <div className="px-6 pt-3 flex gap-2 border-b border-slate-100 bg-slate-50/50">
          <button
            type="button"
            onClick={() => setGeneratorType('lesson')}
            className={`pb-3 px-4 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              generatorType === 'lesson'
                ? 'border-[#81A6C6] text-[#81A6C6] bg-white'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>{isArabic ? 'درس تفاعلي متكيف' : 'Adaptive Lesson'}</span>
          </button>

          <button
            type="button"
            onClick={() => setGeneratorType('quiz')}
            className={`pb-3 px-4 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer ${
              generatorType === 'quiz'
                ? 'border-[#81A6C6] text-[#81A6C6] bg-white'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>{isArabic ? 'اختبار ذكي بتلميحات تدريجية' : 'Adaptive Smart Quiz'}</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleGenerate} className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {isArabic ? 'موضوع الدرس أو التقييم' : 'Lesson Topic'}
            </label>
            <input
              type="text"
              required
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder={t.teacher.topicPlaceholder}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t.teacher.subjectSelect}</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
              >
                <option value="الرياضيات">{isArabic ? 'الرياضيات' : 'Mathematics'}</option>
                <option value="العلوم">{isArabic ? 'العلوم الطبيعية' : 'Science'}</option>
                <option value="اللغة العربية">{isArabic ? 'اللغة العربية' : 'Arabic'}</option>
                <option value="اللغة الإنجليزية">{isArabic ? 'اللغة الإنجليزية' : 'English'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t.teacher.gradeSelect}</label>
              <select
                value={gradeLevel}
                onChange={(e) => setGradeLevel(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#81A6C6]"
              >
                <option value="الصف الخامس الابتدائي">{isArabic ? 'الخامس الابتدائي' : '5th Grade'}</option>
                <option value="الصف الثاني المتوسط">{isArabic ? 'الثاني المتوسط' : '8th Grade'}</option>
                <option value="الصف الأول الثانوي">{isArabic ? 'الأول الثانوي' : '10th Grade'}</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">{t.teacher.difficultyLevel}</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDifficulty('beginner')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                  difficulty === 'beginner'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                    : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                {t.teacher.beginner}
              </button>

              <button
                type="button"
                onClick={() => setDifficulty('intermediate')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                  difficulty === 'intermediate'
                    ? 'bg-blue-50 border-blue-500 text-blue-800'
                    : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                {t.teacher.intermediate}
              </button>

              <button
                type="button"
                onClick={() => setDifficulty('advanced')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                  difficulty === 'advanced'
                    ? 'bg-purple-50 border-purple-500 text-purple-800'
                    : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                {t.teacher.advanced}
              </button>
            </div>
          </div>

          <div className="p-4 bg-blue-50/70 border border-blue-100 rounded-2xl text-xs text-blue-900 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              {isArabic
                ? 'سيقوم مساعد مدرار بصياغة 4 مسارات متوازية فوراً، ونشر المحتوى في خطط الطلاب المتوافقة تلقائياً.'
                : 'Midrar Assistant will simultaneously compile 4 tailored modalities and publish to student cohort.'}
            </p>
          </div>

          <button
            type="submit"
            disabled={isGenerating}
            className="w-full py-3.5 bg-[#81A6C6] hover:bg-[#7298b9] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>
              {isGenerating
                ? (isArabic ? 'جاري الصياغة بالذكاء الاصطناعي...' : 'Compiling with Midrar Assistant...')
                : t.teacher.generateWithGemini}
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};
