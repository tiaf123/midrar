import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { LEARNING_PREFERENCE_QUESTIONS, calculateLearningPreferences } from '../../data/learningTestQuestions';
import { motionTokens, getDirectionalOffset } from '../../motion/tokens';
import { AnimatedButton } from '../motion/AnimatedButton';
import { AIThinkingState } from '../motion/AIThinkingState';
import { AnimatedCounter } from '../motion/AnimatedCounter';
import {
  X,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  BrainCircuit,
  Eye,
  Headphones,
  BookOpen,
  Wrench,
  Lock,
  GraduationCap,
  Info,
  ShieldCheck
} from 'lucide-react';

export const LearningPreferenceModal: React.FC = () => {
  const {
    activeModal,
    setActiveModal,
    role,
    activeStudent,
    saveLearningPreferenceTest,
    showToast
  } = useApp();
  const { isArabic, t } = useLanguage();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState<'next' | 'prev'>('next');
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isCalculating, setIsCalculating] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [calculatedResult, setCalculatedResult] = useState<ReturnType<typeof calculateLearningPreferences> | null>(null);

  if (activeModal !== 'learning-test') return null;

  const isStudentLoggedIn = role === 'student' && !!activeStudent;
  const hasAlreadyCompleted = activeStudent?.hasCompletedPreferenceTest === true && !isCompleted;

  const currentQuestion = LEARNING_PREFERENCE_QUESTIONS[currentIndex];
  const totalQuestions = LEARNING_PREFERENCE_QUESTIONS.length;
  const progressPct = Math.round(((currentIndex + 1) / totalQuestions) * 100);

  const handleSelectOption = (optionId: string) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: optionId,
    }));
  };

  const handleNext = () => {
    if (!answers[currentQuestion.id]) {
      showToast(isArabic ? 'يرجى اختيار أحد الخيارات للمتابعة' : 'Please select an option to proceed', 'warning');
      return;
    }

    setDirection('next');
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Transition to AI Calculation state
      setIsCalculating(true);
      setTimeout(() => {
        const res = calculateLearningPreferences(answers);
        setCalculatedResult(res);
        setIsCalculating(false);
        setIsCompleted(true);
        saveLearningPreferenceTest({
          visual: res.visual,
          auditory: res.auditory,
          readingWriting: res.readingWriting,
          interactiveHandsOn: res.interactiveHandsOn,
          confidenceScore: res.confidenceScore,
          completedDate: new Date().toISOString().split('T')[0],
          summaryAr: res.summaryAr,
          summaryEn: res.summaryEn,
          strengthsAr: res.strengthsAr,
          strengthsEn: res.strengthsEn,
          suggestedStrategiesAr: res.suggestedStrategiesAr,
          suggestedStrategiesEn: res.suggestedStrategiesEn,
          rawAnswers: answers,
        });
        showToast(isArabic ? 'تم تحليل نمطك وتثبيته بنجاح بالذكاء الاصطناعي!' : 'Your learning preferences have been permanently locked by AI!', 'success');
      }, 1800);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setDirection('prev');
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const offset = getDirectionalOffset(isArabic, 24);
  const slideVariants = {
    initial: (dir: 'next' | 'prev') => ({
      opacity: 0,
      x: dir === 'next' ? offset.enterX : -offset.enterX,
    }),
    animate: {
      opacity: 1,
      x: 0,
      transition: { duration: motionTokens.duration.normal, ease: motionTokens.easing.standard },
    },
    exit: (dir: 'next' | 'prev') => ({
      opacity: 0,
      x: dir === 'next' ? offset.exitX : -offset.exitX,
      transition: { duration: motionTokens.duration.fast, ease: motionTokens.easing.exit },
    }),
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-slate-900/60 backdrop-blur-xs">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        transition={motionTokens.spring.responsive}
        className="bg-white rounded-3xl shadow-2xl border border-white/90 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50/40 via-white to-amber-50/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#81A6C6]/20 text-[#81A6C6] flex items-center justify-center">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                  {isArabic ? 'مقياس تفضيلات التعلم الذكي' : 'Smart Modality Diagnostic'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                  {isArabic ? 'لـمـرة واحـدة فـقـط' : 'One-Time Only'}
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500">
                {isArabic ? 'مدعوم بالذكاء الاصطناعي لتثبيت مسارك التعليمي الدائم' : 'AI-powered to permanently lock your learning track'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Condition 1: Guest / Not logged in as student */}
        {!isStudentLoggedIn ? (
          <div className="p-8 sm:p-10 text-center space-y-5 flex-1 flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-inner">
              <GraduationCap className="w-8 h-8" />
            </div>
            <div className="space-y-2 max-w-md">
              <h4 className="text-lg sm:text-xl font-bold text-slate-900">
                {isArabic ? 'تسجيل دخول الطالب مطلوب' : 'Student Login Required'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {isArabic
                  ? 'هذا الاختبار التشخيصي يُجرى لمرة واحدة فقط لكل طالب مسجل لربطه بملفه وتخصيص كافة دروسه بالذكاء الاصطناعي. يرجى تسجيل الدخول برمز الطالب للبدء.'
                  : 'This diagnostic assessment is conducted strictly once per student to lock their permanent AI learning track. Please login with your student code first.'}
              </p>
            </div>
            <AnimatedButton
              variant="primary"
              size="md"
              onClick={() => setActiveModal('auth')}
              icon={<GraduationCap className="w-4 h-4" />}
            >
              <span>{isArabic ? 'تسجيل دخول الطالب برمز الطالب' : 'Enter Student Code'}</span>
            </AnimatedButton>
          </div>
        ) : hasAlreadyCompleted ? (
          /* Condition 2: Student has already completed the one-time test */
          <div className="p-8 sm:p-10 text-center space-y-6 flex-1 flex flex-col items-center justify-center overflow-y-auto custom-scrollbar">
            <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-inner">
              <Lock className="w-8 h-8" />
            </div>
            <div className="space-y-2 max-w-md">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{isArabic ? 'تم إتمام الاختبار وتثبيت النمط مسبقاً' : 'Diagnostic Already Completed & Locked'}</span>
              </div>
              <h4 className="text-lg sm:text-xl font-bold text-slate-900">
                {isArabic ? `نمطك التعليمي مثبت يا ${activeStudent?.name}` : `Learning Profile Locked for ${activeStudent?.name}`}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {isArabic
                  ? 'لقد أجريت هذا المقياس التشخيصي مسبقاً، وتم تثبيت مسارك التعليمي (بصري، سمعي، قرائي، وتطبيقي) بالذكاء الاصطناعي. هذا الاختبار يُجرى لمرة واحدة فقط لضمان دقة خطتك ومسارات دروسك.'
                  : 'You have already completed this diagnostic test. Your personalized learning track has been permanently locked by AI.'}
              </p>
            </div>

            {/* Locked Modality Breakdown */}
            <div className="w-full max-w-md bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-start">
              <span className="text-xs font-bold text-slate-700 block mb-2">
                {isArabic ? '📊 نسب نمطك التعليمي المعتمد:' : '📊 Your Verified Modalities:'}
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-xl bg-white border border-blue-100 flex items-center justify-between">
                  <span className="text-blue-700 font-bold flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {t.test.visualModality}</span>
                  <span className="font-mono font-bold text-slate-800">{activeStudent?.learningPreferences?.visual ?? 38}%</span>
                </div>
                <div className="p-2 rounded-xl bg-white border border-amber-100 flex items-center justify-between">
                  <span className="text-amber-700 font-bold flex items-center gap-1"><Headphones className="w-3.5 h-3.5" /> {t.test.auditoryModality}</span>
                  <span className="font-mono font-bold text-slate-800">{activeStudent?.learningPreferences?.auditory ?? 25}%</span>
                </div>
                <div className="p-2 rounded-xl bg-white border border-emerald-100 flex items-center justify-between">
                  <span className="text-emerald-700 font-bold flex items-center gap-1"><BookOpen className="w-3.5 h-3.5" /> {t.test.readingWritingModality}</span>
                  <span className="font-mono font-bold text-slate-800">{activeStudent?.learningPreferences?.readingWriting ?? 15}%</span>
                </div>
                <div className="p-2 rounded-xl bg-white border border-purple-100 flex items-center justify-between">
                  <span className="text-purple-700 font-bold flex items-center gap-1"><Wrench className="w-3.5 h-3.5" /> {t.test.interactiveHandsOnModality}</span>
                  <span className="font-mono font-bold text-slate-800">{activeStudent?.learningPreferences?.interactiveHandsOn ?? 30}%</span>
                </div>
              </div>
            </div>

            <AnimatedButton
              variant="primary"
              size="md"
              onClick={() => setActiveModal(null)}
            >
              <span>{isArabic ? 'العودة إلى لوحة التحكم والدروس' : 'Return to Dashboard & Lessons'}</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </AnimatedButton>
          </div>
        ) : isCalculating ? (
          /* Condition 3: AI Processing State */
          <div className="flex-1 flex items-center justify-center p-8 min-h-[380px]">
            <AIThinkingState
              customMessages={
                isArabic
                  ? [
                      'مساعد مِدْرار الذكي يحلل استجاباتك الـ 25...',
                      'حساب الأوزان النسبية للأنماط: البصري، السمعي، القرائي، والتطبيقي...',
                      'تثبيت ملفك التعليمي الدائم وتوليد استراتيجيات التفوق بالذكاء الاصطناعي...',
                    ]
                  : [
                      'Midrar AI Tutor analyzing your 25 cognitive responses...',
                      'Calculating relative weights for Visual, Auditory, Reading, and Hands-on...',
                      'Permanently locking your personal learning profile...',
                    ]
              }
            />
          </div>
        ) : !isCompleted ? (
          /* Condition 4: Active 25-Question Test */
          <div className="flex-1 flex flex-col p-5 sm:p-6 overflow-y-auto custom-scrollbar">
            {/* Prominent One-Time Instructions Notice */}
            <div className="mb-4 p-3.5 rounded-2xl bg-amber-50/90 border border-amber-200/80 flex items-start gap-2.5 text-xs text-amber-900">
              <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <span className="font-bold block">
                  {isArabic ? '⚠️ إرشادات هامة (اختبار لمرة واحدة فقط):' : '⚠️ Important Instructions (One-Time Assessment):'}
                </span>
                <span>
                  {isArabic
                    ? 'أجب بصدق عن المواقف التعليمية الـ 25. سيقوم الذكاء الاصطناعي بتحليل إجاباتك لتثبيت نمطك التعليمي بشكل دائم وتخصيص دروسك، ولن تتمكن من إعادة الاختبار بعد اكتماله.'
                    : 'Answer honestly. The AI will analyze all 25 responses to permanently lock your learning modality and tailor all your lessons.'}
                </span>
              </div>
            </div>

            {/* Progress indicator with smooth Spring */}
            <div className="mb-5 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span className="text-[#81A6C6]">
                  {t.test.questionNumber} {currentIndex + 1} {t.test.ofTotal}
                </span>
                <span className="tabular-nums font-extrabold">{progressPct}%</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPct}%` }}
                  transition={{ duration: 0.35, ease: motionTokens.easing.standard }}
                  className="bg-gradient-to-r from-[#81A6C6] to-[#AACDDC] h-full rounded-full"
                />
              </div>
            </div>

            {/* Question Card with Directional Sliding */}
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={currentIndex}
                custom={direction}
                variants={slideVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                className="space-y-4 flex-1 flex flex-col"
              >
                <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 sm:p-5">
                  <h4 className="text-sm sm:text-base font-bold text-slate-800 leading-relaxed">
                    {isArabic ? currentQuestion.questionAr : currentQuestion.questionEn}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-1">{t.test.chooseAnswer}</p>
                </div>

                {/* Options */}
                <div className="space-y-2.5 flex-1">
                  {currentQuestion.options.map((option) => {
                    const isSelected = answers[currentQuestion.id] === option.id;
                    let Icon = Eye;
                    let badgeColor = 'bg-blue-50 text-blue-700';
                    if (option.type === 'auditory') {
                      Icon = Headphones;
                      badgeColor = 'bg-amber-50 text-amber-700';
                    } else if (option.type === 'readingWriting') {
                      Icon = BookOpen;
                      badgeColor = 'bg-emerald-50 text-emerald-700';
                    } else if (option.type === 'interactiveHandsOn') {
                      Icon = Wrench;
                      badgeColor = 'bg-purple-50 text-purple-700';
                    }

                    return (
                      <motion.button
                        key={option.id}
                        type="button"
                        whileHover={{ y: -1.5, transition: motionTokens.spring.responsive }}
                        whileTap={{ scale: 0.985 }}
                        onClick={() => handleSelectOption(option.id)}
                        className={`w-full p-3.5 sm:p-4 rounded-2xl border text-start transition-all flex items-start gap-3 cursor-pointer ${
                          isSelected
                            ? 'bg-[#81A6C6]/15 border-[#81A6C6] shadow-sm ring-1 ring-[#81A6C6]'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/70'
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                            isSelected ? 'bg-[#81A6C6] text-white' : badgeColor
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </div>

                        <div className="flex-1">
                          <p className={`text-xs sm:text-sm leading-relaxed ${isSelected ? 'font-bold text-slate-900' : 'text-slate-700'}`}>
                            {isArabic ? option.textAr : option.textEn}
                          </p>
                        </div>

                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                            isSelected ? 'border-[#81A6C6] bg-[#81A6C6] text-white' : 'border-slate-300'
                          }`}
                        >
                          {isSelected && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={motionTokens.spring.playful}
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </motion.div>
                          )}
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Bottom Stepper Buttons */}
            <div className="pt-5 mt-5 border-t border-slate-100 flex items-center justify-between">
              <AnimatedButton
                variant="outline"
                size="sm"
                disabled={currentIndex === 0}
                onClick={handlePrevious}
                icon={<ArrowLeft className="w-4 h-4 rtl:rotate-180" />}
              >
                <span>{t.common.previous}</span>
              </AnimatedButton>

              <AnimatedButton
                variant="primary"
                size="md"
                onClick={handleNext}
              >
                <span>{currentIndex === totalQuestions - 1 ? (isArabic ? 'اعتماد النمط بالـ AI 🔒' : 'Lock Profile with AI 🔒') : t.common.next}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </AnimatedButton>
            </div>
          </div>
        ) : (
          /* Condition 5: Results View & Confirmation */
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={motionTokens.spring.responsive}
            className="flex-1 p-5 sm:p-6 overflow-y-auto custom-scrollbar space-y-6"
          >
            <div className="text-center space-y-2">
              <motion.div
                initial={{ scale: 0, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={motionTokens.spring.playful}
                className="w-14 h-14 rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner"
              >
                <Sparkles className="w-7 h-7" />
              </motion.div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{isArabic ? 'تم تثبيت واعتماد نمطك الدائم بنجاح 🔒' : 'Modality Permanently Locked & Verified 🔒'}</span>
              </div>
              <h4 className="text-lg sm:text-xl font-bold text-slate-800">
                {isArabic ? `اكتمل تشخيص ملفك يا ${activeStudent?.name}!` : `Profile Completed for ${activeStudent?.name}!`}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                {isArabic ? calculatedResult?.summaryAr : calculatedResult?.summaryEn}
              </p>
            </div>

            {/* Modality Percentage Bars */}
            <div className="space-y-3.5 bg-slate-50 p-5 rounded-2xl border border-slate-200/80">
              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                  <span className="flex items-center gap-1.5 text-blue-700">
                    <Eye className="w-4 h-4" /> {t.test.visualModality}
                  </span>
                  <span><AnimatedCounter value={calculatedResult?.visual || 0} suffix="%" /></span>
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${calculatedResult?.visual}%` }}
                    transition={{ duration: 0.8, ease: motionTokens.easing.enter }}
                    className="bg-blue-500 h-full rounded-full"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                  <span className="flex items-center gap-1.5 text-purple-700">
                    <Wrench className="w-4 h-4" /> {t.test.interactiveHandsOnModality}
                  </span>
                  <span><AnimatedCounter value={calculatedResult?.interactiveHandsOn || 0} suffix="%" /></span>
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${calculatedResult?.interactiveHandsOn}%` }}
                    transition={{ duration: 0.8, delay: 0.1, ease: motionTokens.easing.enter }}
                    className="bg-purple-500 h-full rounded-full"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                  <span className="flex items-center gap-1.5 text-amber-700">
                    <Headphones className="w-4 h-4" /> {t.test.auditoryModality}
                  </span>
                  <span><AnimatedCounter value={calculatedResult?.auditory || 0} suffix="%" /></span>
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${calculatedResult?.auditory}%` }}
                    transition={{ duration: 0.8, delay: 0.2, ease: motionTokens.easing.enter }}
                    className="bg-amber-500 h-full rounded-full"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                  <span className="flex items-center gap-1.5 text-emerald-700">
                    <BookOpen className="w-4 h-4" /> {t.test.readingWritingModality}
                  </span>
                  <span><AnimatedCounter value={calculatedResult?.readingWriting || 0} suffix="%" /></span>
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${calculatedResult?.readingWriting}%` }}
                    transition={{ duration: 0.8, delay: 0.3, ease: motionTokens.easing.enter }}
                    className="bg-emerald-500 h-full rounded-full"
                  />
                </div>
              </div>
            </div>

            {/* Strengths and Strategies */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 space-y-2">
                <h5 className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  {t.test.strengthsTitle}
                </h5>
                <ul className="text-xs text-blue-800 space-y-1.5 list-disc ps-4">
                  {(isArabic ? calculatedResult?.strengthsAr : calculatedResult?.strengthsEn)?.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-100 space-y-2">
                <h5 className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  {t.test.suggestedStrategiesTitle}
                </h5>
                <ul className="text-xs text-amber-800 space-y-1.5 list-disc ps-4">
                  {(isArabic ? calculatedResult?.suggestedStrategiesAr : calculatedResult?.suggestedStrategiesEn)?.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Single Clear Action: Go to Customized Dashboard */}
            <div className="pt-4 border-t border-slate-100 flex justify-center">
              <AnimatedButton
                variant="primary"
                size="lg"
                onClick={() => setActiveModal(null)}
                className="w-full sm:w-auto min-w-[240px] shadow-lg shadow-[#81A6C6]/30"
              >
                <span>{isArabic ? 'بدء رحلة التعلم الذكي المخصصة' : 'Start Personalized AI Learning'}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </AnimatedButton>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};
