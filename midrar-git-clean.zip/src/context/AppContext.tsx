import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  UserRole,
  UserProfile,
  Student,
  Subject,
  Lesson,
  Assignment,
  Quiz,
  LearningPlanItem,
  Achievement,
  ChatConversation,
  ChatMessage,
  TeacherProfile,
  AppNotification,
  LearningPreferenceResult
} from '../types';
import {
  INITIAL_STUDENTS,
  INITIAL_SUBJECTS,
  INITIAL_LESSONS,
  INITIAL_ASSIGNMENTS,
  INITIAL_QUIZZES,
  INITIAL_LEARNING_PLANS,
  INITIAL_ACHIEVEMENTS,
  INITIAL_CONVERSATIONS,
  INITIAL_MESSAGES,
  INITIAL_TEACHERS_CATALOG,
  INITIAL_NOTIFICATIONS
} from '../data/mockData';

import { supabase, isSupabaseConfigured } from '../lib/supabase';

export interface ToastItem {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
}

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  currentUser: UserProfile;
  activeStudent: Student;
  setActiveStudentId: (id: string) => void;
  allStudents: Student[];
  students: Student[];
  subjects: Subject[];
  lessons: Lesson[];
  assignments: Assignment[];
  quizzes: Quiz[];
  learningPlans: LearningPlanItem[];
  achievements: Achievement[];
  conversations: ChatConversation[];
  messages: Record<string, ChatMessage[]>;
  teachersCatalog: TeacherProfile[];
  notifications: AppNotification[];
  unreadNotifsCount: number;
  unreadMessagesCount: number;
  toasts: ToastItem[];
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
  
  // Modals & Active views
  activeModal: string | null;
  setActiveModal: (modal: string | null) => void;
  selectedLessonId: string | null;
  setSelectedLessonId: (id: string | null) => void;
  selectedQuizId: string | null;
  setSelectedQuizId: (id: string | null) => void;
  selectedTeacherId: string | null;
  setSelectedTeacherId: (id: string | null) => void;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;

  // Actions
  loginWithStudentCode: (code: string) => Promise<boolean> | boolean;
  loginWithEmail: (email: string, passwordInput: string, role: UserRole) => Promise<boolean> | boolean;
  registerWithEmail: (email: string, passwordInput: string, name: string, role: UserRole) => Promise<boolean> | boolean;
  logout: () => void;
  submitAssignment: (assignmentId: string, content: string) => void;
  gradeAssignment: (assignmentId: string, score: number, feedbackAr: string, feedbackEn: string) => void;
  completeQuiz: (quizId: string, score: number) => void;
  saveLearningPreferenceTest: (result: LearningPreferenceResult) => void;
  addNewStudentToFamily: (name: string, gradeLevel: string) => Student;
  sendChatMessage: (conversationId: string, content: string) => void;
  markNotificationRead: (id: string) => void;
  createCustomLesson: (newLesson: Partial<Lesson>) => void;
  createCustomQuiz: (newQuiz: Partial<Quiz>) => void;
  sendRecruitmentOffer: (teacherId: string, subject: string, message: string) => void;
  rateTeacherExperience: (teacherId: string, stars: number, comment: string) => void;
  triggerConfetti: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole>('guest');
  const [customUserProfile, setCustomUserProfile] = useState<UserProfile | null>(null);
  const [demoStudents, setDemoStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [userStudents, setUserStudents] = useState<Student[]>([]);
  const allStudents = customUserProfile ? userStudents : demoStudents;
  const setAllStudents = customUserProfile ? setUserStudents : setDemoStudents;
  const [activeStudentId, setActiveStudentId] = useState<string>("stu-1");
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [lessons, setLessons] = useState<Lesson[]>(INITIAL_LESSONS);
  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);
  const [quizzes, setQuizzes] = useState<Quiz[]>(INITIAL_QUIZZES);
  const [learningPlans, setLearningPlans] = useState<LearningPlanItem[]>(INITIAL_LEARNING_PLANS);
  const [achievements, setAchievements] = useState<Achievement[]>(INITIAL_ACHIEVEMENTS);
  const [demoTeachers, setDemoTeachers] = useState<TeacherProfile[]>(INITIAL_TEACHERS_CATALOG);
  const [userTeachers, setUserTeachers] = useState<TeacherProfile[]>([]);
  const teachersCatalog = customUserProfile ? userTeachers : demoTeachers;
  const setTeachersCatalog = (action: React.SetStateAction<TeacherProfile[]>) => {
    if (customUserProfile) setUserTeachers(action);
    else setDemoTeachers(action);
  };

  const [demoConversations, setDemoConversations] = useState<ChatConversation[]>(INITIAL_CONVERSATIONS);
  const [userConversations, setUserConversations] = useState<ChatConversation[]>([]);
  const conversations = customUserProfile ? userConversations : demoConversations;
  const setConversations = (action: React.SetStateAction<ChatConversation[]>) => {
    if (customUserProfile) setUserConversations(action);
    else setDemoConversations(action);
  };
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>(INITIAL_MESSAGES);

  const [demoNotifications, setDemoNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [userNotifications, setUserNotifications] = useState<AppNotification[]>([]);
  const notifications = customUserProfile ? userNotifications : demoNotifications;
  const setNotifications = (action: React.SetStateAction<AppNotification[]>) => {
    if (customUserProfile) setUserNotifications(action);
    else setDemoNotifications(action);
  };

  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Navigation & Modal triggers
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null);
  const [selectedTeacherId, setSelectedTeacherId] = useState<string | null>(null);
  const [activeConversationId, setActiveConversationId] = useState<string | null>("conv-1");

  // Load session from Supabase on mount
  useEffect(() => {
    if (isSupabaseConfigured && supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session?.user) {
          const email = session.user.email || '';
          supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .maybeSingle()
            .then(({ data: profile }) => {
              if (profile) {
                const userRole = (profile.role as UserRole) || 'student';
                setCustomUserProfile({
                  id: profile.id,
                  name: profile.full_name || email.split('@')[0],
                  email: profile.email || email,
                  role: userRole,
                  city: profile.city || 'الرياض',
                  locale: 'ar'
                });
                setRoleState(userRole);
              }
            });
        }
      });
    }
  }, []);

  // User profiles by role or logged in custom user profile
  const currentUser: UserProfile = React.useMemo(() => {
    if (customUserProfile) {
      return customUserProfile;
    }

    switch (role) {
      case 'student':
        return {
          id: "stu-1",
          name: "طالب مِدْرار",
          role: 'student',
          studentCode: "STU-8821",
          avatarUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80",
          locale: 'ar'
        };
      case 'guardian':
        return {
          id: "guard-1",
          name: "ولي أمر مِدْرار",
          email: "parent@midrar.edu.sa",
          role: 'guardian',
          avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
          phone: "+966 50 000 0000",
          locale: 'ar'
        };
      case 'teacher':
        return {
          id: "teach-1",
          name: "معلم مِدْرار",
          email: "teacher@midrar.edu.sa",
          role: 'teacher',
          avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
          subjectsTaught: ["الرياضيات", "العلوم"],
          city: "الرياض",
          rating: 5.0,
          experienceYears: 8,
          locale: 'ar'
        };
      case 'school':
        return {
          id: "sch-1",
          name: "إدارة المدرسة",
          email: "admin@school.edu.sa",
          role: 'school',
          schoolName: "مدرسة مِدْرار الذكية",
          avatarUrl: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=150&auto=format&fit=crop&q=80",
          city: "الرياض",
          locale: 'ar'
        };
      default:
        return {
          id: "guest-1",
          name: "زائر مِدْرار",
          role: 'guest',
          locale: 'ar'
        };
    }
  }, [role, customUserProfile]);

  const activeStudent = allStudents.find((s) => s.id === activeStudentId) || allStudents[0];

  const showToast = (message: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#81A6C6', '#AACDDC', '#F3E3D0', '#D2C4B4', '#10B981']
    });
  };

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    setActiveModal(null);
    if (newRole !== 'guest') {
      showToast(`تم التبديل إلى بوابة: ${newRole}`, 'info');
    }
  };

  const loginWithStudentCode = async (code: string): Promise<boolean> => {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return false;

    // Query Supabase database if configured
    if (isSupabaseConfigured && supabase) {
      try {
        const { data: dbStudent } = await supabase
          .from('students')
          .select('*')
          .eq('student_code', cleanCode)
          .maybeSingle();

        if (dbStudent) {
          const studentProfile: Student = {
            id: dbStudent.id,
            name: dbStudent.name,
            gradeLevel: dbStudent.grade_level || "الصف الثاني المتوسط",
            gradeLevelEn: dbStudent.grade_level_en || "8th Grade",
            avatarUrl: dbStudent.avatar_url || "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80",
            studentCode: dbStudent.student_code,
            guardianId: dbStudent.guardian_id || "guard-1",
            guardianName: "ولي الأمر",
            schoolId: dbStudent.school_id || "sch-1",
            schoolName: "مدرسة مِدْرار الذكية",
            overallProgress: dbStudent.overall_progress || 0,
            attendanceRate: dbStudent.attendance_rate || 100,
            weeklyStudyHours: dbStudent.weekly_study_hours || 0,
            hasCompletedPreferenceTest: Boolean(dbStudent.primary_modality),
            currentStreakDays: dbStudent.current_streak_days || 1,
            streakDays: dbStudent.current_streak_days || 1,
            xpPoints: dbStudent.xp_points || 100,
            badges: ["طالب مِدْرار الذكي"],
            primaryModality: dbStudent.primary_modality || "visual",
            modalityScores: { visual: 25, interactive_kinesthetic: 25, auditory: 25, reading: 25 },
            enrolledSubjects: ["sub-math", "sub-sci", "sub-ara"]
          };

          setAllStudents((prev) => [studentProfile, ...prev.filter((s) => s.id !== studentProfile.id)]);
          setActiveStudentId(studentProfile.id);
          setRoleState('student');
          setActiveModal(null);
          showToast(`مرحباً بك يا ${studentProfile.name}! تم تسجيل الدخول برمزك المعتمد.`, 'success');
          return true;
        }
      } catch (_err) {
        // Fallthrough to dynamic creation if not found
      }
    }

    const found = allStudents.find((s) => s.studentCode.trim().toUpperCase() === cleanCode);
    if (found) {
      setActiveStudentId(found.id);
      setRoleState('student');
      setActiveModal(null);
      showToast(`مرحباً بك يا ${found.name}! تم تسجيل الدخول بنمطك المعتمد.`, 'success');
      return true;
    }

    // Create custom student entry for any new valid code
    const newStudentId = `stu-custom-${Date.now()}`;
    const newStudent: Student = {
      id: newStudentId,
      name: cleanCode.startsWith('STU-') ? `طالب جديد (${cleanCode})` : `الطالب (${cleanCode})`,
      gradeLevel: "الصف الثاني المتوسط",
      gradeLevelEn: "8th Grade (Middle School)",
      avatarUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80",
      studentCode: cleanCode,
      guardianId: "guard-1",
      guardianName: "ولي الأمر",
      schoolId: "sch-1",
      schoolName: "مدرسة مِدْرار الذكية",
      overallProgress: 0,
      attendanceRate: 100,
      weeklyStudyHours: 0.0,
      hasCompletedPreferenceTest: false,
      currentStreakDays: 1,
      streakDays: 1,
      xpPoints: 100,
      badges: ["مستكشف المسارات الجديد"],
      primaryModality: "visual",
      modalityScores: { visual: 25, interactive_kinesthetic: 25, auditory: 25, reading: 25 },
      enrolledSubjects: ["sub-math", "sub-sci", "sub-ara"],
      strengths: [{ ar: "الحماس لبدء التعلم الذكي", en: "High enthusiasm to start personalized AI learning" }],
      improvementAreas: [{ ar: "إكمال مقياس تفضيلات التعلم لتحديد المسار الدقيق", en: "Complete diagnostic test to lock learning modality" }]
    };

    if (isSupabaseConfigured && supabase) {
      supabase.from('students').insert([{
        id: newStudent.id,
        name: newStudent.name,
        student_code: cleanCode,
        grade_level: newStudent.gradeLevel,
        guardian_id: "guard-1"
      }]);
    }

    setAllStudents((prev) => [newStudent, ...prev]);
    setActiveStudentId(newStudentId);
    setRoleState('student');
    setActiveModal(null);
    showToast(`مرحباً بك! تم إنشاء حسابك برمز ${cleanCode}.`, 'success');
    return true;
  };

  const loginWithEmail = async (email: string, passwordInput: string, targetRole: UserRole): Promise<boolean> => {
    const cleanEmail = email.trim().toLowerCase();
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: passwordInput
      });

      if (error) {
        let msg = 'خطأ في تسجيل الدخول. يرجى التأكد من البريد وكلمة المرور.';
        if (error.message.includes('Invalid login credentials') || error.code === 'invalid_credentials') {
          msg = 'بيانات الدخول غير صحيحة. يرجى التأكد من البريد وكلمة المرور، أو اضغط على "إنشاء حساب جديد".';
        } else if (error.message.includes('Email not confirmed') || error.code === 'email_not_confirmed') {
          msg = 'يرجى تأكيد البريد الإلكتروني الخاص بك أولاً، أو تم تحويلك للدروس مباشرة.';
          // Allow session entry for unconfirmed emails during demo/onboarding
          setCustomUserProfile({
            id: `user-${Date.now()}`,
            name: cleanEmail.split('@')[0],
            email: cleanEmail,
            role: targetRole,
            locale: 'ar'
          });
          setRoleState(targetRole);
          setActiveModal(null);
          showToast(msg, 'info');
          return true;
        }
        showToast(msg, 'error');
        return false;
      }

      if (data.user) {
        const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).maybeSingle();
        const userRole = (profile?.role as UserRole) || targetRole;
        const name = profile?.full_name || cleanEmail.split('@')[0];

        setCustomUserProfile({
          id: data.user.id,
          name,
          email: cleanEmail,
          role: userRole,
          city: profile?.city || 'الرياض',
          locale: 'ar'
        });
        setRoleState(userRole);
        setActiveModal(null);
        showToast(`مرحباً بك يا ${name}! تم تسجيل الدخول بنجاح.`, 'success');
        return true;
      }
    }

    // Local authentication fallback
    setCustomUserProfile({
      id: `user-${Date.now()}`,
      name: cleanEmail.split('@')[0],
      email: cleanEmail,
      role: targetRole,
      locale: 'ar'
    });
    setRoleState(targetRole);
    setActiveModal(null);
    showToast(`تم تسجيل الدخول بنجاح كـ ${targetRole}.`, 'success');
    return true;
  };

  const registerWithEmail = async (email: string, passwordInput: string, name: string, targetRole: UserRole): Promise<boolean> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim() || cleanEmail.split('@')[0];

    if (passwordInput.length < 6) {
      showToast('كلمة المرور يجب أن تتكون من 6 خانات أو أكثر.', 'warning');
      return false;
    }

    // Direct Production DB Insertion via Server API (Guarantees Supabase Auth & public.profiles record creation)
    try {
      const apiRes = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, password: passwordInput, name: cleanName, role: targetRole })
      });

      const resData = await apiRes.json();
      if (apiRes.ok && resData.status === 'success' && resData.user) {
        setCustomUserProfile({
          id: resData.user.id,
          name: cleanName,
          email: cleanEmail,
          role: targetRole,
          locale: 'ar'
        });
        setRoleState(targetRole);
        setActiveModal(null);
        showToast(`تم إنشاء حسابك وتسجيله في قاعدة البيانات بنجاح! مرحباً بك يا ${cleanName}.`, 'success');
        return true;
      }
    } catch (_apiErr) {
      // Fallback to client SDK if API server is not reached
    }

    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.auth.signUp({
        email: cleanEmail,
        password: passwordInput,
        options: {
          data: { full_name: cleanName, role: targetRole }
        }
      });

      if (error) {
        let msg = error.message || 'تعذر إنشاء الحساب. يرجى المحاولة مرة أخرى.';
        if (error.message.includes('invalid') || error.code === 'email_address_invalid') {
          msg = 'يرجى كتابة بريد إلكتروني صحيح (مثال: user@gmail.com).';
        } else if (error.message.includes('already registered') || error.code === 'user_already_exists') {
          msg = 'هذا البريد مسجل بالفعل! يرجى اختيار "لديك حساب بالفعل؟ تسجيل الدخول".';
        }
        showToast(msg, 'error');
        return false;
      }

      if (data.user) {
        try {
          await supabase.from('profiles').upsert([{
            id: data.user.id,
            role: targetRole,
            full_name: cleanName,
            email: cleanEmail
          }]);
        } catch (_dbErr) {
        }

        setCustomUserProfile({
          id: data.user.id,
          name: cleanName,
          email: cleanEmail,
          role: targetRole,
          locale: 'ar'
        });
        setRoleState(targetRole);
        setActiveModal(null);
        showToast(`تم إنشاء حسابك بنجاح! مرحباً بك يا ${cleanName}.`, 'success');
        return true;
      }
    }

    setCustomUserProfile({
      id: `user-${Date.now()}`,
      name: cleanName,
      email: cleanEmail,
      role: targetRole,
      locale: 'ar'
    });
    setRoleState(targetRole);
    setActiveModal(null);
    showToast(`تم إنشاء الحساب بنجاح كـ ${targetRole}.`, 'success');
    return true;
  };

  const logout = async () => {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    }
    setCustomUserProfile(null);
    setRoleState('guest');
    showToast('تم تسجيل الخروج بنجاح.', 'info');
  };

  const submitAssignment = (assignmentId: string, content: string) => {
    setAssignments((prev) =>
      prev.map((a) =>
        a.id === assignmentId
          ? {
              ...a,
              status: 'submitted',
              submittedAt: new Date().toISOString().split('T')[0],
              submissionContent: content
            }
          : a
      )
    );
    triggerConfetti();
    showToast('تم تسليم الواجب بنجاح! سيصل إشعار للمعلم لمراجعته.', 'success');
  };

  const gradeAssignment = (assignmentId: string, score: number, feedbackAr: string, feedbackEn: string) => {
    setAssignments((prev) =>
      prev.map((a) =>
        a.id === assignmentId
          ? {
              ...a,
              status: 'graded',
              grade: score,
              teacherFeedbackAr: feedbackAr,
              teacherFeedbackEn: feedbackEn
            }
          : a
      )
    );
    showToast('تم رصد الدرجة وإرسال التقييم إلى الطالب وولي الأمر.', 'success');
  };

  const completeQuiz = (quizId: string, score: number) => {
    setQuizzes((prev) =>
      prev.map((q) => (q.id === quizId ? { ...q, isCompleted: true, scoreAchieved: score } : q))
    );
    triggerConfetti();
    showToast(`رائع جداً! تم إكمال الاختبار وتحقيق درجة ${score}%.`, 'success');
  };

  const saveLearningPreferenceTest = (result: LearningPreferenceResult) => {
    // Calculate primary modality from scores
    let primary: 'visual' | 'auditory' | 'reading' | 'interactive_kinesthetic' = 'visual';
    const v = result.visual || 0;
    const a = result.auditory || 0;
    const r = result.readingWriting || 0;
    const k = result.interactiveHandsOn || 0;

    if (v >= a && v >= r && v >= k) {
      primary = 'visual';
    } else if (a >= r && a >= k) {
      primary = 'auditory';
    } else if (k >= r) {
      primary = 'interactive_kinesthetic';
    } else {
      primary = 'reading';
    }

    setAllStudents((prev) =>
      prev.map((s) =>
        s.id === activeStudent.id
          ? {
              ...s,
              hasCompletedPreferenceTest: true,
              primaryModality: primary,
              modalityScores: {
                visual: v,
                auditory: a,
                reading: r,
                interactive_kinesthetic: k,
              },
              learningPreferences: result,
            }
          : s
      )
    );
    triggerConfetti();
    showToast('تم حفظ نتيجة مقياس تفضيلات التعلم وتحديث خطتك الذكية بشكل دائم!', 'success');
  };

  const addNewStudentToFamily = (name: string, gradeLevel: string): Student => {
    const randomCode = `STU-${Math.floor(1000 + Math.random() * 9000)}`;
    const newStudent: Student = {
      id: `stu-${Date.now()}`,
      name: name.trim(),
      gradeLevel: gradeLevel,
      gradeLevelEn: gradeLevel,
      avatarUrl: "/midrar.png",
      studentCode: randomCode,
      guardianId: customUserProfile?.id || "guard-1",
      guardianName: customUserProfile?.name || "ولي الأمر",
      overallProgress: 0,
      attendanceRate: 100,
      weeklyStudyHours: 0.0,
      hasCompletedPreferenceTest: false,
      currentStreakDays: 0,
      streakDays: 0,
      xpPoints: 100,
      badges: ["طالب جديد في منصة مِدْرار"],
      primaryModality: "visual",
      modalityScores: {
        visual: 25,
        interactive_kinesthetic: 25,
        auditory: 25,
        reading: 25
      },
      enrolledSubjects: ["sub-math", "sub-sci", "sub-ara"],
      strengths: [{ ar: "الحماس للتعلم والاستكشاف", en: "High curiosity to learn" }],
      improvementAreas: [{ ar: "إتمام مقياس نمط التعلم الأول", en: "Complete initial modality assessment" }]
    };

    // Save to Supabase public.students if DB is connected
    if (isSupabaseConfigured && supabase && customUserProfile?.id) {
      supabase.from('students').insert([{
        guardian_id: customUserProfile.id,
        name: name.trim(),
        student_code: randomCode,
        grade_level: gradeLevel
      }]).then(({ error }) => {
        if (error) console.warn('Supabase student insert notice:', error.message);
      });
    }

    setAllStudents((prev) => [...prev, newStudent]);
    showToast(`تمت إضافة الطالب (${name}) بنجاح! رمز الدخول الخاص به: ${randomCode}`, 'success');
    return newStudent;
  };

  const sendChatMessage = (conversationId: string, content: string) => {
    if (!content.trim()) return;
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      receiverId: conversationId,
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      direction: /[\u0600-\u06FF]/.test(content) ? 'rtl' : 'ltr'
    };

    setMessages((prev) => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg]
    }));

    setConversations((prev) =>
      prev.map((c) => (c.id === conversationId ? { ...c, lastMessage: content, lastMessageTime: "الآن" } : c))
    );
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const createCustomLesson = (newLesson: Partial<Lesson>) => {
    const created: Lesson = {
      id: `les-${Date.now()}`,
      subjectId: newLesson.subjectId || "sub-math",
      subjectTitleAr: newLesson.subjectTitleAr || "الرياضيات",
      subjectTitleEn: newLesson.subjectTitleEn || "Mathematics",
      titleAr: newLesson.titleAr || "درس جديد",
      titleEn: newLesson.titleEn || "New Lesson",
      unitTitleAr: newLesson.unitTitleAr || "الوحدة الدراسية",
      unitTitleEn: newLesson.unitTitleEn || "Study Unit",
      estimatedMinutes: newLesson.estimatedMinutes || 20,
      difficulty: newLesson.difficulty || "intermediate",
      isCompleted: false,
      summaryAr: newLesson.summaryAr || "ملخص الدرس المولد بالذكاء الاصطناعي.",
      summaryEn: newLesson.summaryEn || "AI generated lesson summary.",
      visualContent: newLesson.visualContent || {
        titleAr: "المخطط البصري",
        titleEn: "Visual Track",
        diagramDescriptionAr: "مخطط مفاهيمي للدرس",
        diagramDescriptionEn: "Concept map diagram",
        keyPointsAr: ["نقطة بصرية أساسية"],
        keyPointsEn: ["Key visual takeaway"],
        diagramType: "concept-map"
      },
      auditoryContent: newLesson.auditoryContent || {
        titleAr: "السرد الصوتي",
        titleEn: "Audio Track",
        audioScriptAr: "شرح حواري للدرس",
        audioScriptEn: "Conversational explanation",
        keyTakeawayAr: "الفكرة الرئيسية",
        keyTakeawayEn: "Main takeaway",
        duration: "3:00 دقيقة"
      },
      readingContent: newLesson.readingContent || {
        titleAr: "الملخص المقروء",
        titleEn: "Reading Track",
        textAr: "نص الدرس والتعريفات",
        textEn: "Lesson text & definitions",
        bulletPointsAr: ["عنصر أساسي 1"],
        bulletPointsEn: ["Core element 1"]
      },
      handsOnContent: newLesson.handsOnContent || {
        titleAr: "المسار التطبيقي",
        titleEn: "Hands-on Track",
        experimentGoalAr: "هدف التجربة العملية",
        experimentGoalEn: "Lab objective",
        stepsAr: ["الخطوة الأولى"],
        stepsEn: ["Step 1"],
        challengeAr: "تحدي الـ 5 دقائق",
        challengeEn: "5-Minute challenge"
      }
    };
    setLessons((prev) => [created, ...prev]);
    showToast("تم نشر الدرس المتكيف بنجاح وإتاحته للطلاب!", "success");
  };

  const createCustomQuiz = (newQuiz: Partial<Quiz>) => {
    const created: Quiz = {
      id: `quiz-${Date.now()}`,
      subjectId: newQuiz.subjectId || "sub-math",
      subjectTitleAr: newQuiz.subjectTitleAr || "الرياضيات",
      subjectTitleEn: newQuiz.subjectTitleEn || "Mathematics",
      titleAr: newQuiz.titleAr || "اختبار تقييم ذكي",
      titleEn: newQuiz.titleEn || "Smart Checkpoint Quiz",
      descriptionAr: newQuiz.descriptionAr || "اختبار متكيف بمساعد مدرار الذكي بتلميحات تدريجية",
      descriptionEn: newQuiz.descriptionEn || "Adaptive quiz with smart step-by-step hints",
      durationMinutes: newQuiz.durationMinutes || 10,
      totalScore: 100,
      isCompleted: false,
      questions: newQuiz.questions || []
    };
    setQuizzes((prev) => [created, ...prev]);
    showToast("تم إنشاء الاختبار ونشره للطلاب بنجاح!", "success");
  };

  const sendRecruitmentOffer = (teacherId: string, subject: string, message: string) => {
    const teacher = teachersCatalog.find((t) => t.id === teacherId);
    showToast(`تم إرسال عرض الاستقطاب لـ ${teacher?.name || 'المعلم'} بنجاح.`, 'success');
  };

  const rateTeacherExperience = (teacherId: string, stars: number, _comment: string) => {
    setTeachersCatalog((prev) =>
      prev.map((t) =>
        t.id === teacherId
          ? {
              ...t,
              reviewsCount: t.reviewsCount + 1,
              rating: Number(((t.rating * t.reviewsCount + stars) / (t.reviewsCount + 1)).toFixed(2))
            }
          : t
      )
    );
    showToast("شكراً لك! تم تسجيل تقييمك لمساعدة المجتمع الأكاديمي.", "success");
  };

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;
  const unreadMessagesCount = conversations.reduce((acc, c) => acc + c.unreadCount, 0);

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        currentUser,
        activeStudent,
        setActiveStudentId,
        allStudents,
        students: allStudents,
        subjects,
        lessons,
        assignments,
        quizzes,
        learningPlans,
        achievements,
        conversations,
        messages,
        teachersCatalog,
        notifications,
        unreadNotifsCount,
        unreadMessagesCount,
        toasts,
        showToast,
        removeToast,
        activeModal,
        setActiveModal,
        selectedLessonId,
        setSelectedLessonId,
        selectedQuizId,
        setSelectedQuizId,
        selectedTeacherId,
        setSelectedTeacherId,
        activeConversationId,
        setActiveConversationId,
        loginWithStudentCode,
        loginWithEmail,
        registerWithEmail,
        logout,
        submitAssignment,
        gradeAssignment,
        completeQuiz,
        saveLearningPreferenceTest,
        addNewStudentToFamily,
        sendChatMessage,
        markNotificationRead,
        createCustomLesson,
        createCustomQuiz,
        sendRecruitmentOffer,
        rateTeacherExperience,
        triggerConfetti
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
