export interface FAQItem {
  id: string;
  category: 'all' | 'students' | 'guardians' | 'teachers' | 'schools' | 'tech';
  questionAr: string;
  questionEn: string;
  answerAr: string;
  answerEn: string;
  tagsAr: string[];
  tagsEn: string[];
}

export const FAQ_CATEGORIES = [
  { id: 'all', labelAr: 'الكل', labelEn: 'All' },
  { id: 'students', labelAr: 'للطلاب وتجربة التعلم', labelEn: 'Students & Learning' },
  { id: 'guardians', labelAr: 'لأولياء الأمور والأسرة', labelEn: 'Guardians & Families' },
  { id: 'teachers', labelAr: 'للمعلمين والمناهج', labelEn: 'Teachers & Curriculum' },
  { id: 'schools', labelAr: 'لإدارات المدارس', labelEn: 'School Leaders' },
  { id: 'tech', labelAr: 'الذكاء الاصطناعي والخصوصية', labelEn: 'AI & Safety' },
] as const;

export const FAQ_ITEMS: FAQItem[] = [
  // --- Category: Students & Adaptive Learning ---
  {
    id: 'faq-differentiation',
    category: 'students',
    questionAr: 'ما هي فكرة مِدْرار؟ وكيف تختلف عن المنصات التعليمية المعتادة؟',
    questionEn: 'What is Midrar and how is it different from traditional platforms?',
    answerAr: 'مِدْرار لا تقدم درساً واحداً موحداً للجميع؛ بل تحلل أسلوب استيعاب كل طالب عبر اختبار الـ 25 موقفاً واقعياً، ثم تتيح لكل درس 4 مسارات موازية متكاملة (المسار البصري بالخرائط والانفوجرافيك، المسار السمعي بالبودكاست والنقاش، المسار القرائي بالمقالات والمراجع، والمسار التفاعلي بالمختبرات والمحاكاة العملية) ليختار الطالب الطريقة الأنسب لذهنه.',
    answerEn: 'Midrar does not deliver a one-size-fits-all lecture. It gauges each learner’s strengths through a 25-scenario diagnostic and unlocks 4 parallel learning tracks for every lesson: Visual diagrams, Auditory podcast-style discussions, Reading/Writing conceptual breakdowns, and Hands-on interactive simulations.',
    tagsAr: ['تخصيص', 'مسارات التعلم', 'فكرة المنصة'],
    tagsEn: ['Personalization', 'Learning Tracks', 'Platform Overview'],
  },
  {
    id: 'faq-modality-lock',
    category: 'students',
    questionAr: 'هل تحصر المنصة الطالب في مسار تعليمي واحد طوال العام؟',
    questionEn: 'Does the platform lock the student into a single learning modality?',
    answerAr: 'إطلاقاً؛ تفضيلات التعلم في مِدْرار مرنة وديناميكية. يستطيع الطالب في أي لحظة وبضغطة زر التبديل بين المسار البصري، السمعي، القرائي، أو العملي داخل نفس الدرس، مما يتيح له تعزيز فهمه للمفاهيم الصعبة من زوايا متعددة وتطوير مهارات استيعاب جديدة.',
    answerEn: 'Never. Learning preferences are treated as a flexible toolkit rather than a fixed label. Students can seamlessly switch between Visual, Auditory, Textual, and Interactive views inside any lesson to reinforce comprehension from multiple angles.',
    tagsAr: ['مرونة', 'تبديل المسارات', 'طريقة المذاكرة'],
    tagsEn: ['Flexibility', 'Multi-modal', 'Study Flow'],
  },
  {
    id: 'faq-test-diagnostic',
    category: 'students',
    questionAr: 'ماذا يقيس اختبار الـ 25 سؤالاً؟ وهل نتائجه نهائية؟',
    questionEn: 'What does the 25-question diagnostic measure and are its results final?',
    answerAr: 'يقيس الاختبار المزيج النسبي لميول الطالب الاستيعابية عبر سيناريوهات ومواقف واقعية ممتعة، خالية تماماً من المصطلحات المعقدة. النتائج ليست نهائية بل تمثل نقطة انطلاق تتطور وتتعدل ذاتياً مع تفاعل الطالب المستمر مع الدروس والتمارين.',
    answerEn: 'The diagnostic evaluates relative preference tendencies across real-world situational scenarios without tedious psychological jargon. Results serve as an adaptive baseline that evolves as the student interacts with activities over time.',
    tagsAr: ['اختبار التفضيلات', '25 سؤال', 'التشخيص الذكي'],
    tagsEn: ['Diagnostic Test', '25 Scenarios', 'Baseline'],
  },
  {
    id: 'faq-ai-study-assistant',
    category: 'students',
    questionAr: 'كيف يساعدني مساعد مِدْرار الذكي أثناء الاستذكار وحل التمارين؟',
    questionEn: 'How does the Midrar AI Study Assistant help me study and solve problems?',
    answerAr: 'المساعد الذكي مصمم ليكون موجهاً ومحفزاً للتفكير؛ لا يقدم الحلول الجاهزة فوراً، بل يقدم تلميحات تدريجية تفاعلية، ويشرح المفاهيم المعقدة بأمثلة من واقع الطالب، ويوضح سبب الخطأ وكيفية تصحيحه لترسيخ الفهم العميق.',
    answerEn: 'The AI Study Assistant acts as a patient coach. Instead of giving away direct answers, it provides multi-tier progressive hints, draws analogies to real-world context, and clarifies misconceptions step by step.',
    tagsAr: ['المساعد الذكي', 'تلميحات', 'مساعد المذاكرة'],
    tagsEn: ['AI Tutor', 'Smart Hints', 'Homework Help'],
  },
  {
    id: 'faq-offline-and-pdf',
    category: 'students',
    questionAr: 'هل يمكنني طباعة الملخصات والمذاكرة بدون إنترنت؟',
    questionEn: 'Can I print summaries and study offline?',
    answerAr: 'نعم، تتيح المنصة تصدير ملخصات الدروس والخرائط المفاهيمية كملفات PDF منسقة بدقة للطباعة أو الحفظ، مع إمكانية حل التمارين التفاعلية وحفظ التقدم محلياً في حال عدم توفر اتصال دائم.',
    answerEn: 'Yes! Students and educators can download beautifully formatted printable PDF summaries and concept maps, while local state caching ensures you never lose in-progress work during network interruptions.',
    tagsAr: ['طباعة PDF', 'ملخصات', 'المذاكرة بدون نت'],
    tagsEn: ['Printable PDF', 'Summaries', 'Offline Study'],
  },
  {
    id: 'faq-gamification',
    category: 'students',
    questionAr: 'كيف يعمل نظام النقاط والأوسمة ومستويات التقدم؟',
    questionEn: 'How does the points, badges, and streak gamification work?',
    answerAr: 'يكتسب الطالب نقاط خبرة (XP) وشارات إنجاز ملهمة عند استكمال الدروس بمساراتها المختلفة، التفوق في الاختبارات القصيرة، والمحافظة على وتيرة المذاكرة اليومية (Streak)، مما يشجع على الاستمرارية ويجعل التعلم رحلة ممتعة.',
    answerEn: 'Students earn experience points (XP) and unlock skill badges by completing lessons across varied tracks, mastering quizzes, and maintaining daily study streaks—transforming daily revision into an engaging journey.',
    tagsAr: ['نقاط و أوسمة', 'المستويات', 'التحفيز'],
    tagsEn: ['Gamification', 'Badges & XP', 'Daily Streaks'],
  },

  // --- Category: Guardians & Families ---
  {
    id: 'faq-child-safety-login',
    category: 'guardians',
    questionAr: 'هل يستطيع الطالب الصغير إنشاء حساب مستقل بمفرده دون إذن الأسرة؟',
    questionEn: 'Can young students create an account independently without parental consent?',
    answerAr: 'لا، لحماية القُصّر وسلامتهم الرقمية التامة، يتم إنشاء حسابات الطلاب حصرياً عبر ولي الأمر أو المدرسة. يدخل الطالب عبر رمز دخول آمن وسهل (Student Code) دون الحاجة لبريد إلكتروني شخصي أو كلمات مرور معقدة.',
    answerEn: 'No. To ensure total child safety and privacy compliance, student accounts are created exclusively by guardians or schools. Children log in via a dedicated, safe Student Code without requiring personal email addresses.',
    tagsAr: ['أمان الأطفال', 'تسجيل الدخول', 'رمز الطالب'],
    tagsEn: ['Child Safety', 'Safe Login', 'Student Code'],
  },
  {
    id: 'faq-parent-reports',
    category: 'guardians',
    questionAr: 'كيف تساعد لوحة ولي الأمر في متابعة مستوى الأبناء دون تعقيد؟',
    questionEn: 'How does the Guardian Dashboard simplify tracking my children’s academic progress?',
    answerAr: 'توفر المنصة تقارير أسبوعية تفاعلية باللغة العربية الواضحة والخالية من المصطلحات الإحصائية المبهمة. توضح التقارير نمط التعلم المفضل لابنك، نسبة إتقان المواد، نقاط القوة، وأبرز التوصيات التربوية القابلة للتطبيق المنزلي لدعمه.',
    answerEn: 'The Guardian Dashboard delivers easy-to-read weekly digests in plain language. It highlights your child’s learning preferences, topic mastery percentages, core strengths, and actionable home study tips.',
    tagsAr: ['لوحة ولي الأمر', 'تقارير أسبوعية', 'متابعة الأبناء'],
    tagsEn: ['Guardian Dashboard', 'Weekly Reports', 'Progress Tracking'],
  },
  {
    id: 'faq-parent-teacher-chat',
    category: 'guardians',
    questionAr: 'هل يمكنني التواصل المباشر مع معلمي أبنائي عبر المنصة؟',
    questionEn: 'Can I communicate directly with my child’s teachers via Midrar?',
    answerAr: 'نعم، تحتوي مِدْرار على قناة تواصل فورية وآمنة بين أولياء الأمور والمعلمين، تتيح مناقشة الملاحظات الأكاديمية، متابعة الواجبات المتأخرة، وتلقي التوجيهات المباشرة لتعزيز تحصيل الطالب.',
    answerEn: 'Yes. Midrar features a built-in secure messaging channel connecting parents with classroom teachers to discuss performance, review assignments, and coordinate personalized academic support.',
    tagsAr: ['تواصل مع المعلم', 'محادثات آمنة', 'التعاون الأسري'],
    tagsEn: ['Teacher Chat', 'Direct Messaging', 'School-Home Link'],
  },
  {
    id: 'faq-multiple-children',
    category: 'guardians',
    questionAr: 'هل يمكن لولي الأمر إضافة ومتابعة أكثر من ابن في حساب واحد؟',
    questionEn: 'Can a guardian manage and monitor multiple children in a single account?',
    answerAr: 'بكل تأكيد؛ يتيح حساب ولي الأمر إضافة جميع الأبناء بمراحل دراسية مختلفة وإدارتهم من لوحة تحكم مركزية واحدة، مع استعراض تقرير منفصل ومخصص لكل ابن بضغطة زر.',
    answerEn: 'Absolutely. Guardians can add all their children across different grades and schools into one single dashboard, switching between individual student profiles effortlessly.',
    tagsAr: ['تعدد الأبناء', 'لوحة تحكم موحدة', 'إدارة العائلة'],
    tagsEn: ['Multiple Children', 'Unified Dashboard', 'Family Management'],
  },

  // --- Category: Teachers & Curriculum ---
  {
    id: 'faq-teacher-lesson-generator',
    category: 'teachers',
    questionAr: 'كيف يساهم مولد الدروس الذكي في توفير وقت المعلم وجهده؟',
    questionEn: 'How does the AI lesson generator save teachers hours of prep time?',
    answerAr: 'يستطيع المعلم إدخال موضوع الدرس والصف الدراسي، ليقوم مِدْرار بتوليد درس متكامل فوري بـ 4 مسارات مختلفة (شرح بصري، نصي، حوار مسموع، وتطبيق تفاعلي)، بالإضافة إلى اختبار متدرج ونموذج إجابة في أقل من 30 ثانية.',
    answerEn: 'By simply specifying the lesson topic and grade level, Midrar instantly crafts a comprehensive 4-track lesson (Visual, Auditory, Text, Interactive) complete with progressive assessment questions and rubrics in under 30 seconds.',
    tagsAr: ['مولد الدروس', 'توفير الوقت', 'الذكاء للمعلم'],
    tagsEn: ['Lesson Generator', 'Time Saver', 'Teacher AI'],
  },
  {
    id: 'faq-teacher-customization',
    category: 'teachers',
    questionAr: 'هل يستطيع المعلم تعديل المحتوى المولد وتخصيص الأسئلة؟',
    questionEn: 'Can teachers edit generated content and customize quiz questions?',
    answerAr: 'نعم تماماً؛ يتمتع المعلم بالصلاحية الكاملة لتعديل النصوص، إضافة أمثلة محلية، حذف أو إضافة أسئلة، وتحديد درجة الصعوبة قبل نشر الدرس أو الواجب لفصوله الدراسية.',
    answerEn: 'Completely. Teachers retain 100% editorial control to adjust explanations, add custom exercises, refine hints, and set custom grading thresholds before publishing to their classrooms.',
    tagsAr: ['تخصيص المحتوى', 'تحكم المعلم', 'إعداد الواجبات'],
    tagsEn: ['Content Control', 'Teacher Customization', 'Assignment Builder'],
  },
  {
    id: 'faq-smart-grading',
    category: 'teachers',
    questionAr: 'كيف يساعد نظام التصحيح الذكي في تقييم إجابات الطلاب المقالية والأنشطة؟',
    questionEn: 'How does the smart grader assist in assessing student assignments and open answers?',
    answerAr: 'يقوم نظام التصحيح بمراجعة إجابات الطلاب واقتراح تقييم مبدئي دقيق مع ملاحظات توجيهية بناءة لكل طالب بناءً على معايير المعلم، مع إتاحة المجال للمعلم للاعتماد أو التعديل الفوري.',
    answerEn: 'The assistant analyzes student submissions against your rubric, generating suggested scores and constructive feedback snippets that teachers can instantly approve, refine, or override.',
    tagsAr: ['تصحيح ذكي', 'مساعد التصحيح', 'ملاحظات فورية'],
    tagsEn: ['Smart Grading', 'Rubrics', 'Instant Feedback'],
  },

  // --- Category: School Leaders ---
  {
    id: 'faq-school-analytics',
    category: 'schools',
    questionAr: 'ما المؤشرات والتحليلات التي توفرها المنصة لإدارة المدرسة والمشرفين؟',
    questionEn: 'What analytics and KPIs does Midrar provide to school principals and supervisors?',
    answerAr: 'توفر لوحة إدارة المدرسة نظرة بانورامية حية: نسب الإتقان لكل مادة وصف، توزيع أنماط وتفضيلات التعلم بين الطلاب، إحصائيات نشاط المعلمين، وتقارير تفاعل أولياء الأمور لتسهيل اتخاذ القرارات التطويرية المبنية على البيانات.',
    answerEn: 'The School Leadership portal provides real-time oversight: subject mastery benchmarks, grade-level modality distributions, teacher activity metrics, and parental engagement rates to drive data-informed decisions.',
    tagsAr: ['إدارة المدرسة', 'مؤشرات الأداء', 'تحليل البيانات'],
    tagsEn: ['School Leadership', 'KPI Analytics', 'Institutional Data'],
  },
  {
    id: 'faq-curriculum-standards',
    category: 'schools',
    questionAr: 'هل تتوافق مِدْرار مع المناهج الوطنية ومعايير التعليم المعتمدة؟',
    questionEn: 'Is Midrar aligned with national educational curricula and standards?',
    answerAr: 'نعم، تم بناء وتصميم المنصة لتتوافق مع معايير ومفاهيم المناهج الوطنية في العلوم والرياضيات واللغات والاجتماعيات للمراحل الابتدائية والمتوسطة والثانوية.',
    answerEn: 'Yes. Midrar’s content taxonomy and concept mappings are mapped directly to national curricula across Science, Math, Languages, and Social Studies across all K-12 grade tiers.',
    tagsAr: ['المناهج الوطنية', 'المعايير المعتمدة', 'توافق المراحل'],
    tagsEn: ['Curriculum Alignment', 'National Standards', 'K-12 Subjects'],
  },

  // --- Category: AI & Safety ---
  {
    id: 'faq-student-privacy',
    category: 'tech',
    questionAr: 'كيف تضمن مِدْرار خصوصية بيانات الطلاب وأمنها السيبراني؟',
    questionEn: 'How does Midrar ensure student data privacy and cybersecurity?',
    answerAr: 'نلتزم بأعلى معايير حماية البيانات والخصوصية الرقمية. تشفير تام لجميع البيانات، عدم مشاركة أي معلومات شخصية مع أطراف خارجية، والالتزام بعدم تدريب نماذج الذكاء الاصطناعي العامة على بيانات الطلاب الخاصة.',
    answerEn: 'We adhere to rigorous data privacy standards. All data is encrypted at rest and in transit, no student PII is shared with third parties, and private learning interactions are never used to train public AI models.',
    tagsAr: ['حماية البيانات', 'الخصوصية', 'أمان عالي'],
    tagsEn: ['Data Privacy', 'Security', 'Encrypted'],
  },
  {
    id: 'faq-ai-accuracy',
    category: 'tech',
    questionAr: 'ما النموذج المستخدم في المساعد الذكي؟ وكيف نضمن دقته العلمية؟',
    questionEn: 'What AI model powers Midrar and how is academic accuracy safeguarded?',
    answerAr: 'تعتمد المنصة على نماذج Google Gemini المتقدمة مع طبقة إرشاد وتوجيه تربوي متخصصة (Pedagogical Guardrails) تضمن دقة الشروحات العلمية، صياغة لغوية سليمة، ومحتوى آمن يناسب الفئات العمرية المختلفة.',
    answerEn: 'Midrar leverages advanced Google Gemini models guided by rigorous pedagogical guardrails to ensure scientific accuracy, age-appropriate language, and verifiable step-by-step problem explanations.',
    tagsAr: ['Google Gemini', 'دقة علمية', 'ضوابط تربوية'],
    tagsEn: ['Gemini AI', 'Academic Rigor', 'Pedagogical Safety'],
  },
];
