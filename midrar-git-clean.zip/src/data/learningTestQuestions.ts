import { TestQuestion } from '../types';

export const LEARNING_PREFERENCE_QUESTIONS: TestQuestion[] = [
  {
    id: 1,
    questionAr: "عندما تتعلم موضوعاً جديداً، ما الذي يساعدك أكثر على البدء؟",
    questionEn: "When starting a new topic, what helps you begin most effectively?",
    category: 'visual',
    options: [
      { id: "1a", textAr: "مشاهدة مخطط بصري أو خريطة ذهنية تلخص الموضوع", textEn: "Viewing a visual concept map summarizing the topic", type: "visual", weight: 4 },
      { id: "1b", textAr: "الاستماع إلى شرح المعلم أو تسجيل صوتي يمهد للأفكار", textEn: "Listening to a teacher's introductory audio explanation", type: "auditory", weight: 4 },
      { id: "1c", textAr: "قراءة مقدمة مكتوبة ونقاط محددة في الكتاب", textEn: "Reading a concise written overview with bullet points", type: "readingWriting", weight: 4 },
      { id: "1d", textAr: "البدء فوراً بتجربة تطبيقية أو حل مسألة استكشافية", textEn: "Jumping right into an exploratory hands-on activity", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 2,
    questionAr: "عندما يشرح لك أحدهم طريقاً إلى مكان جديد، ماذا تفضل؟",
    questionEn: "When someone gives you directions to a new place, what do you prefer?",
    category: 'visual',
    options: [
      { id: "2a", textAr: "رؤية خريطة مرسومة أو مسار مصور على الشاشة", textEn: "Seeing a clear map or visual route on screen", type: "visual", weight: 4 },
      { id: "2b", textAr: "الاستماع إلى التعليمات الشفوية وتوجيهات الصوت", textEn: "Listening to spoken turn-by-turn audio directions", type: "auditory", weight: 4 },
      { id: "2c", textAr: "كتابة أسماء الشوارع والمعالم في مذكرة لقراءتها", textEn: "Writing street names and notes to read while traveling", type: "readingWriting", weight: 4 },
      { id: "2d", textAr: "أن يقودني أحدهم مرة واحدة أو أجرب السير بنفسي", textEn: "Walking or navigating the route directly in person", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 3,
    questionAr: "إذا أردت تذكر معلومة مهمة للاختبار، ماذا تفعل غالباً؟",
    questionEn: "If you need to recall important info for an exam, what do you usually do?",
    category: 'readingWriting',
    options: [
      { id: "3a", textAr: "تخيل شكل الصفحة وموضع الرسم أو التحديد اللوني", textEn: "Visualizing the page layout, colors, and highlighted areas", type: "visual", weight: 4 },
      { id: "3b", textAr: "ترديد المعلومة بصوت مسموع أو تذكر نبرة المعلم", textEn: "Repeating it aloud or recalling the teacher's tone of voice", type: "auditory", weight: 4 },
      { id: "3c", textAr: "إعادة كتابة الملخص والمفاهيم بيدي عدة مرات", textEn: "Rewriting the summary and notes by hand multiple times", type: "readingWriting", weight: 4 },
      { id: "3d", textAr: "ربط المعلومة بحركة أو تجربة قمت بحلها عملياً", textEn: "Connecting the fact to a hands-on physical activity or gesture", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 4,
    questionAr: "عند تعلم كلمة جديدة أو مصطلح علمي، ما الطريقة الأقرب لك؟",
    questionEn: "When learning a new vocabulary term or scientific concept, what fits you best?",
    category: 'auditory',
    options: [
      { id: "4a", textAr: "مشاهدة صورة أو بطاقة مصورة تعبر عن المعنى", textEn: "Looking at an illustrative flashcard depicting the meaning", type: "visual", weight: 4 },
      { id: "4b", textAr: "سماع نطق الكلمة وسياقها في جملة منطوقة", textEn: "Hearing its pronunciation in an audio sentence", type: "auditory", weight: 4 },
      { id: "4c", textAr: "قراءة تعريفها في القاموس وتدوين معناها", textEn: "Reading dictionary definitions and writing it in a sentence", type: "readingWriting", weight: 4 },
      { id: "4d", textAr: "تمثيل معناها بحركة أو استخدامها في لعبة تفاعلية", textEn: "Acting out its meaning or playing an interactive word game", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 5,
    questionAr: "إذا لم تفهم فكرة معينة من المرة الأولى، ماذا تطلب من المعلم؟",
    questionEn: "If you don't grasp an idea on the first try, what do you ask the teacher?",
    category: 'interactiveHandsOn',
    options: [
      { id: "5a", textAr: "أن يرسم رسماً توضيحياً أو جدول مقارنة على السبورة", textEn: "To sketch an illustrative diagram or visual comparison table", type: "visual", weight: 4 },
      { id: "5b", textAr: "أن يعيد شرحها بنبرة مختلفة ومثال شفهي بديل", textEn: "To re-explain verbally with a fresh spoken analogy", type: "auditory", weight: 4 },
      { id: "5c", textAr: "أن يزودني بنص مكتوب أو مادة مقروءة إضافية", textEn: "To provide an additional reading excerpt or written breakdown", type: "readingWriting", weight: 4 },
      { id: "5d", textAr: "أن يعطيني نموذجاً عملياً أو نشاطاً أقوم بتنفيذه بيدي", textEn: "To give me a hands-on exercise or tangible simulation", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 6,
    questionAr: "أثناء الدرس، ما النشاط الذي يجعلك أكثر تركيزاً وحيوية؟",
    questionEn: "During class, which activity keeps you most engaged and focused?",
    category: 'interactiveHandsOn',
    options: [
      { id: "6a", textAr: "عروض الشرائح المصممة جيداً والرسوم المتحركة", textEn: "Well-designed slide animations and visual infographics", type: "visual", weight: 4 },
      { id: "6b", textAr: "النقاشات الجماعية والحوارات الصوتية المثرية", textEn: "Rich group discussions and interactive Q&A dialogues", type: "auditory", weight: 4 },
      { id: "6c", textAr: "تدوين الملاحظات وتلخيص الأفكار في دفتري", textEn: "Taking structured handwritten notes and summarizing points", type: "readingWriting", weight: 4 },
      { id: "6d", textAr: "المشاركة في التجارب المخبرية والتطبيقات اليدوية", textEn: "Participating in laboratory experiments and practical tasks", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 7,
    questionAr: "عند تجميع لعبة تركيبية أو جهاز إلكتروني جديد، ماذا تفعل أولاً؟",
    questionEn: "When assembling a model kit or new gadget, what do you do first?",
    category: 'interactiveHandsOn',
    options: [
      { id: "7a", textAr: "النظر إلى الرسوم والمخططات المرفقة في الكتيب", textEn: "Studying the visual diagrams and exploded view drawings", type: "visual", weight: 4 },
      { id: "7b", textAr: "الاستماع لشخص يشرح لي شفهياً أو مشاهدة فيديو مع تعليق صوتي", textEn: "Listening to verbal tips or a narrated tutorial video", type: "auditory", weight: 4 },
      { id: "7c", textAr: "قراءة التعليمات والخطوات المكتوبة بدقة بنداً بنداً", textEn: "Reading step-by-step written instructions carefully", type: "readingWriting", weight: 4 },
      { id: "7d", textAr: "البدء فوراً بتركيب القطع وتجربة ما يناسب بالتجربة والخطأ", textEn: "Starting to assemble physical pieces directly by trial and error", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 8,
    questionAr: "ما الطريقة التي تفضلها لمراجعة الاختبارات؟",
    questionEn: "What is your preferred method for exam revision?",
    category: 'visual',
    options: [
      { id: "8a", textAr: "استعراض الخرائط المفاهيمية والبطاقات الملونة", textEn: "Reviewing mind maps and color-coded flashcards", type: "visual", weight: 4 },
      { id: "8b", textAr: "المناقشة مع زميل أو الاستماع لتسجيلات الدروس", textEn: "Discussing concepts with a peer or listening to audio notes", type: "auditory", weight: 4 },
      { id: "8c", textAr: "قراءة الكتاب والملخصات وحل المسائل المكتوبة", textEn: "Reading the textbook notes and writing answers to sample questions", type: "readingWriting", weight: 4 },
      { id: "8d", textAr: "حل اختبارات تفاعلية ومحاكاة مواقف الاختبار الحقيقية", textEn: "Taking interactive timed mock challenges and practical drills", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 9,
    questionAr: "عند قراءة قصة شيقة، ما الذي يجعلك تتذكر أحداثها بسهولة؟",
    questionEn: "When reading an exciting story, what helps you remember its plot best?",
    category: 'visual',
    options: [
      { id: "9a", textAr: "تخيل مشاهد القصة وملامح الشخصيات كفيلم سينمائي في مخيلتي", textEn: "Visualizing vivid scenes and character appearances like a movie", type: "visual", weight: 4 },
      { id: "9b", textAr: "تذكر نبرات الحوارات والجمل المميزة التي قالها الأبطال", textEn: "Remembering spoken dialogue rhythms and memorable quotes", type: "auditory", weight: 4 },
      { id: "9c", textAr: "تذكر الكلمات البليغة والأسلوب اللغوي المكتوب", textEn: "Remembering specific phrases and textual descriptions", type: "readingWriting", weight: 4 },
      { id: "9d", textAr: "تخيل نفسي أتحرك داخل القصة وأعيش تفاصيل المغامرة", textEn: "Imagining physical actions and living through the adventure events", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 10,
    questionAr: "كيف تفضل تعلم تجربة علمية (مثل دورة الماء أو التمثيل الضوئي)؟",
    questionEn: "How do you prefer to learn a scientific experiment (e.g. water cycle)?",
    category: 'interactiveHandsOn',
    options: [
      { id: "10a", textAr: "رسم بياني ملون أو فيديو ثلاثي الأبعاد يوضح المراحل", textEn: "A 3D animated diagram or colorful infographic of stages", type: "visual", weight: 4 },
      { id: "10b", textAr: "بودكاست أو شرح صوتي يشرح الحكاية العلمية بتسلسل جذاب", textEn: "A podcast or audio narrative detailing the scientific phenomenon", type: "auditory", weight: 4 },
      { id: "10c", textAr: "قراءة مقال علمي مفصل يحتوي على المصطلحات والمعادلات", textEn: "Reading an in-depth scientific article with formulas", type: "readingWriting", weight: 4 },
      { id: "10d", textAr: "إجراء التجربة المعملية بنفسي وملاحظة التغيرات بيدي", textEn: "Conducting the hands-on lab experiment and measuring changes", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 11,
    questionAr: "عند حفظ خطوات حل مسألة رياضية، ما الذي يساعدك؟",
    questionEn: "When memorizing steps to solve a math problem, what helps you most?",
    category: 'readingWriting',
    options: [
      { id: "11a", textAr: "تلوين كل خطوة بلون مميز في دفتر الرياضيات", textEn: "Color-coding each step distinctively in my notebook", type: "visual", weight: 4 },
      { id: "11b", textAr: "ترديد الخطوات بنغمة أو إيقاع صوتي محدد", textEn: "Chanting the steps with a specific audio rhythm or song", type: "auditory", weight: 4 },
      { id: "11c", textAr: "كتابة الخطوات بالرموز والكلمات وقراءتها مراراً", textEn: "Writing out mathematical steps in detail and reviewing them", type: "readingWriting", weight: 4 },
      { id: "11d", textAr: "حل 5 مسائل متنوعة بيدي متتالية للتمرن على الحركة", textEn: "Solving 5 varied problems hands-on to build muscle memory", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 12,
    questionAr: "ما نوع الواجب المنزلي الذي تستمتع بإنجازه أكثر؟",
    questionEn: "What type of homework assignment do you enjoy completing most?",
    category: 'visual',
    options: [
      { id: "12a", textAr: "تصميم لوحة أو ملصق بصري أو عرض تقديمي", textEn: "Designing a visual poster, infographic, or slide deck", type: "visual", weight: 4 },
      { id: "12b", textAr: "تسجيل صوتي لإلقاء فكرة أو المشاركة في مناظرة مسجلة", textEn: "Recording an audio presentation or speech on the topic", type: "auditory", weight: 4 },
      { id: "12c", textAr: "كتابة مقال تحليلي أو تقرير منظم بالإجابات", textEn: "Writing an analytical essay or well-structured written report", type: "readingWriting", weight: 4 },
      { id: "12d", textAr: "بناء مجسم أو تنفيذ نموذج تفاعلي أو تجربة مصورة", textEn: "Building a physical model or programming an interactive demo", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 13,
    questionAr: "عندما تشاهد فيديو تعليمياً، ما الجزء الأكثر فائدة لك؟",
    questionEn: "When watching an educational video, what part is most beneficial to you?",
    category: 'auditory',
    options: [
      { id: "13a", textAr: "الرسوم التوضيحية والأشكال والمؤثرات البصرية", textEn: "On-screen illustrations, animations, and graphical motion", type: "visual", weight: 4 },
      { id: "13b", textAr: "صوت المعلق ونبرته الواضحة وطريقة طرحه للأفكار", textEn: "The narrator's clear voice, tone modulation, and pacing", type: "auditory", weight: 4 },
      { id: "13c", textAr: "الكلمات والنصوص المكتوبة التي تظهر أسفل الشاشة", textEn: "Captions, subtitles, and key written summaries on screen", type: "readingWriting", weight: 4 },
      { id: "13d", textAr: "التطبيقات والتمارين التفاعلية التي يطلب من المشاهد تجربتها", textEn: "Prompted pauses for interactive problem solving and drills", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 14,
    questionAr: "إذا شرح المعلم مفهوماً صعباً، ماذا تفضل أن يحدث مباشرة بعد الشرح؟",
    questionEn: "After a teacher explains a tough concept, what do you prefer immediately?",
    category: 'interactiveHandsOn',
    options: [
      { id: "14a", textAr: "عرض رسم بياني يلخص المفهوم ككل", textEn: "Seeing a comprehensive visual chart summarizing the concept", type: "visual", weight: 4 },
      { id: "14b", textAr: "فتح باب الأسئلة الشفوية والنقاش المباشر", textEn: "Opening an open spoken Q&A session with the teacher", type: "auditory", weight: 4 },
      { id: "14c", textAr: "إعطاء دقيقتين لقراءة الملخص المكتوب في الكتاب", textEn: "Having 2 minutes to read the written summary in the text", type: "readingWriting", weight: 4 },
      { id: "14d", textAr: "تطبيق مسألة سريعة على الفور للتأكد من الفهم", textEn: "Tackling an instant practice exercise immediately", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 15,
    questionAr: "عند العمل في مشروع جماعي، ما الدور الأقرب لشغفك؟",
    questionEn: "When collaborating on a team project, which role suits you best?",
    category: 'visual',
    options: [
      { id: "15a", textAr: "تصميم العرض البصري وتنسيق الرسوم والألوان", textEn: "Designing visual layouts, graphics, and color schemes", type: "visual", weight: 4 },
      { id: "15b", textAr: "إلقاء العرض الشفهي ومحاورة الجمهور", textEn: "Presenting the spoken pitch and facilitating discussion", type: "auditory", weight: 4 },
      { id: "15c", textAr: "البحث في المراجع وصياغة النصوص والتقارير", textEn: "Researching literature and drafting the structured report", type: "readingWriting", weight: 4 },
      { id: "15d", textAr: "بناء النموذج الأولي واختبار طريقة العمل عملياً", textEn: "Building the physical prototype and testing operations hands-on", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 16,
    questionAr: "إذا أردت شرح فكرة جديدة لزميلك، كيف تبدأ؟",
    questionEn: "If you want to explain a new idea to a classmate, how do you start?",
    category: 'visual',
    options: [
      { id: "16a", textAr: "أرسم له رسماً سريعاً أو مخططاً على ورقة", textEn: "I sketch a quick visual diagram on a blank sheet", type: "visual", weight: 4 },
      { id: "16b", textAr: "أتحدث معه وأشرح الفكرة بنبرة تفاعلية", textEn: "I explain it conversationally with spoken storytelling", type: "auditory", weight: 4 },
      { id: "16c", textAr: "أكتب له النقاط الرئيسية في رسالة أو ورقة مرتبة", textEn: "I write down clear bullet points in a neat note", type: "readingWriting", weight: 4 },
      { id: "16d", textAr: "أجعله يجرب خطوة عملية معي بالممارسة المباشرة", textEn: "I walk him through a hands-on practical exercise together", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 17,
    questionAr: "ما الذي يساعدك أكثر على تذكر أسماء الأشخاص أو الأماكن؟",
    questionEn: "What helps you remember names of people or landmarks most easily?",
    category: 'visual',
    options: [
      { id: "17a", textAr: "تذكر ملامح الوجه أو الصورة البصرية للمكان", textEn: "Remembering facial features or the place's visual scenery", type: "visual", weight: 4 },
      { id: "17b", textAr: "تذكر نغمة الصوت أو طريقة نطق الاسم", textEn: "Remembering vocal tone or sound of the pronounced name", type: "auditory", weight: 4 },
      { id: "17c", textAr: "رؤية الاسم مكتوباً على بطاقة أو شاشة", textEn: "Seeing the name printed on a name tag or screen", type: "readingWriting", weight: 4 },
      { id: "17d", textAr: "تذكر الموقف الحركي أو النشاط الذي جمعنا معاً", textEn: "Remembering the shared activity or interaction we performed", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 18,
    questionAr: "عند تعلم مهارة جديدة (كالبرمجة، الرسم، أو الرياضة)، ماذا تفضل؟",
    questionEn: "When learning a new skill (coding, art, sports), what do you prefer?",
    category: 'interactiveHandsOn',
    options: [
      { id: "18a", textAr: "مشاهدة محترف يقوم بالأمر بوضوح أمامي", textEn: "Watching an expert demonstrate the visual technique", type: "visual", weight: 4 },
      { id: "18b", textAr: "الاستماع لإرشادات المدرب خطوة بخطوة", textEn: "Listening to coach audio cues and verbal coaching", type: "auditory", weight: 4 },
      { id: "18c", textAr: "قراءة دليل إرشادي مفصل يحتوي على القواعد", textEn: "Reading a comprehensive handbook with guidelines", type: "readingWriting", weight: 4 },
      { id: "18d", textAr: "مسك الأدوات والبدء بالممارسة الفعلية والتكرار", textEn: "Grabbing the tools and practicing directly through repetition", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 19,
    questionAr: "كيف تفضل تلقي الملاحظات والتقييم على أدائك في الواجب؟",
    questionEn: "How do you prefer to receive feedback and grading on your work?",
    category: 'readingWriting',
    options: [
      { id: "19a", textAr: "علامات ملونة ومخطط يوضح مستوى تقدمي بصرياً", textEn: "Color-coded visual rubric showing my performance bands", type: "visual", weight: 4 },
      { id: "19b", textAr: "جلسة محادثة صوتية قصيرة مع المعلم يناقشني فيها", textEn: "A short one-on-one voice conversation with the teacher", type: "auditory", weight: 4 },
      { id: "19c", textAr: "ملاحظات نصية مكتوبة ومفصلة بجانب كل إجابة", textEn: "Detailed written comments next to each question", type: "readingWriting", weight: 4 },
      { id: "19d", textAr: "تمرين تطبيقي تصحيحي أقوم بإعادة حله عملياً", textEn: "A corrective mini-challenge that I solve right away", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 20,
    questionAr: "عندما تشعر بالملل أو تشتت الانتباه أثناء الدراسة، ما الذي يعيد تركيزك؟",
    questionEn: "When feeling fatigued or distracted while studying, what restores your focus?",
    category: 'interactiveHandsOn',
    options: [
      { id: "20a", textAr: "تغيير طريقة العرض إلى فيديو أو صور ملونة جذابة", textEn: "Switching to an engaging visual video or colorful diagram", type: "visual", weight: 4 },
      { id: "20b", textAr: "الاستماع لموسيقى هادئة أو قراءة النص بصوت عالٍ", textEn: "Listening to ambient focus sound or reading text aloud", type: "auditory", weight: 4 },
      { id: "20c", textAr: "إعادة تنظيم مذكراتي وتلخيص الأفكار في قائمة جديدة", textEn: "Reorganizing my written checklist and bullet summaries", type: "readingWriting", weight: 4 },
      { id: "20d", textAr: "الوقوف وتغيير المكان والقيام بنشاط حركي خفيف", textEn: "Standing up, moving around, and doing a light physical activity", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 21,
    questionAr: "ما الطريقة الأفضل بالنسبة لك لفهم الأحداث التاريخية والمعارك؟",
    questionEn: "What is your best way to understand historical eras and timelines?",
    category: 'visual',
    options: [
      { id: "21a", textAr: "خط زمني مصور وخرائط تفاعلية توضح تحركات الجيوش", textEn: "An illustrated visual timeline and movement maps", type: "visual", weight: 4 },
      { id: "21b", textAr: "سماع قصة درامية مسجلة تروي الأحداث بأصوات الشخصيات", textEn: "Listening to a dramatic audio documentary with voice acting", type: "auditory", weight: 4 },
      { id: "21c", textAr: "قراءة وثائق تاريخية ومقالات تحليلية مفصلة", textEn: "Reading in-depth historical manuscripts and essays", type: "readingWriting", weight: 4 },
      { id: "21d", textAr: "تمثيل مشهد تاريخي أو زيارة متحف وتفحص القطع الأثرية", textEn: "Role-playing a scene or exploring museum artifacts hands-on", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 22,
    questionAr: "عند تعلم قاعدة لغوية أو نحوية، ماذا تفضل؟",
    questionEn: "When mastering a grammar rule or language structure, what do you prefer?",
    category: 'readingWriting',
    options: [
      { id: "22a", textAr: "جدول ملون يفرز حالات الإعراب مع أسهم توضيحية", textEn: "A color-coded visual grammar tree with directional arrows", type: "visual", weight: 4 },
      { id: "22b", textAr: "ترديد أبيات شعرية أو شواهد صوتية تلخص القاعدة", textEn: "Reciting mnemonic poetry verses or spoken rhymes", type: "auditory", weight: 4 },
      { id: "22c", textAr: "قراءة نصوص متنوعة واستخراج القاعدة وكتابتها", textEn: "Reading literary excerpts and writing out parsed examples", type: "readingWriting", weight: 4 },
      { id: "22d", textAr: "لعبة بطاقات تفاعلية لتكوين الجمل الصحيحة", textEn: "Playing interactive word cards to assemble correct phrases", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 23,
    questionAr: "إذا كان لديك 15 دقيقة فقط لمراجعة موضوع قبل الاختبار، ماذا تختار؟",
    questionEn: "If you have only 15 minutes before an exam, what do you choose to review?",
    category: 'visual',
    options: [
      { id: "23a", textAr: "النظر السريع إلى الخرائط الذهنية والمخططات البصرية", textEn: "Glancing over visual mind maps and diagram overviews", type: "visual", weight: 4 },
      { id: "23b", textAr: "الاستماع لملخص صوتي سريع يلخص أهم النقاط", textEn: "Listening to a high-speed audio recap of essential facts", type: "auditory", weight: 4 },
      { id: "23c", textAr: "قراءة ملخص النقاط الحرجة والتعريفات المكتوبة", textEn: "Skimming the critical formula list and written definitions", type: "readingWriting", weight: 4 },
      { id: "23d", textAr: "حل مسألتين سريعتين بيدي كإحماء ذهني", textEn: "Solving 2 quick warm-up problems on scratch paper", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 24,
    questionAr: "بعد انتهاء الدرس، كيف تتأكد أنك فهمت الموضوع بعمق؟",
    questionEn: "After finishing a lesson, how do you verify you truly understood it?",
    category: 'interactiveHandsOn',
    options: [
      { id: "24a", textAr: "عندما أستطيع رسم خريطة للمفهوم دون النظر للكتاب", textEn: "When I can draw a complete concept map from memory", type: "visual", weight: 4 },
      { id: "24b", textAr: "عندما أستطيع شرح الدرس بصوتي لشخص آخر بطلاقة", textEn: "When I can explain it verbally to someone else smoothly", type: "auditory", weight: 4 },
      { id: "24c", textAr: "عندما أستطيع كتابة ملخص متكامل بأسلوبي الخاص", textEn: "When I can write a coherent self-authored summary", type: "readingWriting", weight: 4 },
      { id: "24d", textAr: "عندما أستطيع تطبيق المفهوم في مسألة عملية واقعية جديدة", textEn: "When I can apply the concept to a novel real-world task", type: "interactiveHandsOn", weight: 4 },
    ]
  },
  {
    id: 25,
    questionAr: "إذا خُيّرت بين 4 أنشطة ختامية للوحدة الدراسية، ماذا تختار؟",
    questionEn: "If offered 4 culminating activities for the study unit, which one do you pick?",
    category: 'interactiveHandsOn',
    options: [
      { id: "25a", textAr: "تصميم مجلة حائط رقمية أو إنفوجرافيك تفاعلي", textEn: "Designing a digital infographic or interactive visual poster", type: "visual", weight: 4 },
      { id: "25b", textAr: "المشاركة في حلقة نقاش صوتية أو تسجيل بودكاست تعليمي", textEn: "Joining an audio round-table podcast debate", type: "auditory", weight: 4 },
      { id: "25c", textAr: "تأليف مقال شامل يربط الموضوع بالحياة اليومية", textEn: "Authoring an in-depth essay connecting topics to daily life", type: "readingWriting", weight: 4 },
      { id: "25d", textAr: "تنفيذ مشروع علمي عملي وتقديم نموذج حي", textEn: "Constructing a practical scientific project with a live demo", type: "interactiveHandsOn", weight: 4 },
    ]
  }
];

export function calculateLearningPreferences(answers: Record<number, string>): {
  visual: number;
  auditory: number;
  readingWriting: number;
  interactiveHandsOn: number;
  confidenceScore: number;
  summaryAr: string;
  summaryEn: string;
  strengthsAr: string[];
  strengthsEn: string[];
  suggestedStrategiesAr: string[];
  suggestedStrategiesEn: string[];
} {
  let visualScore = 0;
  let auditoryScore = 0;
  let readingWritingScore = 0;
  let interactiveHandsOnScore = 0;

  const totalAnswered = Object.keys(answers).length;

  LEARNING_PREFERENCE_QUESTIONS.forEach((q) => {
    const chosenOptionId = answers[q.id];
    if (chosenOptionId) {
      const option = q.options.find((o) => o.id === chosenOptionId);
      if (option) {
        if (option.type === 'visual') visualScore += option.weight;
        else if (option.type === 'auditory') auditoryScore += option.weight;
        else if (option.type === 'readingWriting') readingWritingScore += option.weight;
        else if (option.type === 'interactiveHandsOn') interactiveHandsOnScore += option.weight;
      }
    }
  });

  const totalPoints = visualScore + auditoryScore + readingWritingScore + interactiveHandsOnScore || 1;

  const visualPct = Math.round((visualScore / totalPoints) * 100);
  const auditoryPct = Math.round((auditoryScore / totalPoints) * 100);
  const readingWritingPct = Math.round((readingWritingScore / totalPoints) * 100);
  // Ensure sum is 100%
  const interactiveHandsOnPct = Math.max(0, 100 - (visualPct + auditoryPct + readingWritingPct));

  const confidenceScore = Math.min(98, Math.max(65, Math.round((totalAnswered / 25) * 95)));

  // Generate dynamic summaries
  const isDominantVisual = visualPct >= 30;
  const isDominantInteractive = interactiveHandsOnPct >= 30;
  const isDominantAuditory = auditoryPct >= 25;
  const isDominantReading = readingWritingPct >= 25;

  let summaryAr = `تُظهر نتيجتك مزيجاً متوازناً ومرناً (${visualPct}% بصري، ${interactiveHandsOnPct}% تفاعلي وتطبيقي، ${auditoryPct}% سمعي، ${readingWritingPct}% قراءة وكتابة).`;
  let summaryEn = `Your profile indicates a flexible, multi-modal blend (${visualPct}% Visual, ${interactiveHandsOnPct}% Interactive/Hands-on, ${auditoryPct}% Auditory, ${readingWritingPct}% Reading/Writing).`;

  if (isDominantVisual && isDominantInteractive) {
    summaryAr += " تستجيب بشكل رائع للخرائط المفاهيمية والتجارب العملية السريعة.";
    summaryEn += " You respond exceptionally well to visual concept maps paired with active hands-on exploration.";
  } else if (isDominantAuditory) {
    summaryAr += " يعزز الاستماع للحوارات والشروحات الصوتية استيعابك للمفاهيم المعقدة.";
    summaryEn += " Listening to engaging audio narratives and interactive dialogues significantly elevates your retention.";
  } else if (isDominantReading) {
    summaryAr += " يساعدك التلخيص المكتوب وقراءة النقاط الهيكلية في تثبيت المعلومات.";
    summaryEn += " Structured written overviews and note-taking provide strong cognitive anchors for your study sessions.";
  }

  const strengthsAr = [
    "القدرة على استيعاب الأفكار من مسارات متعددة",
    "التفاعل الإيجابي مع الأنشطة التوضيحية والتطبيقية",
    "المرونة الذهنية في التكيف مع أساليب التدريس المتنوعة"
  ];
  const strengthsEn = [
    "Multi-track comprehension across diverse formats",
    "High engagement with visual and interactive challenges",
    "Cognitive adaptability across varied teaching styles"
  ];

  const suggestedStrategiesAr = [
    "تفعيل المسار البصري عند بدء أي مفهوم جديد (مخططات ورسوم)",
    "إجراء التمارين التطبيقية السريعة بعد كل 15 دقيقة دراسة",
    "استخدام تلميحات المساعد الذكي خطوة بخطوة لبناء الثقة الذاتية"
  ];
  const suggestedStrategiesEn = [
    "Initiate new topics with visual diagrams and concept maps",
    "Engage with interactive mini-drills every 15 minutes of study",
    "Utilize step-by-step smart interactive hints from the AI tutor to build mastery"
  ];

  return {
    visual: visualPct,
    auditory: auditoryPct,
    readingWriting: readingWritingPct,
    interactiveHandsOn: interactiveHandsOnPct,
    confidenceScore,
    summaryAr,
    summaryEn,
    strengthsAr,
    strengthsEn,
    suggestedStrategiesAr,
    suggestedStrategiesEn
  };
}
