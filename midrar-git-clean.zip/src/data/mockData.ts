import {
  Student,
  Subject,
  Lesson,
  Assignment,
  Quiz,
  LearningPlanItem,
  Achievement,
  ChatConversation,
  ChatMessage,
  TeacherProfile,
  AppNotification
} from '../types';

export const INITIAL_STUDENTS: Student[] = [
  {
    id: "stu-1",
    name: "أحمد بن عبد الله الرشيد",
    gradeLevel: "الصف الثاني المتوسط",
    gradeLevelEn: "8th Grade (Middle School)",
    avatarUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80",
    studentCode: "STU-8821",
    guardianId: "guard-1",
    guardianName: "عبد الله الرشيد (ولي الأمر)",
    schoolId: "sch-1",
    schoolName: "مدارس الرواد الذكية الأهلية",
    overallProgress: 88,
    attendanceRate: 96,
    weeklyStudyHours: 14.5,
    hasCompletedPreferenceTest: true,
    currentStreakDays: 7,
    streakDays: 7,
    xpPoints: 1420,
    badges: ["مستكشف الأنماط", "بطل الرياضيات", "المثابرة الذهبية"],
    primaryModality: "visual",
    modalityScores: {
      visual: 38,
      interactive_kinesthetic: 32,
      auditory: 18,
      reading: 12
    },
    enrolledSubjects: ["sub-math", "sub-sci", "sub-ara", "sub-eng"],
    learningPreferences: {
      visual: 38,
      interactiveHandsOn: 32,
      auditory: 18,
      readingWriting: 12,
      confidenceScore: 92,
      completedDate: "2026-08-10",
      summaryAr: "تفضيل قوي للمسارات البصرية (38%) والأنشطة التطبيقية (32%). يستجيب بفاعلية للمخططات والرسوم البيانية والمحاكاة التفاعلية.",
      summaryEn: "Strong preference for visual tracks (38%) and interactive hands-on activities (32%). Responds best to diagrams and simulation models.",
      strengthsAr: ["الاستيعاب السريع للخرائط المفاهيمية", "التفكير الهندسي والتطبيقي", "المثابرة في حل التحديات التفاعلية"],
      strengthsEn: ["Fast visual synthesis of concept maps", "Spatial and geometric intuition", "Persistence in interactive challenges"],
      suggestedStrategiesAr: ["البدء برسم توضيحي لكل مفهوم جديد", "تطبيق 10 دقائق من التمارين العملية", "استخدام تلميحات تدريجية"],
      suggestedStrategiesEn: ["Begin concepts with visual diagram", "10-minute hands-on drill", "Step-by-step smart hints"]
    },
    strengths: [
      { ar: "الاستيعاب السريع للخرائط المفاهيمية والهندسية", en: "Fast visual comprehension in geometry & maps" },
      { ar: "الالتزام المستمر بالتسليم قبل الموعد", en: "Consistent on-time submission" },
      { ar: "التفاعل الإيجابي مع تلميحات المساعد الذكي", en: "Active engagement with AI Tutor smart hints" }
    ],
    improvementAreas: [
      { ar: "المسائل اللفظية المركبة في مادة الرياضيات", en: "Multi-step word problems in Mathematics" },
      { ar: "كتابة المقالات التلخيصية المطولة", en: "Long-form analytical essay summaries" }
    ]
  },
  {
    id: "stu-2",
    name: "سارة عبد الله الرشيد",
    gradeLevel: "الصف الخامس الابتدائي",
    gradeLevelEn: "5th Grade (Elementary)",
    avatarUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80",
    studentCode: "STU-5490",
    guardianId: "guard-1",
    guardianName: "عبد الله الرشيد (ولي الأمر)",
    schoolId: "sch-1",
    schoolName: "مدارس الرواد الذكية الأهلية",
    overallProgress: 94,
    attendanceRate: 98,
    weeklyStudyHours: 11.0,
    hasCompletedPreferenceTest: true,
    currentStreakDays: 12,
    streakDays: 12,
    xpPoints: 1890,
    badges: ["بلبل الفصاحة", "المستمع الفطن", "نجمة العلوم"],
    primaryModality: "auditory",
    modalityScores: {
      visual: 28,
      interactive_kinesthetic: 22,
      auditory: 34,
      reading: 16
    },
    enrolledSubjects: ["sub-math", "sub-sci", "sub-ara"],
    learningPreferences: {
      visual: 28,
      interactiveHandsOn: 22,
      auditory: 34,
      readingWriting: 16,
      confidenceScore: 89,
      completedDate: "2026-08-12",
      summaryAr: "تفضيل بارز للمسار السمعي (34%) مع مسار بصري داعم (28%). تستمتع بالشرح الحواري والقصص المسموعة.",
      summaryEn: "Prominent auditory preference (34%) with strong visual support (28%). Enjoys conversational narratives and audio stories.",
      strengthsAr: ["حفظ القواعد عبر السرد الصوتي", "طلاقة التعبير الشفهي", "التفاعل مع المناقشات الصفية"],
      strengthsEn: ["Auditory recall through spoken rhythm", "Spoken articulation & storytelling", "Active participation in voice dialogue"],
      suggestedStrategiesAr: ["الاستماع للقصة التعليمية الصوتية أولاً", "ترديد القواعد بصوت مسموع", "حل الألغاز الحوارية"],
      suggestedStrategiesEn: ["Listen to audio lesson narrative first", "Verbal vocalization of rules", "Conversational problem drills"]
    },
    strengths: [
      { ar: "الطلاقة في القراءة المعبرة والشعر العربي", en: "Expressive Arabic reading & recitation" },
      { ar: "الفضول العلمي في تجارب العلوم الطبيعية", en: "Scientific curiosity in Nature studies" }
    ],
    improvementAreas: [
      { ar: "التركيز عند حل المسائل الحسابية الطويلة", en: "Sustained attention during lengthy arithmetic division" }
    ]
  },
  {
    id: "stu-3",
    name: "عمر بن عبد الله الرشيد",
    gradeLevel: "الصف الأول المتوسط",
    gradeLevelEn: "7th Grade (Middle School)",
    avatarUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80",
    studentCode: "STU-1003",
    guardianId: "guard-1",
    guardianName: "عبد الله الرشيد (ولي الأمر)",
    schoolId: "sch-1",
    schoolName: "مدارس الرواد الذكية الأهلية",
    overallProgress: 0,
    attendanceRate: 100,
    weeklyStudyHours: 0.0,
    hasCompletedPreferenceTest: false,
    currentStreakDays: 1,
    streakDays: 1,
    xpPoints: 100,
    badges: ["مستكشف المسارات الجديد"],
    primaryModality: "visual",
    modalityScores: {
      visual: 25,
      interactive_kinesthetic: 25,
      auditory: 25,
      reading: 25
    },
    enrolledSubjects: ["sub-math", "sub-sci", "sub-ara"],
    strengths: [{ ar: "الحماس العالي لبدء التعلم الذكي", en: "Eagerness to start personalized AI learning" }],
    improvementAreas: [{ ar: "تحديد النمط التعليمي الدقيق عبر المقياس التشخيصي", en: "Determine exact learning modality through diagnostic test" }]
  }
];

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: "sub-math",
    titleAr: "الرياضيات المتكيفة",
    titleEn: "Adaptive Mathematics",
    iconName: "Calculator",
    color: "from-blue-500 to-cyan-500",
    progress: 88,
    teacherName: "أ. فهد الشمري",
    totalLessons: 16,
    completedLessons: 14
  },
  {
    id: "sub-sci",
    titleAr: "العلوم والاستكشاف",
    titleEn: "Science & Exploration",
    iconName: "FlaskConical",
    color: "from-emerald-500 to-teal-500",
    progress: 92,
    teacherName: "د. مريم السعيد",
    totalLessons: 12,
    completedLessons: 11
  },
  {
    id: "sub-ara",
    titleAr: "اللغة العربية والبلاغة",
    titleEn: "Arabic & Rhetoric",
    iconName: "BookOpen",
    color: "from-amber-500 to-orange-500",
    progress: 85,
    teacherName: "د. نورة الغامدي",
    totalLessons: 14,
    completedLessons: 12
  },
  {
    id: "sub-eng",
    titleAr: "اللغة الإنجليزية التفاعلية",
    titleEn: "Interactive English",
    iconName: "Languages",
    color: "from-indigo-500 to-purple-500",
    progress: 79,
    teacherName: "أ. طارق منصور",
    totalLessons: 10,
    completedLessons: 8
  }
];

export const INITIAL_LESSONS: Lesson[] = [
  {
    id: "les-1",
    subjectId: "sub-math",
    subjectTitleAr: "الرياضيات",
    subjectTitleEn: "Mathematics",
    titleAr: "نظرية فيثاغورس وتطبيقاتها الهندسية",
    titleEn: "Pythagorean Theorem & Geometric Applications",
    unitTitleAr: "الوحدة الثالثة: المثلثات والهندسة المستوية",
    unitTitleEn: "Unit 3: Triangles & Plane Geometry",
    estimatedMinutes: 20,
    difficulty: "intermediate",
    isCompleted: true,
    summaryAr: "استكشاف العلاقة الرياضية بين أضلاع المثلث القائم الزاوية وكيفية حساب الوتر باستخدام المربعات المنشأة على الأضلاع.",
    summaryEn: "Explore the mathematical relation between the sides of a right triangle and how to calculate the hypotenuse using squares on sides.",
    visualContent: {
      titleAr: "المخطط البصري لمربعات الأضلاع",
      titleEn: "Visual Geometric Proof with Squares",
      diagramDescriptionAr: "مخطط تفاعلي يُظهر مثلثاً قائماً أطوال أضلاعه 3، 4، 5، ومربعات ملونة منشأة على كل ضلع بمساحات 9، 16، 25.",
      diagramDescriptionEn: "Interactive visual showing a 3-4-5 right triangle with colored squares erected on each side (areas 9, 16, 25).",
      keyPointsAr: [
        "الوتر هو الضلع المقابل للزاوية القائمة وهو الأطول دائماً.",
        "مساحة المربع المنشأ على الوتر = مجموع مساحتي المربعين على الضلعين الآخرين.",
        "القانون الأساسي: أ² + ب² = ج²"
      ],
      keyPointsEn: [
        "Hypotenuse is always opposite to the 90-degree angle and is the longest.",
        "Square on hypotenuse = sum of squares on other two legs.",
        "Core Formula: a² + b² = c²"
      ],
      diagramType: "right-triangle-squares"
    },
    auditoryContent: {
      titleAr: "الشرح الصوتي الحواري",
      titleEn: "Conversational Audio Narration",
      audioScriptAr: "تخيل أنك تبني منزلاً وتريد التأكد من أن زاوية الجدار قائمة تماماً... المهندسون القدامى في مصر واليونان استخدموا حبلاً بـ 12 عقدة ليصنعوا مثلث 3-4-5!",
      audioScriptEn: "Imagine building a house and needing to ensure the corner is perfectly square... Ancient architects used a 12-knot rope to form a 3-4-5 triangle!",
      keyTakeawayAr: "تذكر نغمة القاعدة: مربع الأول + مربع الثاني = مربع الوتر دائماً!",
      keyTakeawayEn: "Remember the rhythmic rule: Leg squared plus leg squared equals hypotenuse squared!",
      duration: "3:45 دقيقة"
    },
    readingContent: {
      titleAr: "الملخص المنظم والنقاط الحرجة",
      titleEn: "Structured Text & Formula Definitions",
      textAr: "تنسب النظرية إلى العالم الإغريقي فيثاغورس، وتعتبر من أهم القوانين التي تربط الجبر بالهندسة الفضائية.",
      textEn: "Attributed to the Greek mathematician Pythagoras, it is a foundational pillar linking algebra with Euclidean spatial geometry.",
      bulletPointsAr: [
        "أ: طول الضلع القائم الأول (متر / سم)",
        "ب: طول الضلع القائم الثاني",
        "ج: طول الوتر (c = √(a² + b²))",
        "تطبيق عكس النظرية لإثبات أن الزاوية قائمة"
      ],
      bulletPointsEn: [
        "a: Length of the first perpendicular leg",
        "b: Length of the second leg",
        "c: Length of hypotenuse (c = √(a² + b²))",
        "Converse test to prove if angle is right-angled"
      ]
    },
    handsOnContent: {
      titleAr: "التجربة المعملية والتحدي التطبيقي",
      titleEn: "Hands-on Geometric Lab & Challenge",
      experimentGoalAr: "قص مربعات من الورق بمساحات 9 سم² و 16 سم² وتجميعها لتكوين مربع مساحته 25 سم².",
      experimentGoalEn: "Cut paper squares of 9cm² and 16cm² and assemble them to form a 25cm² square.",
      stepsAr: [
        "ارسم مثلثاً بأطوال 6 سم و 8 سم على ورقة بيضاء.",
        "احسب طول الوتر نظرياً (6² + 8² = 36 + 64 = 100 → √100 = 10 سم).",
        "قس الوتر بالمسطرة للتأكد من تطابق الحساب النظري مع القياس الواقعي."
      ],
      stepsEn: [
        "Draw a triangle with 6cm and 8cm legs on grid paper.",
        "Calculate hypotenuse mathematically (6² + 8² = 100 → √100 = 10cm).",
        "Measure with physical ruler to confirm theory matches empirical reality."
      ],
      challengeAr: "تحدي الـ 5 دقائق: إذا كان سلم طوله 13 متراً يبعد 5 أمتار عن حائط، ما الارتفاع الذي يصل إليه؟",
      challengeEn: "5-Minute Challenge: If a 13m ladder is 5m away from a wall, what height does it reach on the wall?"
    }
  },
  {
    id: "les-2",
    subjectId: "sub-sci",
    subjectTitleAr: "العلوم",
    subjectTitleEn: "Science",
    titleAr: "قوانين الحركة لنيوتن وتأثير الجاذبية",
    titleEn: "Newton's Laws of Motion & Gravity",
    unitTitleAr: "الوحدة الرابعة: الميكانيكا والطاقة",
    unitTitleEn: "Unit 4: Mechanics & Energy",
    estimatedMinutes: 25,
    difficulty: "intermediate",
    isCompleted: false,
    summaryAr: "فهم القوانين الثلاثة التي تحكم حركة الأجسام في الكون وكيف تتفاعل القوة مع الكتلة والتسارع.",
    summaryEn: "Understanding the three fundamental laws governing object motion and force-mass-acceleration interactions.",
    visualContent: {
      titleAr: "مخطط متجهات القوة والتسارع",
      titleEn: "Force Vector & Acceleration Diagram",
      diagramDescriptionAr: "رسومات متحركة لصاروخ فضائي يُظهر قوة الدفع للأعلى ومقاومة الجاذبية للأسفل مع أسهم متجهات ملونة.",
      diagramDescriptionEn: "Animated rocket diagram illustrating upward thrust vectors versus downward gravitational pull.",
      keyPointsAr: [
        "القانون الأول (القصور الذاتي): الجسم الساكن يبقى ساكناً ما لم تؤثر عليه قوة خارجية.",
        "القانون الثاني: القوة = الكتلة × التسارع (ق = ك × ت).",
        "القانون الثالث: لكل فعل رد فعل مساوٍ له في المقدار ومعاكس له في الاتجاه."
      ],
      keyPointsEn: [
        "1st Law (Inertia): An object at rest stays at rest unless acted upon by a net force.",
        "2nd Law: Force = Mass × Acceleration (F = m × a).",
        "3rd Law: For every action, there is an equal and opposite reaction."
      ],
      diagramType: "rocket-forces"
    },
    auditoryContent: {
      titleAr: "السرد الصوتي لقصة التفاحة وسفن الفضاء",
      titleEn: "Audio Story of Newton's Apple & Spacecraft",
      audioScriptAr: "عندما جلس إسحاق نيوتن تحت شجرة التفاح، لم يتساءل فقط لماذا سقطت التفاحة، بل لماذا لا يسقط القمر على الأرض؟ الإجابة تكمن في توازن الجاذبية مع السرعة المدارية!",
      audioScriptEn: "When Isaac Newton watched the apple fall, he wondered: why doesn't the moon fall into Earth too? The answer lies in the harmony between gravity and orbital velocity!",
      keyTakeawayAr: "تذكر: كلما زادت كتلة الجسم، احتجت لقوة أكبر لتغيير سرعته!",
      keyTakeawayEn: "Remember: Greater mass requires greater force to alter acceleration!",
      duration: "4:15 دقيقة"
    },
    readingContent: {
      titleAr: "التعريفات والمعادلات الفيزيائية",
      titleEn: "Physics Definitions & Equation Breakdown",
      textAr: "صاغ نيوتن هذه القوانين عام 1687 في كتابه المبادئ الرياضية للفلسفة الطبيعية، ولا تزال تشكل أساس علم الميكانيكا الكلاسيكية.",
      textEn: "Formulated in 1687 in Principia Mathematica, these principles remain the bedrock of classical mechanics.",
      bulletPointsAr: [
        "القوة (F): تقاس بوحدة النيوتن (N)",
        "الكتلة (m): تقاس بالكيلوجرام (kg)",
        "التسارع (a): يقاس بـ (م/ث²)",
        "الوزن = الكتلة × تسارع الجاذبية الأرضية (9.8 م/ث²)"
      ],
      bulletPointsEn: [
        "Force (F): Measured in Newtons (N)",
        "Mass (m): Measured in Kilograms (kg)",
        "Acceleration (a): Measured in m/s²",
        "Weight = Mass × Gravitational acceleration (9.8 m/s²)"
      ]
    },
    handsOnContent: {
      titleAr: "تجربة البالون النفاث وعربة الدفع",
      titleEn: "Jet Balloon Propulsion Lab",
      experimentGoalAr: "إثبات قانون نيوتن الثالث عملياً باستخدام بالون وخيط وقشة شرب.",
      experimentGoalEn: "Empirically demonstrate Newton's 3rd Law using a balloon, straw, and string.",
      stepsAr: [
        "مرر خيطاً طويلاً عبر قشة شرب وثبت طرفي الخيط عبر الغرفة.",
        "انفخ بالوناً دون ربط فوهته وثبته بشريط لاصق على القشة.",
        "أفلت فوهة البالون ولاحظ كيف يندفع الهواء للخلف بينما تندفع القشة للأمام بسرعة!"
      ],
      stepsEn: [
        "Thread a string through a straw and tape string ends across the room.",
        "Inflate a balloon without tying and tape it to the straw.",
        "Release the nozzle and observe air rushing backwards as straw shoots forward!"
      ],
      challengeAr: "إذا ضاعفت كتلة العربة ورميت بنفس القوة، ماذا سيحدث لسرعة انطلاقها؟",
      challengeEn: "If you double the cart mass while applying identical force, what happens to acceleration?"
    }
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: "ass-1",
    subjectId: "sub-math",
    subjectNameAr: "الرياضيات",
    subjectNameEn: "Mathematics",
    titleAr: "تطبيقات واقعية على المثلث القائم والوتر",
    titleEn: "Real-world Pythagorean Problem Set",
    descriptionAr: "حل 4 مسائل تطبيقية حول حساب ارتفاع المباني وأطوال المنحدرات مع رسم تخطيطي لكل مسألة.",
    descriptionEn: "Solve 4 applied geometric problems calculating building heights and ramps with diagrams.",
    dueDate: "2026-08-20",
    status: "graded",
    grade: 95,
    teacherFeedbackAr: "إجابات ممتازة جداً يا أحمد! استخدامك للمخططات البصرية أظهر فهماً عميقاً لخطوات الحل.",
    teacherFeedbackEn: "Outstanding work Ahmed! Your visual sketches demonstrated strong conceptual mastery.",
    submittedAt: "2026-08-16",
    submissionContent: "تم إرفاق ملف الحل بصيغة PDF وتدوين خطوات التعويض الهندسي والرسم التوضيحي.",
    rubricAr: ["صحة القوانين الرياضية (40%)", "دقة الحسابات الرقمية (30%)", "وضوح الرسم التوضيحي (30%)"],
    rubricEn: ["Formula Accuracy (40%)", "Calculations (30%)", "Diagram Clarity (30%)"]
  },
  {
    id: "ass-2",
    subjectId: "sub-sci",
    subjectNameAr: "العلوم",
    subjectNameEn: "Science",
    titleAr: "تقرير تجربة البالون وقانون نيوتن الثالث",
    titleEn: "Balloon Propulsion Lab Report",
    descriptionAr: "قم بتسجيل ملاحظاتك حول تجربة الدفع ورد الفعل وكتابة استنتاجك في 3 فقرات مرتبة.",
    descriptionEn: "Record empirical observations on the jet propulsion lab and draft your 3-paragraph conclusion.",
    dueDate: "2026-08-22",
    status: "pending",
    rubricAr: ["وصف خطوات التجربة (30%)", "تسجيل القياسات والزمن (30%)", "الاستنتاج العلمي وربطه بالقانون (40%)"],
    rubricEn: ["Step-by-step description (30%)", "Measurements (30%)", "Scientific deduction (40%)"]
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: "quiz-1",
    subjectId: "sub-math",
    subjectTitleAr: "الرياضيات",
    subjectTitleEn: "Mathematics",
    titleAr: "اختبار قصير: حساب الوتر والمثلثات القائمة",
    titleEn: "Mastery Quiz: Hypotenuse & Right Triangles",
    descriptionAr: "3 أسئلة تفاعلية مع تلميحات ذكية لتثبيت مهارة حساب الأضلاع المجهولة.",
    descriptionEn: "3 interactive checkpoint questions with smart step-by-step hints.",
    durationMinutes: 10,
    totalScore: 100,
    isCompleted: false,
    questions: [
      {
        id: "q1",
        questionAr: "في مثلث قائم الزاوية، إذا كان طولا ضلعي القائمة 6 سم و 8 سم، فما طول الوتر؟",
        questionEn: "In a right triangle, if the legs measure 6 cm and 8 cm, what is the hypotenuse?",
        optionsAr: ["10 سم", "14 سم", "12 سم", "48 سم"],
        optionsEn: ["10 cm", "14 cm", "12 cm", "48 cm"],
        correctIndex: 0,
        hint1Ar: "تذكر قانون فيثاغورس: ج² = أ² + ب²",
        hint1En: "Recall Pythagorean theorem: c² = a² + b²",
        hint2Ar: "احسب 6² = 36، و 8² = 64، ثم اجمعهما وخذ الجذر التربيعي لـ 100.",
        hint2En: "Calculate 6² = 36 and 8² = 64, sum them to 100, then find √100.",
        explanationAr: "ج² = 6² + 8² = 36 + 64 = 100، وبالتالي ج = √100 = 10 سم.",
        explanationEn: "c² = 6² + 8² = 36 + 64 = 100, hence c = √100 = 10 cm."
      },
      {
        id: "q2",
        questionAr: "أي من مجموعات الأطوال التالية تشكل أضلاع مثلث قائم الزاوية؟",
        questionEn: "Which of the following side length sets forms a right triangle?",
        optionsAr: ["5 سم، 12 سم، 13 سم", "4 سم، 5 سم، 6 سم", "2 سم، 3 سم، 4 سم", "7 سم، 8 سم، 9 سم"],
        optionsEn: ["5 cm, 12 cm, 13 cm", "4 cm, 5 cm, 6 cm", "2 cm, 3 cm, 4 cm", "7 cm, 8 cm, 9 cm"],
        correctIndex: 0,
        hint1Ar: "تحقق مما إذا كان مربع الضلع الأكبر يساوي مجموع مربعي الضلعين الآخرين.",
        hint1En: "Check if the square of the largest number equals the sum of the other two squares.",
        hint2Ar: "5² = 25، 12² = 144 → 25 + 144 = 169 = 13².",
        hint2En: "5² = 25, 12² = 144 → 25 + 144 = 169 = 13².",
        explanationAr: "5² + 12² = 25 + 144 = 169 = 13²، تنطبق نظرية فيثاغورس تماماً.",
        explanationEn: "5² + 12² = 25 + 144 = 169 = 13², fully validating the Pythagorean converse."
      },
      {
        id: "q3",
        questionAr: "إذا كان طول الوتر 15 سم وطول أحد ضلعي القائمة 9 سم، فما طول الضلع الآخر؟",
        questionEn: "If the hypotenuse is 15 cm and one leg is 9 cm, what is the other leg?",
        optionsAr: ["12 سم", "6 سم", "24 سم", "10 سم"],
        optionsEn: ["12 cm", "6 cm", "24 cm", "10 cm"],
        correctIndex: 0,
        hint1Ar: "لحساب أحد ضلعي القائمة: اطرح مربع الضلع المعلوم من مربع الوتر.",
        hint1En: "To find a leg: subtract the known leg square from hypotenuse square.",
        hint2Ar: "15² = 225، 9² = 81 → 225 - 81 = 144، فما جذر 144؟",
        hint2En: "15² = 225, 9² = 81 → 225 - 81 = 144. What is √144?",
        explanationAr: "ب² = 15² - 9² = 225 - 81 = 144 → ب = 12 سم.",
        explanationEn: "b² = 15² - 9² = 225 - 81 = 144 → b = 12 cm."
      }
    ]
  }
];

export const INITIAL_LEARNING_PLANS: LearningPlanItem[] = [
  {
    id: "plan-1",
    titleAr: "إتقان نظرية فيثاغورس والهندسة التحليلية",
    titleEn: "Pythagorean Theorem & Analytic Geometry Mastery",
    subjectAr: "الرياضيات",
    subjectEn: "Mathematics",
    status: "completed",
    targetDate: "2026-08-15",
    modalityPreference: "visual",
    descriptionAr: "التركيز على الرسوم التخطيطية وحساب مساحات المربعات المنشأة على المثلثات.",
    descriptionEn: "Visual mapping and geometric square construction on right triangles."
  },
  {
    id: "plan-2",
    titleAr: "تطبيقات قوانين الحركة لنيوتن والتسارع",
    titleEn: "Newtonian Motion & Acceleration Labs",
    subjectAr: "العلوم",
    subjectEn: "Science",
    status: "in_progress",
    targetDate: "2026-08-22",
    modalityPreference: "interactiveHandsOn",
    descriptionAr: "تنفيذ تجارب عملية بالدفع النفاث واختبار تأثير الكتلة على السرعة.",
    descriptionEn: "Hands-on momentum experiments testing mass variations on velocity."
  },
  {
    id: "plan-3",
    titleAr: "البلاغة والتعبير في النص الأدبي العربي",
    titleEn: "Arabic Rhetoric & Literary Expression",
    subjectAr: "اللغة العربية",
    subjectEn: "Arabic",
    status: "upcoming",
    targetDate: "2026-08-28",
    modalityPreference: "auditory",
    descriptionAr: "الاستماع إلى نماذج شعرية فصيحة ومحاكاة الإلقاء الصوتي المعبر.",
    descriptionEn: "Listening to classic vocal poetry recitation and vocal rhythm modeling."
  }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: "ach-1",
    titleAr: "شعلة الالتزام الأسبوعي",
    titleEn: "7-Day Study Streak",
    descriptionAr: "الدخول والتفاعل اليومي مع الدروس لمدة 7 أيام متتالية دون انقطاع.",
    descriptionEn: "Active continuous learning engagement for 7 consecutive days.",
    icon: "Flame",
    isUnlocked: true,
    unlockedAt: "2026-08-16",
    category: "streak"
  },
  {
    id: "ach-2",
    titleAr: "عبقري الهندسة البصرية",
    titleEn: "Visual Geometry Master",
    descriptionAr: "إتقان وحل جميع مسائل نظرية فيثاغورس بنسبة نجاح تفوق 90%.",
    descriptionEn: "Scored over 90% in all spatial geometric challenges.",
    icon: "Sparkles",
    isUnlocked: true,
    unlockedAt: "2026-08-14",
    category: "mastery"
  },
  {
    id: "ach-3",
    titleAr: "المستكشف الذكي",
    titleEn: "Adaptive Pioneer",
    descriptionAr: "إتمام مقياس تفضيلات التعلم الـ 25 موقفاً بنجاح.",
    descriptionEn: "Successfully completed the 25-scenario learning preference test.",
    icon: "Compass",
    isUnlocked: true,
    unlockedAt: "2026-08-10",
    category: "exploration"
  },
  {
    id: "ach-4",
    titleAr: "بطل التحديات المعملية",
    titleEn: "Hands-on Lab Champion",
    descriptionAr: "تنفيذ 5 تجارب عملية وتوثيق النتائج المعملية بنجاح.",
    descriptionEn: "Completed 5 hands-on experimental science labs.",
    icon: "Trophy",
    isUnlocked: false,
    category: "mastery"
  }
];

export const INITIAL_CONVERSATIONS: ChatConversation[] = [
  {
    id: "conv-1",
    participantId: "teach-1",
    participantName: "أ. فهد الشمري (معلم الرياضيات)",
    participantRole: "teacher",
    participantAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    participantTitleAr: "معلم أول رياضيات — مدارس الرواد",
    participantTitleEn: "Lead Mathematics Teacher — Al-Rowad Schools",
    lastMessage: "أحمد أظهر تفوقاً باهراً في درس فيثاغورس اليوم!",
    lastMessageTime: "منذ 25 دقيقة",
    unreadCount: 1
  },
  {
    id: "conv-2",
    participantId: "teach-2",
    participantName: "د. مريم السعيد (معلمة العلوم)",
    participantRole: "teacher",
    participantAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
    participantTitleAr: "مشرفة العلوم والفيزياء",
    participantTitleEn: "Science & Physics Supervisor",
    lastMessage: "يرجى تجهيز أدوات تجربة البالون النفاث لموعد الغد.",
    lastMessageTime: "أمس",
    unreadCount: 0
  },
  {
    id: "conv-3",
    participantId: "sch-1",
    participantName: "مدارس الرواد الذكية الأهلية (إدارة الاستقطاب)",
    participantRole: "school",
    participantAvatar: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=150&auto=format&fit=crop&q=80",
    participantTitleAr: "إدارة المجمع التعليمي",
    participantTitleEn: "Academic Complex Administration",
    lastMessage: "يسرنا دعوتكم لحضور اللقاء الفصلي لأولياء الأمور.",
    lastMessageTime: "منذ يومين",
    unreadCount: 0
  }
];

export const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  "conv-1": [
    {
      id: "msg-1",
      senderId: "teach-1",
      senderName: "أ. فهد الشمري",
      senderRole: "teacher",
      receiverId: "guard-1",
      content: "السلام عليكم ورحمة الله وبركاته، أود إبلاغكم بأن أحمد أظهر تفوقاً رائعاً في استيعاب المفاهيم الهندسية، ودرجته في الواجب الأخير كانت 95%.",
      timestamp: "10:15 ص",
      isRead: true,
      direction: "rtl"
    },
    {
      id: "msg-2",
      senderId: "guard-1",
      senderName: "عبد الله الرشيد",
      senderRole: "guardian",
      receiverId: "teach-1",
      content: "وعليكم السلام ورحمة الله وبركاته، جزاكم الله خيراً أستاذ فهد. لاحظنا تحمسه الكبير واستفادته من تلميحات منصة مِدْرار الذكية.",
      timestamp: "10:30 ص",
      isRead: true,
      direction: "rtl"
    },
    {
      id: "msg-3",
      senderId: "teach-1",
      senderName: "أ. فهد الشمري",
      senderRole: "teacher",
      receiverId: "guard-1",
      content: "أحمد أظهر تفوقاً باهراً في درس فيثاغورس اليوم! سنبدأ غداً بتحديات المسائل اللفظية المركبة وسأدعمه بمخططات بصرية تناسب نمطه.",
      timestamp: "11:05 ص",
      isRead: false,
      direction: "rtl"
    }
  ]
};

export const INITIAL_TEACHERS_CATALOG: TeacherProfile[] = [
  {
    id: "teach-1",
    name: "أ. فهد بن عبد العزيز الشمري",
    titleAr: "معلم خبير رياضيات وتفكير منطقي",
    titleEn: "Expert Mathematics & Logic Educator",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    subjectsAr: ["الرياضيات", "الهندسة التحليلية", "القدرات العامة"],
    subjectsEn: ["Mathematics", "Analytic Geometry", "Aptitude"],
    gradeLevelsAr: ["المرحلة المتوسطة", "المرحلة الثانوية"],
    gradeLevelsEn: ["Middle School", "High School"],
    cityAr: "الرياض",
    cityEn: "Riyadh",
    rating: 4.9,
    reviewsCount: 42,
    experienceYears: 11,
    isAvailableForRecruitment: true,
    bioAr: "حاصل على ماجستير في طرائق تدريس الرياضيات، ممارس معتمد في التعليم المتكيف وتوظيف الذكاء الاصطناعي لتنمية التفكير الرياضي الإبداعي.",
    bioEn: "M.Ed. in Mathematics Pedagogy, certified in adaptive learning and AI-augmented cognitive STEM frameworks.",
    guardianReviewsSummaryAr: "يشيد أولياء الأمور بأسلوبه الصبور في تبسيط المسائل المعقدة واستجابته السريعة لملاحظات الطلاب.",
    guardianReviewsSummaryEn: "Parents praise his patient style in demystifying complex concepts and prompt, supportive feedback."
  },
  {
    id: "teach-2",
    name: "د. مريم بنت صالح السعيد",
    titleAr: "دكتوراه في المناهج وتعليم العلوم والفيزياء",
    titleEn: "Ph.D. in Science & Physics Curriculum",
    avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
    subjectsAr: ["العلوم العامة", "الفيزياء الميكانيكية", "الكيمياء"],
    subjectsEn: ["General Science", "Physics", "Chemistry"],
    gradeLevelsAr: ["المرحلة الابتدائية العليا", "المرحلة المتوسطة"],
    gradeLevelsEn: ["Upper Elementary", "Middle School"],
    cityAr: "جدة",
    cityEn: "Jeddah",
    rating: 4.95,
    reviewsCount: 56,
    experienceYears: 14,
    isAvailableForRecruitment: true,
    bioAr: "باحثة ومؤلفة في تبسيط العلوم للأطفال، متخصصة في تصميم التجارب المعملية التفاعلية وربط المفاهيم النظرية بالتطبيقات الحياتية.",
    bioEn: "Researcher and author in science communication, specialized in interactive experimental lab designs.",
    guardianReviewsSummaryAr: "تقييمات ممتازة جداً من أولياء الأمور لتشجيعها الفضول العلمي وربط الدروس بتجارب ممتعة في المنزل.",
    guardianReviewsSummaryEn: "Outstanding parent reviews for fostering scientific curiosity through engaging experiments."
  },
  {
    id: "teach-3",
    name: "د. نورة بنت فهد الغامدي",
    titleAr: "أستاذة البلاغة والأدب العربي",
    titleEn: "Professor of Arabic Rhetoric & Literature",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    subjectsAr: ["اللغة العربية", "النحو والبلاغة", "الكتابة الإبداعية"],
    subjectsEn: ["Arabic Language", "Grammar & Rhetoric", "Creative Writing"],
    gradeLevelsAr: ["جميع المراحل الدراسية"],
    gradeLevelsEn: ["All Grade Levels"],
    cityAr: "الدمام",
    cityEn: "Dammam",
    rating: 4.88,
    reviewsCount: 38,
    experienceYears: 9,
    isAvailableForRecruitment: true,
    bioAr: "متخصصة في إحياء الشغف باللغة العربية عبر السرد القصصي والمسابقات الصوتية والتعبير الإبداعي.",
    bioEn: "Specialized in inspiring love for the Arabic language through storytelling, debate, and creative prose.",
    guardianReviewsSummaryAr: "أسلوب متميز في غرس حب القراءة والفصاحة لدى الطلاب بمختلف أعمارهم.",
    guardianReviewsSummaryEn: "Exceptional methodology in instilling reading mastery and eloquence across age groups."
  },
  {
    id: "teach-4",
    name: "أ. طارق بن كمال منصور",
    titleAr: "مدرب معتمد للغة الإنجليزية والـ IELTS",
    titleEn: "Certified ESL & IELTS Coach",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    subjectsAr: ["اللغة الإنجليزية", "المحادثة والاستماع", "التحضير للاختبارات الدولية"],
    subjectsEn: ["English ESL", "Listening & Speaking", "IELTS Preparation"],
    gradeLevelsAr: ["المرحلة المتوسطة", "المرحلة الثانوية"],
    gradeLevelsEn: ["Middle School", "High School"],
    cityAr: "الرياض",
    cityEn: "Riyadh",
    rating: 4.82,
    reviewsCount: 29,
    experienceYears: 8,
    isAvailableForRecruitment: false,
    bioAr: "خبير في تدريس الإنجليزية عبر الألعاب التفاعلية والمحادثات المباشرة الغامرة.",
    bioEn: "Expert in gamified language acquisition, immersion dialogues, and accent mastery.",
    guardianReviewsSummaryAr: "تطور ملحوظ في ثقة الطلاب بالتحدث باللغة الإنجليزية في غضون أسابيع قليلة.",
    guardianReviewsSummaryEn: "Measurable surge in student conversational confidence within a few weeks."
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: "notif-1",
    titleAr: "توصية ذكية جديدة من مساعد مدرار",
    titleEn: "New Midrar Smart Recommendation",
    bodyAr: "تم تحديث خطة تعلم الطالب أحمد بناءً على نتائج الاختبار الأخير بنجاح.",
    bodyEn: "Ahmed's adaptive learning plan has been updated based on recent quiz mastery.",
    timestamp: "منذ 10 دقائق",
    isRead: false,
    type: "recommendation"
  },
  {
    id: "notif-2",
    titleAr: "رسالة جديدة من المعلم",
    titleEn: "New Message from Teacher",
    bodyAr: "أرسل أ. فهد الشمري ملاحظة تشجيعية حول أداء أحمد في مادة الرياضيات.",
    bodyEn: "Teacher Fahad sent an encouraging note regarding Ahmed's math progress.",
    timestamp: "منذ 25 دقيقة",
    isRead: false,
    type: "message"
  },
  {
    id: "notif-3",
    titleAr: "إنجاز جديد مُكتسب!",
    titleEn: "New Achievement Unlocked!",
    bodyAr: "حصل أحمد على شارة 'شعلة الالتزام الأسبوعي' لإكماله 7 أيام دراسة متواصلة.",
    bodyEn: "Ahmed earned the '7-Day Streak' badge for uninterrupted daily study.",
    timestamp: "أمس",
    isRead: true,
    type: "achievement"
  }
];
