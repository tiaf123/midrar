-- ==============================================================================
-- MIDRAR (مِدْرار) - PRODUCTION POSTGRESQL / SUPABASE DATABASE SCHEMA
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. ROLES & PROFILES
CREATE TYPE user_role AS ENUM ('student', 'guardian', 'teacher', 'school', 'admin');
CREATE TYPE modality_type AS ENUM ('visual', 'auditory', 'reading', 'interactive_kinesthetic');

CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    role user_role NOT NULL DEFAULT 'student',
    full_name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. STUDENTS & ADAPTIVE METRICS
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    guardian_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    student_code VARCHAR(20) UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    grade_level TEXT NOT NULL,
    primary_modality modality_type DEFAULT 'visual',
    visual_score INT DEFAULT 25,
    auditory_score INT DEFAULT 25,
    reading_score INT DEFAULT 25,
    interactive_score INT DEFAULT 25,
    xp_points INT DEFAULT 0,
    streak_days INT DEFAULT 0,
    overall_progress INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. ADAPTIVE LESSONS (4 MODALITIES)
CREATE TABLE lessons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teacher_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    title_ar TEXT NOT NULL,
    title_en TEXT NOT NULL,
    subject TEXT NOT NULL,
    unit_title TEXT NOT NULL,
    grade_level TEXT NOT NULL,
    difficulty TEXT DEFAULT 'intermediate',
    estimated_minutes INT DEFAULT 25,
    visual_content JSONB,
    auditory_content JSONB,
    reading_content JSONB,
    hands_on_content JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. SMART ADAPTIVE QUIZZES & HINTS
CREATE TABLE quizzes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lesson_id UUID REFERENCES lessons(id) ON DELETE CASCADE,
    title_ar TEXT NOT NULL,
    title_en TEXT NOT NULL,
    questions JSONB NOT NULL, -- Array of { question, options, correctIndex, hint1, hint2, explanation }
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. RECRUITMENT OFFERS & TALENT MARKET
CREATE TABLE teacher_recruitment_offers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    teacher_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    subject TEXT NOT NULL,
    offer_message TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. TEACHER RATINGS & GUARDIAN REVIEWS
CREATE TABLE teacher_reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    guardian_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    teacher_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    rating_stars INT CHECK (rating_stars >= 1 AND rating_stars <= 5),
    feedback_text TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS (ROW LEVEL SECURITY) POLICIES
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_recruitment_offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_reviews ENABLE ROW LEVEL SECURITY;
