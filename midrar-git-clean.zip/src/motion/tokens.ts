/**
 * Midrar (مِدْرار) Motion Design System
 * Unified tokens, curves, spring physics, and directional helpers (RTL/LTR)
 */

export const motionTokens = {
  duration: {
    instant: 0.12,
    fast: 0.2,
    normal: 0.35,
    slow: 0.55,
    cinematic: 0.8,
  },

  easing: {
    standard: [0.22, 1, 0.36, 1] as const,
    enter: [0.16, 1, 0.3, 1] as const,
    exit: [0.7, 0, 0.84, 0] as const,
    soft: [0.25, 0.8, 0.25, 1] as const,
  },

  spring: {
    soft: {
      type: 'spring' as const,
      stiffness: 180,
      damping: 22,
    },
    responsive: {
      type: 'spring' as const,
      stiffness: 320,
      damping: 28,
    },
    playful: {
      type: 'spring' as const,
      stiffness: 260,
      damping: 18,
    },
    bouncy: {
      type: 'spring' as const,
      stiffness: 400,
      damping: 25,
    },
  },
};

/**
 * Directional Motion Helper
 * Returns tailored enter/exit offset based on RTL (Arabic) vs LTR (English)
 */
export const getDirectionalOffset = (isArabic: boolean, distance = 24) => {
  return {
    enterX: isArabic ? distance : -distance,
    exitX: isArabic ? -distance : distance,
    reverseEnterX: isArabic ? -distance : distance,
    reverseExitX: isArabic ? distance : -distance,
  };
};

/**
 * Common Animation Variants for Framer Motion / motion/react
 */
export const fadeVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      duration: motionTokens.duration.normal,
      ease: motionTokens.easing.enter,
    },
  },
  exit: {
    opacity: 0,
    transition: {
      duration: motionTokens.duration.fast,
      ease: motionTokens.easing.exit,
    },
  },
};

export const slideUpVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: motionTokens.duration.normal,
      ease: motionTokens.easing.standard,
    },
  },
  exit: {
    opacity: 0,
    y: -12,
    transition: {
      duration: motionTokens.duration.fast,
      ease: motionTokens.easing.exit,
    },
  },
};

export const staggerContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.07,
      delayChildren: 0.04,
    },
  },
};

export const staggerItemVariants = {
  hidden: { opacity: 0, y: 14 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: motionTokens.duration.normal,
      ease: motionTokens.easing.standard,
    },
  },
};

export const modalBackdropVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: motionTokens.duration.fast, ease: motionTokens.easing.enter },
  },
  exit: {
    opacity: 0,
    transition: { duration: motionTokens.duration.fast, ease: motionTokens.easing.exit },
  },
};

export const modalDialogVariants = {
  hidden: { opacity: 0, scale: 0.95, y: 12 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: motionTokens.spring.responsive,
  },
  exit: {
    opacity: 0,
    scale: 0.96,
    y: 8,
    transition: { duration: motionTokens.duration.fast, ease: motionTokens.easing.exit },
  },
};

export const bottomSheetVariants = {
  hidden: { y: '100%', opacity: 0.4 },
  visible: {
    y: 0,
    opacity: 1,
    transition: motionTokens.spring.responsive,
  },
  exit: {
    y: '100%',
    opacity: 0,
    transition: { duration: motionTokens.duration.fast, ease: motionTokens.easing.exit },
  },
};
