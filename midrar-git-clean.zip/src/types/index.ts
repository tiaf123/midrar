export type UserRole = 'guest' | 'student' | 'guardian' | 'teacher' | 'school';

export type Language = 'ar' | 'en';

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  role: UserRole;
  avatarUrl?: string;
  studentCode?: string;
  locale: Language;
  phone?: string;
  schoolName?: string;
  subjectsTaught?: string[];
  city?: string;
  rating?: number;
  experienceYears?: number;
  bio?: string;
}

export interface Student {
  id: string;
  name: string;
  gradeLevel: string;
  gradeLevelEn: string;
  avatarUrl: string;
  studentCode: string;
  guardianId: string;
  guardianName: string;
  schoolId?: string;
  schoolName?: string;
  overallProgress: number; // 0-100
  attendanceRate: number; // 0-100
  weeklyStudyHours: number;
  hasCompletedPreferenceTest?: boolean;
  learningPreferences?: LearningPreferenceResult;
  strengths: { ar: string; en: string }[];
  improvementAreas: { ar: string; en: string }[];
  enrolledSubjects: string[]; // subject IDs
  currentStreakDays: number;
  streakDays?: number;
  xpPoints?: number;
  badges?: string[];
  primaryModality?: 'visual' | 'auditory' | 'reading' | 'interactive_kinesthetic';
  modalityScores?: {
    visual: number;
    auditory: number;
    reading: number;
    interactive_kinesthetic: number;
  };
}

export interface LearningPreferenceResult {
  visual: number; // 0-100%
  auditory: number; // 0-100%
  readingWriting: number; // 0-100%
  interactiveHandsOn: number; // 0-100%
  confidenceScore: number;
  completedDate: string;
  summaryAr: string;
  summaryEn: string;
  strengthsAr: string[];
  strengthsEn: string[];
  suggestedStrategiesAr: string[];
  suggestedStrategiesEn: string[];
}

export interface TestQuestion {
  id: number;
  questionAr: string;
  questionEn: string;
  category: 'visual' | 'auditory' | 'readingWriting' | 'interactiveHandsOn';
  options: {
    id: string;
    textAr: string;
    textEn: string;
    type: 'visual' | 'auditory' | 'readingWriting' | 'interactiveHandsOn';
    weight: number;
  }[];
}

export interface Subject {
  id: string;
  titleAr: string;
  titleEn: string;
  iconName: string;
  color: string;
  progress: number;
  teacherName: string;
  totalLessons: number;
  completedLessons: number;
}

export interface Lesson {
  id: string;
  subjectId: string;
  subjectTitleAr: string;
  subjectTitleEn: string;
  titleAr: string;
  titleEn: string;
  unitTitleAr: string;
  unitTitleEn: string;
  estimatedMinutes: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  isCompleted: boolean;
  summaryAr: string;
  summaryEn: string;
  visualContent: {
    titleAr: string;
    titleEn: string;
    diagramDescriptionAr: string;
    diagramDescriptionEn: string;
    keyPointsAr: string[];
    keyPointsEn: string[];
    diagramType: string;
  };
  auditoryContent: {
    titleAr: string;
    titleEn: string;
    audioScriptAr: string;
    audioScriptEn: string;
    keyTakeawayAr: string;
    keyTakeawayEn: string;
    duration: string;
  };
  readingContent: {
    titleAr: string;
    titleEn: string;
    textAr: string;
    textEn: string;
    bulletPointsAr: string[];
    bulletPointsEn: string[];
  };
  handsOnContent: {
    titleAr: string;
    titleEn: string;
    experimentGoalAr: string;
    experimentGoalEn: string;
    stepsAr: string[];
    stepsEn: string[];
    challengeAr: string;
    challengeEn: string;
  };
}

export interface Assignment {
  id: string;
  lessonId?: string;
  subjectId: string;
  subjectNameAr: string;
  subjectNameEn: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'graded';
  grade?: number; // 0-100
  teacherFeedbackAr?: string;
  teacherFeedbackEn?: string;
  submittedAt?: string;
  submissionContent?: string;
  rubricAr?: string[];
  rubricEn?: string[];
}

export interface Quiz {
  id: string;
  subjectId: string;
  subjectTitleAr: string;
  subjectTitleEn: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  durationMinutes: number;
  totalScore: number;
  questions: QuizQuestion[];
  isCompleted?: boolean;
  scoreAchieved?: number;
}

export interface QuizQuestion {
  id: string;
  questionAr: string;
  questionEn: string;
  optionsAr: string[];
  optionsEn: string[];
  correctIndex: number;
  hint1Ar: string;
  hint1En: string;
  hint2Ar: string;
  hint2En: string;
  explanationAr: string;
  explanationEn: string;
}

export interface LearningPlanItem {
  id: string;
  titleAr: string;
  titleEn: string;
  subjectAr: string;
  subjectEn: string;
  status: 'completed' | 'in_progress' | 'upcoming';
  targetDate: string;
  modalityPreference: 'visual' | 'auditory' | 'readingWriting' | 'interactiveHandsOn';
  descriptionAr: string;
  descriptionEn: string;
}

export interface Achievement {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  icon: string;
  unlockedAt?: string;
  isUnlocked: boolean;
  category: 'streak' | 'mastery' | 'quiz' | 'exploration';
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  senderAvatar?: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
  direction: 'rtl' | 'ltr';
  attachmentName?: string;
}

export interface ChatConversation {
  id: string;
  participantId: string;
  participantName: string;
  participantRole: UserRole;
  participantAvatar?: string;
  participantTitleAr?: string;
  participantTitleEn?: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
}

export interface TeacherProfile {
  id: string;
  name: string;
  titleAr: string;
  titleEn: string;
  avatarUrl: string;
  subjectsAr: string[];
  subjectsEn: string[];
  gradeLevelsAr: string[];
  gradeLevelsEn: string[];
  cityAr: string;
  cityEn: string;
  rating: number;
  reviewsCount: number;
  experienceYears: number;
  isAvailableForRecruitment: boolean;
  bioAr: string;
  bioEn: string;
  guardianReviewsSummaryAr: string;
  guardianReviewsSummaryEn: string;
}

export interface RecruitmentOffer {
  id: string;
  schoolId: string;
  schoolName: string;
  teacherId: string;
  teacherName: string;
  subjectAr: string;
  subjectEn: string;
  status: 'pending' | 'accepted' | 'declined';
  sentDate: string;
  message: string;
}

export interface AppNotification {
  id: string;
  titleAr: string;
  titleEn: string;
  bodyAr: string;
  bodyEn: string;
  timestamp: string;
  isRead: boolean;
  type: 'assignment' | 'quiz' | 'message' | 'recommendation' | 'achievement' | 'alert';
  actionUrl?: string;
}
