-- ============================================================================
-- 🌟 منصة مِدْرار التعليمية الذكية (MIDRAR SMART PLATFORM)
-- 📚 COMPLETE PRODUCTION POSTGRESQL & SUPABASE SCHEMA
-- 🛡️ Includes All 4 Roles (Student, Guardian, Teacher, School),
--    Chat System, Realtime Subscriptions, Learning Preferences (25-Questions),
--    Adaptive Multi-Modal Lessons, Quizzes, Rubrics, AI Reports, and Strict RLS Policies.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. EXTENSIONS SETUP
-- ----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ----------------------------------------------------------------------------
-- 2. USER PROFILES & ROLES TABLE (public.profiles)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('student', 'guardian', 'teacher', 'school', 'admin')),
  full_name TEXT NOT NULL,
  email TEXT UNIQUE,
  phone TEXT,
  avatar_url TEXT,
  locale TEXT DEFAULT 'ar' CHECK (locale IN ('ar', 'en')),
  city TEXT,
  bio TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 3. SCHOOLS ORGANIZATIONS TABLE (public.schools)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.schools (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id UUID UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  license_number TEXT,
  principal_name TEXT,
  phone TEXT,
  email TEXT,
  logo_url TEXT,
  total_students_capacity INT DEFAULT 1000,
  is_verified BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 4. TEACHER PROFILES & SPECIALTIES (public.teachers)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.teachers (
  id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  school_id UUID REFERENCES public.schools(id) ON DELETE SET NULL,
  title_ar TEXT DEFAULT 'معلم خبير',
  title_en TEXT DEFAULT 'Expert Teacher',
  subjects_taught TEXT[] DEFAULT '{}',
  grade_levels TEXT[] DEFAULT '{}',
  experience_years INT DEFAULT 5,
  rating NUMERIC DEFAULT 4.9,
  reviews_count INT DEFAULT 0,
  is_available_for_recruitment BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 5. STUDENTS TABLE (Child Safety & Dual Access: Student / Guardian)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.students (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  guardian_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  school_id UUID REFERENCES public.schools(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  student_code TEXT UNIQUE NOT NULL, -- e.g. STU-8821 for COPPA-safe instant login (auto-generated via trigger)
  grade_level TEXT NOT NULL,         -- e.g. 'الصف الثاني المتوسط' / 'Grade 8'
  grade_level_en TEXT DEFAULT 'Grade 8',
  avatar_url TEXT,
  overall_progress NUMERIC DEFAULT 0 CHECK (overall_progress >= 0 AND overall_progress <= 100),
  attendance_rate NUMERIC DEFAULT 100 CHECK (attendance_rate >= 0 AND attendance_rate <= 100),
  weekly_study_hours NUMERIC DEFAULT 0,
  current_streak_days INT DEFAULT 0,
  xp_points INT DEFAULT 120,
  primary_modality TEXT CHECK (primary_modality IN ('visual', 'auditory', 'reading', 'interactive_kinesthetic')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index on student_code for ultra-fast instant student code logins
CREATE INDEX IF NOT EXISTS idx_students_student_code ON public.students(student_code);
CREATE INDEX IF NOT EXISTS idx_students_guardian_id ON public.students(guardian_id);

-- ----------------------------------------------------------------------------
-- AUTOMATIC STUDENT CODE GENERATION TRIGGER (Direct in Database)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.generate_unique_student_code()
RETURNS TRIGGER AS $$
DECLARE
  generated_code TEXT;
  code_exists BOOLEAN;
BEGIN
  -- Only generate if not explicitly supplied
  IF NEW.student_code IS NULL OR TRIM(NEW.student_code) = '' THEN
    LOOP
      -- Format: STU- followed by 4 random digits (e.g. STU-8821)
      generated_code := 'STU-' || LPAD(FLOOR(RANDOM() * 9000 + 1000)::TEXT, 4, '0');
      SELECT EXISTS(
        SELECT 1 FROM public.students WHERE student_code = generated_code
      ) INTO code_exists;
      EXIT WHEN NOT code_exists;
    END LOOP;
    NEW.student_code := generated_code;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_auto_student_code ON public.students;
CREATE TRIGGER trigger_auto_student_code
  BEFORE INSERT ON public.students
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_unique_student_code();

-- ----------------------------------------------------------------------------
-- GUARDIAN CHILDREN CODES SECURE VIEW
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.guardian_children_codes AS
SELECT
  s.id AS student_id,
  s.guardian_id,
  p.full_name AS guardian_name,
  s.name AS student_name,
  s.student_code,
  s.grade_level,
  s.grade_level_en,
  s.avatar_url,
  s.overall_progress,
  s.current_streak_days,
  s.xp_points,
  s.created_at
FROM public.students s
JOIN public.profiles p ON p.id = s.guardian_id;

-- ----------------------------------------------------------------------------
-- 6. STUDENT LEARNING PREFERENCES (25-Question Test Results & VARK Baseline)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.student_learning_preferences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  visual_pct INT NOT NULL CHECK (visual_pct BETWEEN 0 AND 100),
  auditory_pct INT NOT NULL CHECK (auditory_pct BETWEEN 0 AND 100),
  reading_writing_pct INT NOT NULL CHECK (reading_writing_pct BETWEEN 0 AND 100),
  interactive_hands_on_pct INT NOT NULL CHECK (interactive_hands_on_pct BETWEEN 0 AND 100),
  confidence_score INT DEFAULT 85,
  summary_ar TEXT,
  summary_en TEXT,
  strengths_ar TEXT[] DEFAULT '{}',
  strengths_en TEXT[] DEFAULT '{}',
  suggested_strategies_ar TEXT[] DEFAULT '{}',
  suggested_strategies_en TEXT[] DEFAULT '{}',
  raw_answers JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 7. SUBJECTS & CURRICULUM MODULES (public.subjects)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.subjects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  icon_name TEXT DEFAULT 'BookOpen',
  color_theme TEXT DEFAULT 'blue',
  order_index INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 8. MULTI-MODAL ADAPTIVE LESSONS (public.lessons)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.lessons (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subject_id UUID NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  teacher_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  unit_title_ar TEXT,
  unit_title_en TEXT,
  estimated_minutes INT DEFAULT 20,
  difficulty TEXT DEFAULT 'intermediate' CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  summary_ar TEXT,
  summary_en TEXT,
  visual_content JSONB NOT NULL DEFAULT '{}'::jsonb,   -- Diagrams, concept maps, color coding
  auditory_content JSONB NOT NULL DEFAULT '{}'::jsonb, -- Audio scripts, narratives, mnemonics
  reading_content JSONB NOT NULL DEFAULT '{}'::jsonb,  -- Structured bullet points, definitions
  hands_on_content JSONB NOT NULL DEFAULT '{}'::jsonb, -- Interactive steps, 5-minute challenges
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 9. STUDENT LESSON PROGRESS & ENGAGEMENT (public.student_lesson_progress)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.student_lesson_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  lesson_id UUID NOT NULL REFERENCES public.lessons(id) ON DELETE CASCADE,
  completed_modalities TEXT[] DEFAULT '{}',
  is_completed BOOLEAN DEFAULT FALSE,
  time_spent_seconds INT DEFAULT 0,
  last_accessed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, lesson_id)
);

-- ----------------------------------------------------------------------------
-- 10. ADAPTIVE QUIZZES & QUESTION BANK (public.quizzes & public.quiz_questions)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.quizzes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
  lesson_id UUID REFERENCES public.lessons(id) ON DELETE SET NULL,
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  description_ar TEXT,
  description_en TEXT,
  duration_minutes INT DEFAULT 15,
  total_score INT DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.quiz_questions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quiz_id UUID NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
  question_ar TEXT NOT NULL,
  question_en TEXT NOT NULL,
  options_ar TEXT[] NOT NULL,
  options_en TEXT[] NOT NULL,
  correct_index INT NOT NULL,
  hint1_ar TEXT,
  hint1_en TEXT,
  hint2_ar TEXT,
  hint2_en TEXT,
  explanation_ar TEXT,
  explanation_en TEXT,
  order_index INT DEFAULT 0
);

-- ----------------------------------------------------------------------------
-- 11. QUIZ SUBMISSIONS & MASTERY TRACKING (public.quiz_submissions)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.quiz_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quiz_id UUID NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  score NUMERIC NOT NULL,
  total_questions INT NOT NULL,
  correct_answers_count INT NOT NULL,
  hints_used_count INT DEFAULT 0,
  answers_json JSONB DEFAULT '[]'::jsonb,
  submitted_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 12. ASSIGNMENTS & HOMEWORK SUBMISSIONS (public.assignments & submissions)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subject_id UUID NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  lesson_id UUID REFERENCES public.lessons(id) ON DELETE SET NULL,
  teacher_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  description_ar TEXT,
  description_en TEXT,
  due_date DATE NOT NULL,
  rubric_ar TEXT[] DEFAULT '{}',
  rubric_en TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.assignment_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  assignment_id UUID NOT NULL REFERENCES public.assignments(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'submitted', 'graded')),
  submission_content TEXT,
  attachment_url TEXT,
  grade NUMERIC CHECK (grade >= 0 AND grade <= 100),
  teacher_feedback_ar TEXT,
  teacher_feedback_en TEXT,
  submitted_at TIMESTAMPTZ,
  graded_at TIMESTAMPTZ,
  UNIQUE(assignment_id, student_id)
);

-- ----------------------------------------------------------------------------
-- 13. REALTIME CHAT SYSTEM (public.chat_messages)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  attachment_name TEXT,
  attachment_url TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 14. SCHOOL RECRUITMENT OFFERS (public.recruitment_offers)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.recruitment_offers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  subject_ar TEXT NOT NULL,
  subject_en TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined')),
  message TEXT,
  sent_date TIMESTAMPTZ DEFAULT NOW(),
  responded_at TIMESTAMPTZ
);

-- ----------------------------------------------------------------------------
-- 15. PARENT WEEKLY AI REPORTS (public.parent_weekly_reports)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.parent_weekly_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  guardian_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  week_start_date DATE NOT NULL,
  overall_mastery NUMERIC NOT NULL,
  headline TEXT NOT NULL,
  summary_ar TEXT NOT NULL,
  summary_en TEXT NOT NULL,
  strengths_ar TEXT[] DEFAULT '{}',
  strengths_en TEXT[] DEFAULT '{}',
  home_advice_ar TEXT[] DEFAULT '{}',
  home_advice_en TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 16. NOTIFICATIONS SYSTEM (public.notifications)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  body_ar TEXT NOT NULL,
  body_en TEXT NOT NULL,
  type TEXT DEFAULT 'alert' CHECK (type IN ('assignment', 'quiz', 'message', 'recommendation', 'achievement', 'alert')),
  action_url TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 17. ACHIEVEMENTS & GAMIFICATION (public.achievements & student_achievements)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.achievements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  title_ar TEXT NOT NULL,
  title_en TEXT NOT NULL,
  description_ar TEXT NOT NULL,
  description_en TEXT NOT NULL,
  icon TEXT NOT NULL DEFAULT 'Award',
  category TEXT DEFAULT 'mastery' CHECK (category IN ('streak', 'mastery', 'quiz', 'exploration'))
);

CREATE TABLE IF NOT EXISTS public.student_achievements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  achievement_id UUID NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  unlocked_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, achievement_id)
);

-- ----------------------------------------------------------------------------
-- 18. AUTOMATIC TRIGGERS & FUNCTIONS
-- ----------------------------------------------------------------------------
-- Auto-create profile upon Auth sign-up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, role, full_name, email, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'role', 'student'),
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NEW.email,
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Auto update timestamp function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_profiles_timestamp
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER set_students_timestamp
  BEFORE UPDATE ON public.students
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ----------------------------------------------------------------------------
-- 19. ROW LEVEL SECURITY (RLS) POLICIES — HIGHEST PRIVACY & COPPA COMPLIANCE
-- ----------------------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schools ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_learning_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_lesson_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assignment_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recruitment_offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parent_weekly_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_achievements ENABLE ROW LEVEL SECURITY;

-- 1. Profiles: Users can view their own profile; teachers & schools public read
CREATE POLICY profiles_self_access ON public.profiles
  FOR ALL TO authenticated
  USING (auth.uid() = id);

CREATE POLICY public_profiles_view ON public.profiles
  FOR SELECT TO authenticated
  USING (role IN ('teacher', 'school'));

-- 2. Students & Guardians RLS: Guardian has full access to their children
CREATE POLICY guardian_student_access ON public.students
  FOR ALL TO authenticated
  USING (guardian_id = auth.uid());

CREATE POLICY student_self_access ON public.students
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- 3. Learning Preferences: Guardian and Student access
CREATE POLICY guardian_pref_access ON public.student_learning_preferences
  FOR ALL TO authenticated
  USING (
    student_id IN (SELECT id FROM public.students WHERE guardian_id = auth.uid() OR user_id = auth.uid())
  );

-- 4. Subjects & Lessons: Public read for all authenticated users
CREATE POLICY subjects_read_all ON public.subjects
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY lessons_read_all ON public.lessons
  FOR SELECT TO authenticated
  USING (true);

-- 5. Chat Messages Isolation: Senders and Receivers only
CREATE POLICY chat_isolation_policy ON public.chat_messages
  FOR ALL TO authenticated
  USING (sender_id = auth.uid() OR receiver_id = auth.uid());

-- 6. Notifications: User can only read their own notifications
CREATE POLICY notifications_self_access ON public.notifications
  FOR ALL TO authenticated
  USING (user_id = auth.uid());

-- 7. Parent Weekly Reports: Guardian access only
CREATE POLICY parent_reports_guardian_access ON public.parent_weekly_reports
  FOR ALL TO authenticated
  USING (guardian_id = auth.uid());

-- ----------------------------------------------------------------------------
-- 20. SUPABASE REALTIME REPLICATION CONFIGURATION
-- ----------------------------------------------------------------------------
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.student_lesson_progress;
ALTER PUBLICATION supabase_realtime ADD TABLE public.quiz_submissions;

-- ----------------------------------------------------------------------------
-- 21. HELPER RPC FUNCTIONS (Called directly from Client SDK)
-- ----------------------------------------------------------------------------

-- A. Register Child for Guardian with auto code generation
CREATE OR REPLACE FUNCTION public.register_child(
  p_guardian_id UUID,
  p_name TEXT,
  p_grade_level TEXT,
  p_grade_level_en TEXT DEFAULT 'Grade 8',
  p_avatar_url TEXT DEFAULT 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
)
RETURNS TABLE (
  student_id UUID,
  student_name TEXT,
  student_code TEXT,
  grade_level TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ
) AS $$
DECLARE
  v_new_id UUID;
  v_generated_code TEXT;
BEGIN
  INSERT INTO public.students (guardian_id, name, grade_level, grade_level_en, avatar_url, overall_progress, attendance_rate, xp_points)
  VALUES (p_guardian_id, p_name, p_grade_level, p_grade_level_en, p_avatar_url, 0, 100, 100)
  RETURNING id, student_code INTO v_new_id, v_generated_code;

  -- Create initial default learning preference baseline
  INSERT INTO public.student_learning_preferences (student_id, visual_pct, auditory_pct, reading_writing_pct, interactive_hands_on_pct, confidence_score, summary_ar, summary_en)
  VALUES (v_new_id, 35, 20, 20, 25, 80, 'نمط بصري - تطبيقي متوازن', 'Balanced Visual & Kinesthetic Learner')
  ON CONFLICT DO NOTHING;

  RETURN QUERY
  SELECT s.id, s.name, s.student_code, s.grade_level, s.avatar_url, s.created_at
  FROM public.students s
  WHERE s.id = v_new_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- B. Fast Student Code Login lookup
CREATE OR REPLACE FUNCTION public.get_student_by_code(p_code TEXT)
RETURNS TABLE (
  id UUID,
  name TEXT,
  student_code TEXT,
  guardian_id UUID,
  school_id UUID,
  grade_level TEXT,
  avatar_url TEXT,
  overall_progress NUMERIC,
  attendance_rate NUMERIC,
  current_streak_days INT,
  xp_points INT,
  primary_modality TEXT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    s.id,
    s.name,
    s.student_code,
    s.guardian_id,
    s.school_id,
    s.grade_level,
    s.avatar_url,
    s.overall_progress,
    s.attendance_rate,
    s.current_streak_days,
    s.xp_points,
    s.primary_modality
  FROM public.students s
  WHERE UPPER(TRIM(s.student_code)) = UPPER(TRIM(p_code));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- C. Fetch all children for a guardian (with latest progress and codes)
CREATE OR REPLACE FUNCTION public.get_guardian_children_vault(p_guardian_id UUID)
RETURNS TABLE (
  student_id UUID,
  name TEXT,
  student_code TEXT,
  grade_level TEXT,
  avatar_url TEXT,
  overall_progress NUMERIC,
  current_streak_days INT,
  xp_points INT,
  visual_pct INT,
  auditory_pct INT,
  reading_pct INT,
  hands_on_pct INT,
  created_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    s.id AS student_id,
    s.name,
    s.student_code,
    s.grade_level,
    s.avatar_url,
    s.overall_progress,
    s.current_streak_days,
    s.xp_points,
    COALESCE(pref.visual_pct, 35) AS visual_pct,
    COALESCE(pref.auditory_pct, 20) AS auditory_pct,
    COALESCE(pref.reading_writing_pct, 20) AS reading_pct,
    COALESCE(pref.interactive_hands_on_pct, 25) AS hands_on_pct,
    s.created_at
  FROM public.students s
  LEFT JOIN public.student_learning_preferences pref ON pref.student_id = s.id
  WHERE s.guardian_id = p_guardian_id
  ORDER BY s.created_at ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ----------------------------------------------------------------------------
-- 22. INITIAL SEED DATA (Ready-to-use Subjects & Adaptive Curriculum)
-- ----------------------------------------------------------------------------
INSERT INTO public.subjects (id, title_ar, title_en, icon_name, color_theme, order_index)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'الرياضيات والمنطق', 'Mathematics & Logic', 'Calculator', 'blue', 1),
  ('22222222-2222-2222-2222-222222222222', 'العلوم الطبيعية والأحياء', 'Natural Sciences & Biology', 'Atom', 'emerald', 2),
  ('33333333-3333-3333-3333-333333333333', 'اللغة العربية والبيان', 'Arabic Language & Rhetoric', 'BookOpen', 'amber', 3),
  ('44444444-4444-4444-4444-444444444444', 'الفيزياء والطاقة', 'Physics & Energy', 'Zap', 'purple', 4)
ON CONFLICT (id) DO NOTHING;

-- Sample Multi-Modal Lesson: Photosynthesis (البناء الضوئي)
INSERT INTO public.lessons (
  id, subject_id, title_ar, title_en, unit_title_ar, unit_title_en, estimated_minutes, difficulty, summary_ar, summary_en,
  visual_content, auditory_content, reading_content, hands_on_content
)
VALUES (
  '55555555-5555-5555-5555-555555555555',
  '22222222-2222-2222-2222-222222222222',
  'عملية البناء الضوئي والطاقة الخلوية',
  'Photosynthesis & Cellular Energy',
  'الوحدة الثالثة: الحياة والبيئة',
  'Unit 3: Life & Environment',
  25,
  'intermediate',
  'شرح تكيفي متكامل لمعادلة البناء الضوئي ودور البلاستيدات الخضراء عبر 4 مسارات متوازية.',
  'Comprehensive adaptive explanation of photosynthesis through 4 parallel modality tracks.',
  '{
    "diagram_type": "chloroplast_flow",
    "key_elements": ["ضوء الشمس", "ثاني أكسيد الكربون (CO2)", "الماء (H2O)", "سكر الجلوكوز", "الأكسجين (O2)"],
    "color_map": {"chlorophyll": "#10B981", "light": "#F59E0B", "oxygen": "#3B82F6"}
  }'::jsonb,
  '{
    "audio_duration_seconds": 180,
    "narrator_tone": "engaging_story",
    "audio_script_ar": "تخيل أن كل ورقة شجر هي مصنع كيميائي ذكي صغير يستقبل فوتونات الشمس...",
    "mnemonic": "شمس + ماء + هواء = غذاء ونقاء"
  }'::jsonb,
  '{
    "core_law": "6CO2 + 6H2O + Light energy -> C6H12O6 + 6O2",
    "definitions": [
      {"term": "البلاستيدات الخضراء", "def": "عضيات خلوية تحتوي صبغة الكلوروفيل"},
      {"term": "الثايلاكويد", "def": "أقراص غشائية تحدث فيها التفاعلات الضوئية"}
    ]
  }'::jsonb,
  '{
    "interactive_challenge_type": "slider_balance",
    "experiment_title": "مختبر موازنة شدة الإضاءة ومعدل إنتاج فقاعات الأكسجين",
    "steps": [
      "قم بزيادة مصدر الضوء إلى 80%",
      "راقب زيادة انبعاث فقاعات الأكسجين في النبات المائي",
      "قس معدل إنتاج السكر"
    ]
  }'::jsonb
)
ON CONFLICT (id) DO NOTHING;
